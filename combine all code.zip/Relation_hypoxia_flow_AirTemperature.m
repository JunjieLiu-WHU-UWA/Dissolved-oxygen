addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead

file =  [dicmodel currentFolder '\Output\' ];
FlowIn = [ file '2. Flow\FlowInDaily_wholeWetland.csv'];
fid = fopen(FlowIn,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
FlowIN.Date = dateTime;
FlowIN.Data = data{1,2}; % the unit is m3/s
[ FlowINnonStorm,  FlowINStorm ]   = divide2period( FlowIN);

fileHypoxia = [ file '4. Oxygen\Hypoxia_DepthAveDay_daily.csv'];
fid = fopen(fileHypoxia,'rt');
data = textscan(fid,'%s %f %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
Hypoxia_Min.Date = dateTime;
Hypoxia_Min.Data = data{1,3}; % the minium  percent
[ Hypoxia_MinnonStorm,  Hypoxia_MinStorm ]   = divide2period( Hypoxia_Min);

fileDenitri = [ file '4. Oxygen\Denitri_DepthAveDay_daily.csv'];
fid = fopen(fileDenitri,'rt');
data = textscan(fid,'%s %f %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
Denitri_Max.Date = dateTime;
Denitri_Max.Data = data{1,2}; % the maximum percent
[ Denitri_MaxnonStorm,  Denitri_MaxStorm ]   = divide2period( Denitri_Max);

fileBC =  [ dicmodel currentFolder   '\BCs\'   'Met_sourthPerth_2005_2018.csv' ];
fid = fopen(fileBC ,'rt');
str = repmat('%f ', [1 7] );
data = textscan(fid, ['%s' str], 'Headerlines',1,'Delimiter',',');
ISOTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
AirTemp.Date = ISOTime;
AirTemp.Data = data{1,4};
AirTempDay = dailyDelta(AirTemp) % calculate daily maximum, minimum, delta, mean temperature.
AirTempDailyMean.Date =  AirTempDay.Date;
AirTempDailyMean.Data = AirTempDay.varMean;

ss =  find(     sTime <= AirTempDailyMean.Date & AirTempDailyMean.Date <=  eTime );
AirTempDailyMeanPeriod.Date = AirTempDailyMean.Date(ss);
AirTempDailyMeanPeriod.Data = AirTempDailyMean.Data(ss);

[ AirTempDailyMeanPeriodnonStorm,  AirTempDailyMeanPeriodStorm ]   = divide2period( AirTempDailyMeanPeriod);









figure
subplot(2,1,1)
h(1) = plot( AirTempDailyMeanPeriodnonStorm.Data  , Hypoxia_MinnonStorm.Data, '*b');
hold on 
h(2) = plot( AirTempDailyMeanPeriodStorm.Data  , Hypoxia_MinStorm.Data, '*r');
leg1 = legend(h(1:2), 'Non storm period','Storm event');
set(leg1,'Position',[0.121430184680557 0.866375991995791 0.392166836215666 0.0435578330893118],...
    'Orientation','horizontal', ...
    'box', 'on');
title([ 'scenario'  currentFolder  ]);
ylabel('Daily minimum percent of hypoxia');
xlabel(' Air temp (^{\circ}C)');

x1 = AirTempDailyMeanPeriodnonStorm.Data;
y = Hypoxia_MinnonStorm.Data;
X = [ones(size(x1)) x1 ];
[bnonStorm_AT_Y, bint_AT_Y, r_AT_Y, rint_AT_Y, statsnonStorm_AT_Y] = regress(y,X)  ;

x1 = AirTempDailyMeanPeriodStorm.Data;
y = Hypoxia_MinStorm.Data;
X = [ones(size(x1)) x1 ];
[bStorm_AT_Y, bint_AT_Y, r_AT_Y, rint_AT_Y, statsStorm_AT_Y] = regress(y,X)  ;

x1 = AirTempDailyMeanPeriod.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 ];
[b_AT_Y, bint_AT_Y, r_AT_Y, rint_AT_Y, stats_AT_Y] = regress(y,X)  ;


% set(pp, 'XScale','log');
subplot(2, 1, 2)
h(1) = semilogx(FlowINnonStorm.Data  ,  Hypoxia_MinnonStorm.Data, '*b');
hold on
h(2) = semilogx( FlowINStorm.Data  ,  Hypoxia_MinStorm.Data, '*r');
hold on
leg1 = legend(h(1:2), 'Non storm period','Storm event');
set(leg1,'Position',[0.121430184680557 0.866344058100564 0.392166836215666 0.0436217008797654],...
    'Orientation','horizontal', ...
    'box', 'on');
% title([ 'scenario'  currentFolder  ]);
ylabel('Daily minimum percent of hypoxia');
xlabel('Inflow rate (m^{3}/s)');

x1 = FlowINnonStorm.Data;
y = Hypoxia_MinnonStorm.Data;
X = [ones(size(x1)) x1 ];
[bnonStorm_Q_Y, bint_Q_Y, r_Q_Y, rint_Q_Y, statsnonStorm_Q_Y] = regress(y,X)  ;

x1 = FlowINStorm.Data;
y = Hypoxia_MinStorm.Data;
X = [ones(size(x1)) x1 ];
[bStorm_Q_Y, bint_Q_Y, r_Q_Y, rint_Q_Y, statsStorm_Q_Y] = regress(y,X)  ;

x1 = FlowIN.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 ];
[b_Q_Y, bint_Q_Y, r_Q_Y, rint_Q_Y, stats_Q_Y] = regress(y,X)  ;

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2_AirTemp_flow_single'],'png');
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2_ AirTemp_flow_single'],'fig');



% figure
% 
% % set(pp, 'XScale','log');
%  set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 20; ySize = 10;
% xLeft = 0; yTop = 0;
% 
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% % saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2 _Flow'],'png');
% % saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2_Flow'],'fig');




figure
scatter3(AirTempDailyMeanPeriodnonStorm.Data, FlowINnonStorm.Data, Hypoxia_MinnonStorm.Data,'*b')
hold on
scatter3(AirTempDailyMeanPeriodStorm.Data,  FlowINStorm.Data,   Hypoxia_MinStorm.Data,'*r')
hold on
grid on 
xlabel(' Air temp (^{\circ}C)', 'Rotation',30);
ylabel('Inflow rate (m^{3}/s)', 'Rotation',-30);
zlabel('Daily minimum percent of hypoxia');

leg1 = legend('Non storm period','Storm event');
set(leg1,...
    'Position',[0.22104526958291 0.645307917888567 0.219226856561546 0.0773460410557185]);

title([ 'scenario'  currentFolder  ]);
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2 _Flow AirTemp_double'],'png');
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2_Flow AirTemp_double'],'fig');

% non storm 
x1 = AirTempDailyMeanPeriodnonStorm.Data;
x2 = FlowINnonStorm.Data;    % Contains NaN data
y = Hypoxia_MinnonStorm.Data;
X = [ones(size(x1)) x1 x2 ];
[bnonStorm_AT_Q_Y,bint,r,rint,statsnonStorm_AT_Q_Y] = regress(y,X)  ;


%
x1 = AirTempDailyMeanPeriodStorm.Data;
x2 = FlowINStorm.Data;    % Contains NaN data
y = Hypoxia_MinStorm.Data;
X = [ones(size(x1)) x1 x2 ];
[bStorm_AT_Q_Y,bint,r,rint,statsStorm_AT_Q_Y] = regress(y,X)  ;

x1 = AirTempDailyMeanPeriod.Data;
x2 =FlowIN.Data;    % Contains NaN data
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 x2 ];
[bWhole_AT_Q_Y,bint,r,rint,statsWhole_AT_Q_Y] = regress(y,X) ; 


% figure
% scatter3(x1,x2,y,'filled')
% hold on
SolarRadiation.Date = ISOTime;
SolarRadiation.Data = data{1,6}; % w/m2

SolarRadiationDay  = dailyCummulativeRadiation(SolarRadiation); %  % the unit will be kJ

ss =  find(     sTime <= SolarRadiationDay.Date & SolarRadiationDay.Date <=  eTime );
SolarRadiationDayPeriod.Date = SolarRadiationDay.Date(ss);
SolarRadiationDayPeriod.Data = SolarRadiationDay.Data(ss);
[ SolarRadiationDayPeriodnonStorm,  SolarRadiationDayPeriodStorm ]   = divide2period( SolarRadiationDayPeriod);
figure
plot(SolarRadiationDayPeriodnonStorm.Date ,SolarRadiationDayPeriodnonStorm.Data, '*' )
hold on 
plot(SolarRadiationDayPeriodStorm.Date ,SolarRadiationDayPeriodStorm.Data, '*' )
hold on 
datetick('x', 19)
figure
h(1) = plot(SolarRadiationDayPeriodnonStorm.Data, Hypoxia_MinnonStorm.Data,'*b');
hold on 
h(2) = plot(    SolarRadiationDayPeriodStorm.Data  ,   Hypoxia_MinStorm.Data,'*r' );
leg1 = legend(h(1:2), 'Non storm period','Storm event');
set(leg1,'Position',[0.121430184680557 0.866375991995791 0.392166836215666 0.0435578330893118],...
    'Orientation','horizontal', ...
    'box', 'on');
title([ 'scenario'  currentFolder  ]);
ylabel('Daily minimum percent of hypoxia');
xlabel('Daily radiation (KJ)');

x1 = SolarRadiationDayPeriodnonStorm.Data;
y = Hypoxia_MinnonStorm.Data;
X = [ones(size(x1)) x1 ];
[bnonStorm_SR_Y, bintnonStorm_Q_Y, rnonStorm_SR_Y, rintnonStorm_SR_Y, statsnonStorm_SR_Y] = regress(y,X)  ;


x1 = SolarRadiationDayPeriodStorm.Data;
y = Hypoxia_MinStorm.Data;
X = [ones(size(x1)) x1 ];
[bStorm_SR_Y, bintStorm_Q_Y, rStorm_SR_Y, rintStorm_SR_Y, statsStorm_SR_Y] = regress(y,X)  ;

x1 = SolarRadiationDayPeriod.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 ];
[b_SR_Y, bint_Q_Y, r_SR_Y, rint_SR_Y, stats_SR_Y] = regress(y,X)  ;

%
x1 = AirTempDailyMeanPeriod.Data;
x2 = FlowIN.Data;    % Contains NaN data
x3 = SolarRadiationDayPeriod.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 x2 x3 ];
[bWhole_AT_Q_SR_Y,bint,r,rint,statsWhole_AT_Q_SR_Y] = regress(y,X) ; 

%---------------------------
x1 = AirTempDailyMeanPeriod.Data;
x2 = FlowIN.Data;    % Contains NaN data
x3 = SolarRadiationDayPeriod.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 x2 x3 ];
[bWhole_AT_Q_SR_Y,bint,r,rint,statsWhole_AT_Q_SR_Y] = regress(y,X) ; 


WindSpeed.Date = anvil.Met.DAFWA.LRD.southPerth.SP.mDate;

WindSpeed.Data = anvil.Met.DAFWA.LRD.southPerth.SP.WS * 1000 /3600;% m/s

WindSpeedDay  = dailyDelta(WindSpeed); %  % the unit will be m/s
WindSpeedDailyMean.Date =  WindSpeedDay.Date;
WindSpeedDailyMean.Data = WindSpeedDay.varMean;% average wind speed every day. m/s

ss =  find(     sTime <= WindSpeedDailyMean.Date & WindSpeedDailyMean.Date <=  eTime );
WindSpeedDayPeriod.Date = WindSpeedDailyMean.Date(ss);
WindSpeedDayPeriod.Data = WindSpeedDailyMean.Data(ss);

figure
plot(WindSpeedDayPeriod.Data   ,Hypoxia_Min.Data, '*'  )

x1 = AirTempDailyMeanPeriod.Data;
x2 = FlowIN.Data;    % Contains NaN data
x3 = WindSpeedDayPeriod.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 x2 x3 ];
[bWhole_AT_Q_WS_Y,bint,r,rint,statsWhole_AT_Q_WS_Y] = regress(y,X) ; 



x1 = AirTempDailyMeanPeriod.Data;
x2 = FlowIN.Data;    % Contains NaN data
 x3 = SolarRadiationDayPeriod.Data;
x4 = WindSpeedDayPeriod.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 x2 x3  x4 ];
[bWhole_AT_Q_SR_WS_Y,bint,r,rint,statsWhole_AT_Q__SRWS_Y] = regress(y,X) ; 