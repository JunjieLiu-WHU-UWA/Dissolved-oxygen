clc


% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead
file =  [dicmodel currentFolder '\Output\' ];
num_fig = 6;
figure

 % Atmospheric flux
  subplot(num_fig,1,1);
 fileAtm = [ file '5. Atmospheric flux\AtmFlux_wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
AtmFlux.Date = dateTime ;
AtmFlux.Data = data{1,3};

AtmFluxDaily = dailySum(AtmFlux);
fileAtmDailyOut = [ file '5. Atmospheric flux\AtmFluxDaily_rate_wholeWetland.csv'];
writeDaily(AtmFluxDaily,  fileAtmDailyOut  ,  'AtmFluxDaily(g O2/m2 /d)'  );

pp = plot(AtmFlux.Date, AtmFlux.Data);
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Atmospheric', 'exchange',' (g O_{2}/m^{2} /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
 grid on 
 %------------------------------
  
  % sediment oxygen
  subplot(num_fig,1,2);
  fileSed = [ file '6. Sediment Oxygen demand\SOD_wholeWetland.csv'];
 fid = fopen(fileSed,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedOxy.Date = dateTime;
SedOxy.Data = data{1,3};

SedOxyDaily = dailySum(SedOxy);
fileSedDailyOut = [ file '6. Sediment Oxygen demand\SedOxyDaily_rate_wholeWetland.csv'];
writeDaily(SedOxyDaily,  fileSedDailyOut  ,  'SedOxyDaily(g O2/m2 /d)'  );

pp = plot(SedOxy.Date, SedOxy.Data); % g O2/m2 /d
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sediment oxygen',' demand ', '(g O_{2}/m^{2} /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
 grid on 
 
 % pelagic productivity
  subplot(num_fig,1,3);
filePela = [ file '7. Pelagic productivity\Pelagic net productivity_wholeWetland.csv'];
fid = fopen(filePela,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
PelaPro.Date = dateTime;
PelaPro.Data = data{1,3};

PelaProDaily = dailySum(PelaPro);
filePelaDaily = [ file '7. Pelagic productivity\PelagicNetProductivityDaily_rate_wholeWetland.csv'];
writeDaily(PelaProDaily,  filePelaDaily  ,  'PelagicProductivityDaily(g O2/m2 /d)'  );

  pp = plot(PelaPro.Date, PelaPro.Data ); %  g O2/m2 /d
  set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Gross pelagic ', ' productivity', '(g O_{2}/m^{2} /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(e)','units','normalized');
 grid on 
  
 % net benthic productivity
 subplot(num_fig,1,4);
fileBen = [ file '8. Benthic productivity\Benthic net productivityBCP_wholeWetland.csv'];
fid = fopen(fileBen,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
BenPro.Date = dateTime;
BenPro.Data = data{1,3};

BenProDaily = dailySum(BenPro);
fileBenDaily = [ file '8. Benthic productivity\BenthicNetProductivityDaily_rate_wholeWetland.csv'];
writeDaily(BenProDaily,  fileBenDaily  ,  'BenthicProductivityDaily(g O2/m2 /d)'  );

pp = plot(BenPro.Date, BenPro.Data ); % g O2/m2 /d
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Net benthic',' producitvity ', '(g O_{2}/m^{2} /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(f)','units','normalized');
 grid on 
 
 
 
 % mineralisation of DOC
 subplot(num_fig,1,5);
fileBen = [ file '9. Carbon mineralisation\DeccomposittinPOCmineralisationDOC_wholeWetland.csv'];
fid = fopen(fileBen,'rt');
data = textscan(fid,'%s %f %f %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Miner_DOC.Date = dateTime;
Miner_DOC.Data = data{1,5};

Miner_DOCDaily = dailySum(Miner_DOC);
fileDOCDaily = [ file '9. Carbon mineralisation\mineralisationDOCDaily_rate_wholeWetland.csv'];
writeDaily(Miner_DOCDaily,  fileDOCDaily  ,  'mineralisationDOCDaily(g O2/m2 /d)'  );

pp = plot(Miner_DOC.Date, Miner_DOC.Data ); % g O2/m2 /d
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Mineralisation','DOC', '(g O_{2}/m^{2} /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(f)','units','normalized');
 grid on 
 
 
 
 
 % Nitrification of NH4
 subplot(num_fig,1,6);
fileNitri = [ file '10. Nitrogen nitrification\nitirification_wholeWetland.csv'];
fid = fopen(fileNitri,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Nitrif_NH4.Date = dateTime;
Nitrif_NH4.Data = data{1, 3};

Nitrif_NH4Daily = dailySum(Nitrif_NH4);
fileNitrif_NH4Daily = [ file '10. Nitrogen nitrification\nitirificationDaily_rate_wholeWetland.csv'];
writeDaily(Nitrif_NH4Daily,  fileNitrif_NH4Daily  ,  'nitirificationDaily(g O2/m2 /d)'  );

pp = plot(Nitrif_NH4.Date, Nitrif_NH4.Data ); % g O2/m2 /d
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Nitrification','NH_{4}', '(g O_{2}/m^{2} /d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(f)','units','normalized');
 grid on 
 
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 20;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file 'Oxygen budget rate'],'png');
 