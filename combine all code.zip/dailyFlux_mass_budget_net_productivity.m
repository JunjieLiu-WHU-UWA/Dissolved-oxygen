
% clearvars -except anvil 

addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
file =  [dicmodel currentFolder '\Output\' ];

% labels = {'Influent','Outfluent','Atmospheric flux', ...
%                 'SOD', 'PGPP', 'Pelagic respiration', ...
%                 'Benthic GPP',  'Benthic respiration', ...
%                 
%                 
%                 'Mineralization', 'Nitrification' }';
            
  % initial mass of oxygen all the cell
%   varid = netcdf.inqVarID(ncid,'WQ_OXY_OXY');
% Oxy = netcdf.getVar(ncid,varid) /1000 *32; % the unit is mg/L g/m3
%   

  % the ourput is g
  timeStep = 1;
%    oxy_mass_initial  = concentrationToMassTimeStep( OXY(:, timeStep)   , ...
%        Basic, Cell_whole_channel, timeStep);
%             
%            timeStep = length(   ResTime  );
%    oxy_mass_final  = concentrationToMassTimeStep( OXY(:, timeStep)   , ...
%        Basic, Cell_whole_channel, timeStep) ;
% %    
tot_fig = 7;
figure
%   -----source----------------
% transport in 
subplot(tot_fig,1,1);
             
   % transport in   
   
file_influent =  [ dicmodel currentFolder   '\Output\4. Oxygen\'   'Transport_in_Oxygen_10min.csv' ];
fid = fopen(file_influent ,'rt');
data_inlet = textscan(fid,'%s %f' ,'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
tarnsport_total_in.Date = ISOTime_in;
tarnsport_total_in.Data = data_inlet{1,2}; % g/d  total means includes inflow and Mars
  
 source_oxy(1,1) = trapz(tarnsport_total_in.Date , tarnsport_total_in.Data ) ;
 
  [ TranInletnonStorm,  TranInletStorm, sumTranInletperiod ]    = sum_10min_six_period( tarnsport_total_in ,  period_10min );
  % the unit is g 

 
tarnsport_total_inDaily = dailySum(tarnsport_total_in);
fileTransINDaily = [ file '2. Flow\transportInDaily_mass_wholeWetland.csv'];
writeDaily(tarnsport_total_inDaily,  fileTransINDaily  ,  'transportIn(g O2 / d)'  );

pp = plot(tarnsport_total_in.Date, tarnsport_total_in.Data ./1000) ; % kg/d  

AddShade([0  0] , [1000 1000] , period );
set(gca,'XTick',[datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylim([0 1000 ]);
ylabel({'Inflow','of oxygen', '(kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 title(['Scenario   '  currentFolder])
 grid on 
  
 
 % Atmospheric flux
 subplot(tot_fig,1,2);
 fileAtm = [ file '5. Atmospheric flux\AtmFlux_wholeWetland.csv'];
 fid = fopen(fileAtm,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
AtmFlux.Date = dateTime ;
AtmFlux.Data = data{1,2};
source_oxy(2,1) = trapz(AtmFlux.Date, AtmFlux.Data  );
 [ AtmFluxnonStorm,  AtmFluxStorm, sumAtmFluxperiod ]    = sum_10min_six_period( AtmFlux,  period_10min );
 % the unit is g

AtmFluxDaily = dailySum(AtmFlux);
fileAtmDailyOut = [ file '5. Atmospheric flux\AtmFluxDaily_mass_wholeWetland.csv'];
writeDaily(AtmFluxDaily,  fileAtmDailyOut  ,  'AtmFluxDaily(g O2 /d)'  );

pp = plot(AtmFlux.Date, AtmFlux.Data/1000); % kg/d
AddShade([0 0] , [40  40] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
ylim( [0   40 ])
xlim([sTime  eTime]);
ylabel({'Atmospheric', 'flux',' (kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');
 grid on 
 %------------------------------
 
 %  Pelagic net productivity
  subplot(tot_fig,1,3);
filePelaNEP = [ file '7. Pelagic productivity\Pelagic net productivity_wholeWetland.csv'];
fid = fopen(filePelaNEP,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
PelaNEP.Date = dateTime;
PelaNEP.Data = data{1,2};

source_oxy(3,1) = trapz(PelaNEP.Date,PelaNEP.Data  );
 [ PelaNEPnonStorm,  PelaNEPStorm, sumPelaNEPperiod ]    = sum_10min_six_period( PelaNEP,  period_10min );
 % the unit is g

PelaNEPDaily = dailySum(PelaNEP);
filePelaNEPDaily = [ file '7. Pelagic productivity\PelathicNEPDaily_mass_wholeWetland.csv'];
writeDaily(PelaNEPDaily,  filePelaNEPDaily  ,  'PelathicNetProductivityDaily(g O2 /d)'  );

pp = plot(PelaNEP.Date, PelaNEP.Data /1000); %kg/d
AddShade([0 0] , [50 50] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylim([0 20  ]);
ylabel({'Pelagic',' net production ', '(kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
 grid on 
 

 
 %  benthic net productivity

fileBenNEP = [ file '8. Benthic productivity\Benthic net productivityBCP_wholeWetland.csv'];
fid = fopen(fileBenNEP,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
BenNEP.Date = dateTime;
BenNEP.Data = data{1,2};

source_oxy(4,1) = trapz(BenNEP.Date,BenNEP.Data  );
 [ BenNEPnonStorm,  BenNEPStorm, sumBenNEPperiod ]    = sum_10min_six_period( BenNEP,  period_10min );
 % the unit is g

BenNEPDaily = dailySum(BenNEP);
fileBenNEPDaily = [ file '8. Benthic productivity\BenthicNetProductivity_mass_wholeWetland.csv'];
writeDaily(BenNEPDaily,  fileBenNEPDaily  ,  'BenthicNetProductivityDaily(g O2 /d)'  );
 subplot(tot_fig,1,4);
pp = plot(BenNEP.Date, BenNEP.Data /1000); %kg/d
AddShade([0 0] , [100 100] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'benthic',' net production', '(kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
 grid on 
   
 %  sink
% transport out
subplot(tot_fig,1,5);
file_outflow =  [ dicmodel currentFolder   '\Output\'  '4. Oxygen\Transport_outflow_Oxygen_10min.csv'];
fid = fopen(file_outflow ,'rt');
data_outlet = textscan(fid,'%s %f %f ', 'Headerlines',1,'Delimiter',',');
ISOTime_out = datenum(data_outlet{1,1},'dd/mm/yyyy HH:MM:SS');
transOutOxy.Date = ISOTime_out;
transOutOxy.Data = data_outlet{1,2};%  g/d 

% figure
% plot(  Outflow.Date,Outflow.Data   )
%  file_outflow =  [ dicmodel currentFolder   '\Output\'  '4. Oxygen\WeirDO_10min.csv'];
% fid = fopen(file_outflow ,'rt');
% data_outlet = textscan(fid,'%s %f', 'Headerlines',1,'Delimiter',',');
% ISOTime_out = datenum(data_outlet{1,1},'dd/mm/yyyy HH:MM:SS');
% transOutOxy.Date = ISOTime_out;
% transOutOxy.Data = data_outlet{1,3} ; 

% 3
% plot( OutOxygen.Date , OutOxygen.Data  )

% transOutOxy   = calculationFlux(Outflow.Date,   Outflow.Data,   OutOxygen.Data ); % mmol/s
% transOutOxy.Data = transOutOxy.Data  * Oxy_mmol_g  * day_second  ; % the unit is g/d
sink_oxy(1,1) = trapz(transOutOxy.Date, transOutOxy.Data  );

 [ TranOutnonStorm,  TranOutStorm, sumTranOutperiod ]    = sum_10min_six_period( transOutOxy,  period_10min );
 % the unit is g

transOutDaily = dailySum(transOutOxy);
fileTransOutDaily = [ file '2. Flow\transportOutDaily_mass_wholeWetland.csv'];
writeDaily(transOutDaily,  fileTransOutDaily  ,  'transportOut(g O2 /d)'  );
pp = plot(transOutOxy.Date, transOutOxy.Data /1000); % kg/d  
AddShade([0  0] , [1000 1000] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylim([0 1000 ]);
ylabel({'Effluent', 'of oxygen', '(kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(e)','units','normalized');
 grid on  
 
 
 
  % sediment oxygen
  subplot(tot_fig,1,6);
  
fileSed = [ file '6. Sediment Oxygen demand\SOD_wholeWetland.csv'];
fid = fopen(fileSed,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SedOxy.Date = dateTime;
SedOxy.Data = data{1,2};
sink_oxy(2,1) = trapz(SedOxy.Date, SedOxy.Data  );
 [ SedOxynonStorm,  SedOxyStorm, sumSedOxyperiod ]    = sum_10min_six_period( SedOxy,  period_10min );
 % the unit is g

SedOxyDaily = dailySum(SedOxy);
fileSedDailyOut = [ file '6. Sediment Oxygen demand\SedOxyDaily_mass_wholeWetland.csv'];
writeDaily(SedOxyDaily,  fileSedDailyOut  ,  'SedOxyDaily(g O2 /d)'  );


  pp = plot(SedOxy.Date, SedOxy.Data/1000); %kg/d
  AddShade([0 0] , [60 60] , period );
  set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
  set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Sediment oxygen',' demand ', '(kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(f)','units','normalized');
 grid on 
 
 
 
 
% mineralization
fileCarbon = [ file '9. Carbon mineralisation\DeccomposittinPOCmineralisationDOC_wholeWetland.csv'];
fid = fopen(fileCarbon,'rt');
data = textscan(fid,'%s %f %f %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
CarMiner.Date = dateTime;
CarMiner.Data = data{1,4};  % the unit is g/d
sink_oxy(3,1) = trapz(CarMiner.Date,CarMiner.Data  );
 [ CarMinernonStorm,  CarMinerStorm, sumCarMinerperiod ]    = sum_10min_six_period( CarMiner,  period_10min );
 % the unit is g

  subplot(tot_fig,1,7);

pp = plot(CarMiner.Date, CarMiner.Data /1000); %kg/d
AddShade([0 0] , [10 10] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Mineralisation',' DOC ', '(kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(g)','units','normalized');
 grid on 
 
 
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 29;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file 'Oxygen budget mass net production'],'jpg');
 
%%%%%%%%%%%%%%%%%%%
mass_merge = figure;
subplot(4, 1, 1);
hh = area(tarnsport_total_in.Date, tarnsport_total_in.Data ./1000) ; % kg/d  

hold on
hhh = area(transOutOxy.Date, transOutOxy.Data /1000 * (-1)); % kg/d
% 
% leg_in = legend(hh, 'Inflow of oxygen');
% leg_in = legend(hhh, 'Outflow of oxygen');

% AddShade([0 0] , [60 60] , period );
  set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
  set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({ 'kg/d'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(a)','units','normalized');
 grid on 
hold on


 text(1.05,0.5,'Inflow','units','normalized', 'Rotation',90);
  text(1.05,0.05,'Outflow','units','normalized', 'Rotation',90);
  
 annotation(mass_merge,'arrow',[0.913179916317992 0.913179916317992],...
    [0.832670349907919 0.90475138121547],'LineWidth',1);
 annotation(mass_merge,'arrow',[0.915271966527197 0.916317991631799],...
    [0.803254143646408 0.753222836095764],'LineWidth',1);


subplot(4, 1, 2);
pp = plot(AtmFlux.Date, AtmFlux.Data/1000); % kg/d

hold on 

pp = plot(PelaNEP.Date, PelaNEP.Data /1000, 'r'); %kg/d


AddShade([0 0] , [20 20] , period );
  set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
  set(gca,'GridAlpha',0.5);
  leg1 = legend('Atmospheric flux', 'Pelagic net production');
  set(leg1,...
    'Position',[0.348849372384938 0.658839779005525 0.482740585774058 0.0547882136279926],...
    'Orientation','horizontal');
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'kg/d'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(b)','units','normalized');
 grid on 

subplot(4, 1, 3);
hold on 
pp = plot(BenNEP.Date, BenNEP.Data /1000); %kg/d

AddShade([-50 -50] , [100 100] , period );
  set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
  set(gca,'GridAlpha',0.5);
set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Benthic net','production (kg/d)'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(c)','units','normalized');
 grid on 
 
subplot(4, 1, 4);
  pp = plot(SedOxy.Date, SedOxy.Data/1000 * (-1)); %kg/d
  hold on 
pp = plot(CarMiner.Date, CarMiner.Data /1000 * (-1), 'r'); %kg/d

AddShade([0 0] , [-60 -60] , period );
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
leg1 = legend('Sediment oxygen demand', 'Mineralization');
set(leg1,...
    'Position',[0.313343907089986 0.130449978537504 0.305696846388606 0.0447368421052632], ...
     'Orientation','vertical');
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({ 'kg/d'});
%  text( sTime + 8,800,'(a)');
 text(0.08,1.1,'(d)','units','normalized');
 grid on 
 
 
 
 set(mass_merge, 'PaperPositionMode', 'manual');
set(mass_merge, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 20;
xLeft = 0;   yTop = 0;
set(mass_merge,'paperposition',[xLeft yTop xSize ySize])
saveas(mass_merge, [file 'Oxygen budget mass net production_merge'],'jpg');
 
 print(mass_merge,[file 'fig 6 Oxygen budget mass net production_merge.tiff'],'-dtiff','-r300');
print(mass_merge,[file 'fig 6 Oxygen budget mass net production_merge.png'],'-dpng','-r300');
% nitrification

fileNitri = [ file '10. Nitrogen nitrification\nitirification_wholeWetland.csv'];
fid = fopen(fileNitri,'rt');
data = textscan(fid,'%s %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
NitroNitro.Date = dateTime;
NitroNitro.Data = data{1,2};  % the unit is g/d
% sink_oxy(4,1) = trapz(NitroNitro.Date,NitroNitro.Data ) ;
 [ NitroNitrononStorm,  NitroNitroStorm, sumNitroNitrorperiod ]    = sum_10min_six_period( NitroNitro,  period_10min );
 % the unit is g


% 
% figure
% p = pie(budget_oxy);
% pText = findobj(p,'Type','text');
% 
% leg1 = legend('Influent','Outfluent','Atmospheric flux', ...
%                 'SOD', 'PGPP', 'NBP', 'Mineraliation', 'Nitrification');
%  set(leg1,...
%     'Location','eastoutside');
% title([currentFolder ] );
% set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 15; ySize = 10;
% xLeft = 0;   yTop = 0;
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file 'Pie Oxygen budget percent'],'jpg');

% total_in_oxygen  = budget_oxy(1,1) + budget_oxy(3,1) + budget_oxy(5,1) + budget_oxy(6,1) ;
% 



%----------------whole period----------------
f = figure;
f.Renderer = 'painters';
fig_p  = subplot(2,1,1);
p = pie2(source_oxy);
colormap(gca, [ 0.5 0.5 0.5;      %white
          0, 0.4470, 0.7410  ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow
      hold on 
      
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.4);
% set(findobj(h, '-property', 'EdgeAlpha'), 'EdgeAlpha', 0);
pText = findobj(p,'Type','text');

% p(1).Position = 0.5*p(1).Position;
% p(2).Position = 0.3*p(2).Position;
% p(4).Position = 0.3*p(4).Position;
% p(6).Position = 0.3*p(6).Position;
% p(8).Position =  0.5 * p(8).Position;
% p(8).Position =  [ 0.2 0.6  0 ] .* p(8).Position;
% [ 0.5  1.0  0  ] .* [0.24 1.0 0  ]
% for iHandle = 2:2:2*numel(labels)
%     pieHandle(iHandle).Position = 0.5*pieHandle(iHandle).Position;
% end
% leg1  = legend(fig_p  , 'Inflow' , 'Atmospheric flux', ...
%                      'Pelagic net production', 'Benthic net production');
%  set(leg1,...
%     'Location','eastoutside', 'box', 'off', 'FontSize', 5.5);
% 
% leg1 = legend('Influent' , 'Atmospheric flux', ...
%               'PNP', 'BNP');
%  set(leg1,...
%     'Position',[0.167853511645051 0.078539767857999 0.214140386571719 0.130704041720991]);
% % set(leg1,...
%     'Position',[0.727365213214199 0.687407680945347 0.214140386571719 0.14807976366322]);
% title([currentFolder 'Oxygen budget whole period' ] );

% total_out_oxygen = budget_oxy(2,1) + budget_oxy(4,1) +  budget_oxy(7,1) + budget_oxy(8,1);
% 


%  diff = total_in_oxygen + oxy_mass_final  - total_out_oxygen - oxy_mass_initial ;
%  
%  sum(oxygen_in(2:4)) + oxy_mass_final - sum( oxygen_out(2:4)) -  oxy_mass_initial;

subplot(2,1,2)
p = pie2(sink_oxy);
colormap(gca, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  %cyan
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.4);
p(2).Position = 0.2*p(2).Position;
p(4).Position = 0.2*p(4).Position;
% p(6).Position =  [ 0.8  1.0  0   ] .*p(6).Position;
% leg1  = legend('Outflow', ...
%                        'Sediment  oxyen demand', ...
%        'Mineralization');
%  set(leg1,...
%     'Location','eastoutside',  'box', 'off', 'FontSize', 5.5);

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file 'Pie Oxygen  inlet outlet budget percent'],'jpg');
 print(gcf,[file 'Fig 7 Pie Oxygen  inlet outlet budget percent.tiff'],'-dtiff','-r300');
print(gcf,[file 'Fig 7 Pie Oxygen  inlet outlet budget percent.png'],'-dpng','-r300');
%------------------------------- non storm period----  in 
oxygen_in_nonStorm(1,1)  =  TranInletnonStorm ;
oxygen_in_nonStorm(2,1)  = AtmFluxnonStorm;
oxygen_in_nonStorm(3,1)  = PelaNEPnonStorm;
oxygen_in_nonStorm(4,1)  = BenNEPnonStorm;

% out
oxygen_out_nonStorm(1,1)  =  TranOutnonStorm;
oxygen_out_nonStorm(2,1)  = SedOxynonStorm;
oxygen_out_nonStorm(3,1)  =  CarMinernonStorm;
% oxygen_out_nonStorm(4,1)  =  NitroNitrononStorm;
% ------------------storm period
% in
oxygen_in_Storm(1,1)  =  TranInletStorm ;
oxygen_in_Storm(2,1)  =  AtmFluxStorm;
oxygen_in_Storm(3,1)  = PelaNEPStorm;
oxygen_in_Storm(4,1)  = BenNEPStorm; % druing strom event, it become negative
% out
oxygen_out_Storm(1,1)  =  TranOutStorm;
oxygen_out_Storm(2,1)  =   SedOxyStorm;

oxygen_out_Storm(3,1)  =  CarMinerStorm;
% oxygen_out_Storm(4,1)  =  NitroNitroStorm;
%
figure
fig_p  = subplot(2,1,1);
p = pie2(oxygen_in_nonStorm);
colormap(gca, [ 0.5 0.5 0.5;      %white
         0, 0.4470, 0.7410   ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.4);
p(2).Position = [ 0.2  0.5 0   ]  .*p(2).Position;
p(4).Position = [ 0.2  0.5 0   ] .*p(4).Position;
p(6).Position = [  0.2  0.6  0 ] .*p(6).Position;
p(8).Position = [  0.2  0.5  0 ] .*p(8).Position;
% leg1  = legend(fig_p  , 'Inflow' , 'Atmospheric flux', ...
%                      'Pelagic net production', 'Benthic net production');
%  set(leg1,...
%     'Location','eastoutside', 'box', 'off', 'FontSize', 5.5);

% title([currentFolder '     ' 'Oxygen budget non storm period' ] );
subplot(2,1,2)
p = pie2(oxygen_out_nonStorm);
colormap(gca, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  %cyan
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.4);
p(2).Position = [0 1  0  ] .*p(2).Position;
p(4).Position =  [0.4  0.3 0  ].*p(4).Position;
% p(6).Position =  [ 0.2  0.6 0 ].*p(6).Position;
% leg1  = legend('Outflow', ...
%                        'Sediment  oxyen demand', ...
%        'Mineralization');
%  set(leg1,...
%     'Location','eastoutside',  'box', 'off', 'FontSize', 5.5);
% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file 'Pie Oxygen nonStorm in out budget percent'],'jpg');
 print(gcf,[file 'Fig 7 Pie Oxygen nonStorm in out budget percent.tiff'],'-dtiff','-r300');
print(gcf,[file 'Fig 7 Pie Oxygen nonStorm in out budget percent.png'],'-dpng','-r300');


f = figure;
f.Renderer = 'painters';
fig_p = subplot(2,1,1);
p = pie2(oxygen_in_Storm);
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410  ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.5);
p(2).Position = [ 0.2  0.2 0  ] .*p(2).Position;
% p(4).Position = 0.5*p(4).Position;
% p(6).Position = 0.5*p(6).Position;
p(8).Position = [ -4.0 1.2 0  ] .*p(8).Position;
% leg1  = legend(fig_p  , 'Inflow' , 'Atmospheric flux', ...
%                      'Pelagic net production', 'Benthic net production');
%  set(leg1,...
%     'Location','eastoutside', 'box', 'off', 'FontSize', 5.5);

% title([currentFolder '  ' ' Oxygen budget Storm event' ] );
subplot(2,1,2)
% figure
p = pie2(oxygen_out_Storm);
colormap(gca, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  %cyan
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.5);
p(2).Position = [ 0.1  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.2 0.5 0  ].*p(4).Position;
% p(6).Position = 0.7*p(6).Position;
% leg1  = legend('Outflow', ...
%                        'Sediment  oxyen demand', ...
%        'Mineralization');
%  set(leg1,...
%     'Location','eastoutside',  'box', 'off', 'FontSize', 5.5);

% % LEG_obj = findobj(leg1,'type','text');
% leg1.FontSize = 8;
% lgnd = legend(legendTextCells);
% set(leg1.BoxFace, 'ColorType', 'truecoloralpha', 'ColorData', uint8([255;255;255;0.4*255]));
% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file 'Pie Oxygen Storm in out budget percent'],'jpg');

 print(gcf,[file 'Fig 7 Pie Oxygen Storm in out budget percent.tiff'],'-dtiff','-r300');
print(gcf,[file 'Fig 7 Pie Oxygen Storm in out budget percent.png'],'-dpng','-r300');

% for legend
f = figure;
f.Renderer = 'painters';
fig_p = subplot(2,1,1);
p = pie2(oxygen_in_Storm);
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410  ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.5);
p(2).Position = [ 0.2  0.2 0  ] .*p(2).Position;
% p(4).Position = 0.5*p(4).Position;
% p(6).Position = 0.5*p(6).Position;
p(8).Position = [ -4.0 1.2 0  ] .*p(8).Position;
leg1  = legend(fig_p  , 'Inflow' , 'Atmospheric flux', ...
                     'Pelagic net production', 'Benthic net production');
 set(leg1,...
    'Location','eastoutside', 'box', 'off', 'FontSize', 5.5);

% title([currentFolder '  ' ' Oxygen budget Storm event' ] );
subplot(2,1,2)
% figure
p = pie2(oxygen_out_Storm);
colormap(gca, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  %cyan
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.5);
p(2).Position = [ 0.1  0.5 0 ] .*p(2).Position;
p(4).Position =  [0.2 0.5 0  ].*p(4).Position;
% p(6).Position = 0.7*p(6).Position;
leg1  = legend('Outflow', ...
                       'Sediment  oxyen demand', ...
       'Mineralization');
 set(leg1,...
    'Location','eastoutside',  'box', 'off', 'FontSize', 5.5);

% % LEG_obj = findobj(leg1,'type','text');
% leg1.FontSize = 8;
% lgnd = legend(legendTextCells);
% set(leg1.BoxFace, 'ColorType', 'truecoloralpha', 'ColorData', uint8([255;255;255;0.4*255]));
% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file 'Pie Oxygen Storm in out budget percent'],'jpg');

 print(gcf,[file 'Fig 7 Pie Oxygen Storm in out budget percent_legend.tiff'],'-dtiff','-r300');
print(gcf,[file 'Fig 7 Pie Oxygen Storm in out budget percent_legend.png'],'-dpng','-r300');




% for  graphical abstract
% for  graphical abstract% for  graphical abstract
% for  graphical abstract
figure
fig_p  = subplot(2,1,1);
p = pie2(oxygen_in_nonStorm);
colormap(gca, [ 0.5 0.5 0.5;      %white
         0, 0.4470, 0.7410   ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow

pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.4);
      TextChildren =  findobj(p,'Type','text');
      set(TextChildren,'visible','off')
% p(2).Position = [ 0.2  0.5 0   ]  .*p(2).Position;
% p(4).Position = [ 0.2  0.5 0   ] .*p(4).Position;
% p(6).Position = [  0.2  0.6  0 ] .*p(6).Position;
% p(8).Position = [  0.2  0.5  0 ] .*p(8).Position;
% leg1  = legend(fig_p  , 'Inflow' , 'Atmospheric flux', ...
%                      'Pelagic net production', 'Benthic net production');
%  set(leg1,...
%     'Location','eastoutside', 'box', 'off', 'FontSize', 5.5);

% title([currentFolder '     ' 'Oxygen budget non storm period' ] );
subplot(2,1,2)
p = pie2(oxygen_out_nonStorm);
colormap(gca, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  %cyan
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.4);
      TextChildren =  findobj(p,'Type','text');
      set(TextChildren,'visible','off')
% p(2).Position = [0 1  0  ] .*p(2).Position;
% p(4).Position =  [0.4  0.3 0  ].*p(4).Position;
% p(6).Position =  [ 0.2  0.6 0 ].*p(6).Position;
% leg1  = legend('Outflow', ...
%                        'Sediment  oxyen demand', ...
%        'Mineralization');
%  set(leg1,...
%     'Location','eastoutside',  'box', 'off', 'FontSize', 5.5);
% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file 'Pie Oxygen nonStorm in out budget percent'],'jpg');
 print(gcf,[file 'Fig 7 Pie Oxygen nonStorm in out budget percent_graphicalAbstract.tiff'],'-dtiff','-r300');
print(gcf,[file 'Fig 7 Pie Oxygen nonStorm in out budget percent_graphicalAbstract.png'],'-dpng','-r300');


f = figure;
f.Renderer = 'painters';
fig_p = subplot(2,1,1);
p = pie(oxygen_in_Storm);
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410  ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.5);
      TextChildren =  findobj(p,'Type','text');
      set(TextChildren,'visible','off')
% p(2).Position = [ 0.2  0.2 0  ] .*p(2).Position;
% p(4).Position = 0.5*p(4).Position;
% p(6).Position = 0.5*p(6).Position;
% p(8).Position = [ -4.0 1.2 0  ] .*p(8).Position;
% leg1  = legend(fig_p  , 'Inflow' , 'Atmospheric flux', ...
%                      'Pelagic net production', 'Benthic net production');
%  set(leg1,...
%     'Location','eastoutside', 'box', 'off', 'FontSize', 5.5);

% title([currentFolder '  ' ' Oxygen budget Storm event' ] );
subplot(2,1,2)
% figure
p = pie2(oxygen_out_Storm);
colormap(gca, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  %cyan
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.5);
      TextChildren =  findobj(p,'Type','text');
      set(TextChildren,'visible','off')
% p(2).Position = [ 0.1  0.5 0 ] .*p(2).Position;
% p(4).Position =  [0.2 0.5 0  ].*p(4).Position;
% % p(6).Position = 0.7*p(6).Position;
% leg1  = legend('Outflow', ...
%                        'Sediment  oxyen demand', ...
%        'Mineralization');
%  set(leg1,...
%     'Location','eastoutside',  'box', 'off', 'FontSize', 5.5);

% % LEG_obj = findobj(leg1,'type','text');
% leg1.FontSize = 8;
% lgnd = legend(legendTextCells);
% set(leg1.BoxFace, 'ColorType', 'truecoloralpha', 'ColorData', uint8([255;255;255;0.4*255]));
% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file 'Pie Oxygen Storm in out budget percent'],'jpg');

 print(gcf,[file 'Fig 7 Pie Oxygen Storm in out budget percent_graphicalAbstract.tiff'],'-dtiff','-r300');
print(gcf,[file 'Fig 7 Pie Oxygen Storm in out budget percent_graphicalAbstract.png'],'-dpng','-r300');