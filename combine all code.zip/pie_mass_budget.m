

f = figure;
f.Renderer = 'painters';
fig_p = subplot(2,1,1);
p = pie(oxygen_in_Storm);
colormap(fig_p , [ 0.5  0.5  0.5;      %grey
       0, 0.4470, 0.7410  ; % blue      
          0 1 0;  % green     
          1 1 0]) % yellow
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.5);
      TextChildren =  findobj(p,'Type','text');
      set(TextChildren,'visible','off')
% p(2).Position = [ 0.2  0.2 0  ] .*p(2).Position;
% p(4).Position = 0.5*p(4).Position;
% p(6).Position = 0.5*p(6).Position;
% p(8).Position = [ -4.0 1.2 0  ] .*p(8).Position;
% leg1  = legend(fig_p  , 'Inflow' , 'Atmospheric flux', ...
%                      'Pelagic net production', 'Benthic net production');
%  set(leg1,...
%     'Location','eastoutside', 'box', 'off', 'FontSize', 5.5);

% title([currentFolder '  ' ' Oxygen budget Storm event' ] );
subplot(2,1,2)
% figure
p = pie2(oxygen_out_Storm);
colormap(gca, [ 0.5 0.5 0.5;      %grey
         1 0 0  ; % red   
          0 1 1 ])  %cyan
pText = findobj(p,'Type','text');
set(findobj(p, '-property', 'FaceAlpha'), 'FaceAlpha', 0.5);
      TextChildren =  findobj(p,'Type','text');
      set(TextChildren,'visible','off')
% p(2).Position = [ 0.1  0.5 0 ] .*p(2).Position;
% p(4).Position =  [0.2 0.5 0  ].*p(4).Position;
% % p(6).Position = 0.7*p(6).Position;
% leg1  = legend('Outflow', ...
%                        'Sediment  oxyen demand', ...
%        'Mineralization');
%  set(leg1,...
%     'Location','eastoutside',  'box', 'off', 'FontSize', 5.5);

% % LEG_obj = findobj(leg1,'type','text');
% leg1.FontSize = 8;
% lgnd = legend(legendTextCells);
% set(leg1.BoxFace, 'ColorType', 'truecoloralpha', 'ColorData', uint8([255;255;255;0.4*255]));
% title([currentFolder ] );
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file 'Pie Oxygen Storm in out budget percent'],'jpg');

 print(gcf,[file 'Fig 7 Pie Oxygen Storm in out budget percent_graphicalAbstract.tiff'],'-dtiff','-r300');
print(gcf,[file 'Fig 7 Pie Oxygen Storm in out budget percent_graphicalAbstract.png'],'-dpng','-r300');