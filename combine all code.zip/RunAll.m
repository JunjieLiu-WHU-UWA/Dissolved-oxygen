
addpath('E:\Simulation_UWA_WD\1 water balance');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
addpath('E:\Simulation_UWA_WD\2 For model variables\1. Water stage');
addpath('E:\Simulation_UWA_WD\2 For model variables\2. Flow');
addpath('E:\Simulation_UWA_WD\2 For model variables\3. Temperature');
addpath('E:\Simulation_UWA_WD\2 For model variables\4. Oxygen');
addpath('E:\Simulation_UWA_WD\2 For model variables\5. Atmospheric flux');
addpath('E:\Simulation_UWA_WD\2 For model variables\6. Sediment Oxygen demand');
addpath('E:\Simulation_UWA_WD\2 For model variables\7. Pelagic productivity');
addpath('E:\Simulation_UWA_WD\2 For model variables\8. Benthic productivity');
addpath('E:\Simulation_UWA_WD\2 For model variables\9. Carbon mineralisation');
addpath('E:\Simulation_UWA_WD\2 For model variables\10. Nitrogen nitrification');
addpath('E:\Simulation_UWA_WD\2 For model variables\11. Residence time');
% BasicRead
% wholeCell_channel_basicVariable
waterBalance

WaterStage
% Flow_oxygen
FlowInDaily_Discharge
TemperatureCablibriationCurtain
OxygenCalibriationMid
AtmosphericFlux
SedimentOxygenDemand
PelagicProductivity
BenthicProductivity
CarbonMineralisation
NitrogenNitrificaion





ResidenceTime 


FlowInDaily_Discharge

% Period_discharge

CarbonMineralisation

NitrogenNitrificaion
  Oxygen_Inlet_Outlet
  Transport_in_out_oxygen
  calculate_area_hypoxia
  MainLine_oxygen_temperature
 dailyFlux_mass_budget_net_productivity 
 
 dailyFlux_rate
 ComparisonNon_Storm_flow_component
 Static_primaryProduction_respiration
 
 addpath('E:\Simulation_UWA_WD\3 nitrogen')
 runAll_NNN