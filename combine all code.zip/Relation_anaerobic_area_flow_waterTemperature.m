addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead

file =  [dicmodel currentFolder '\Output\' ];
FlowIn = [ file '2. Flow\FlowInDaily_wholeWetland.csv'];
fid = fopen(FlowIn,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
FlowIN.Date = dateTime;
FlowIN.Data = data{1,2}; % the unit is m3/s
[ FlowINnonStorm,  FlowINStorm ]   = divide2period( FlowIN);


fileDenitri = [ file '4. Oxygen\Denitri_DepthAveDay_daily.csv'];
fid = fopen(fileDenitri,'rt');
data = textscan(fid,'%s %f %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
Denitri_Min.Date = dateTime;
Denitri_Min.Data = data{1,3}; % the minimum percent
[ Denitri_MinnonStorm,  Denitri_MinStorm ]   = divide2period( Denitri_Min);

fileBC =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(fileBC ,'rt');
str = repmat('%f ', [1 27] );
data = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Temp.Date = ISOTime;
Temp.Data = data{1,4}
TempDay = dailyDelta(Temp) % calculate daily maximum, minimum, delta, mean temperature.
TempDailyMean.Date =  TempDay.Date;
TempDailyMean.Data = TempDay.varMean;

[ TempDailyMeannonStorm,  TempDailyMeanStorm ]   = divide2period( TempDailyMean);

figure
h(1) = plot( TempDailyMeannonStorm.Data  , Denitri_MinnonStorm.Data, '*b');
hold on 
h(2) = plot( TempDailyMeanStorm.Data  , Denitri_MinStorm.Data, '*r');
leg1 = legend(h(1:2), 'Non storm period','Storm event');
set(leg1,'Position',[0.126516654670388 0.933792738452483 0.392166836215666 0.0436217008797654],...
    'Orientation','horizontal', ...
    'box', 'on');
title([ 'scenario'  currentFolder  ]);
ylabel('Daily minimum percent of anaerobic area (%)');
xlabel(' Water temp (^{\circ}C)');
% set(pp, 'XScale','log');
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  0 5  waterTemp'],'png');
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  0 5_ waterTemp'],'fig');

%---------------------------------

figure
h(1) = semilogx(FlowINnonStorm.Data  ,  Denitri_MinnonStorm.Data, '*b');
hold on
h(2) = semilogx( FlowINStorm.Data  ,  Denitri_MinStorm.Data, '*r');
hold on
leg1 = legend(h(1:2), 'Non storm period','Storm event');
set(leg1,'Position',[0.126516654670388 0.933792738452483 0.392166836215666 0.0436217008797654],...
    'Orientation','horizontal', ...
    'box', 'on');
title([ 'scenario'  currentFolder  ]);
ylabel('Daily minimum percent of anaerobic area (%)');
xlabel('Inflow rate (m^{3}/s)');
% set(pp, 'XScale','log');
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent minimum 0 5 _Flow'],'png');
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent minimum 0 5_Flow'],'fig');
%----------------------------------------------------------------------

x1 = TempDailyMeannonStorm.Data;
x2 = FlowINnonStorm.Data;    % Contains NaN data
y = Denitri_MinnonStorm.Data;
X = [ones(size(x1)) x1 x2 ];
[bnonStorm,bint,r,rint,statsnonStorm] = regress(y,X)  ;
figure
scatter3(x1,x2,y,'*b')
hold on

x1 = TempDailyMeanStorm.Data;
x2 = FlowINStorm.Data;    % Contains NaN data
y = Denitri_MinStorm.Data;
X = [ones(size(x1)) x1 x2 ];
[bStorm,bint,r,rint,statsStorm] = regress(y,X)  ;
scatter3(x1,x2,y,'*r')
hold on
grid on 
xlabel(' Water temp (^{\circ}C)', 'Rotation',30);
ylabel('Inflow rate (m^{3}/s)', 'Rotation',-30);
zlabel('Daily minimum percent of anaerobic area');

leg1 = legend('Non storm period','Storm event');
set(leg1,...
    'Position',[0.22104526958291 0.645307917888567 0.219226856561546 0.0773460410557185]);

title([ 'scenario'  currentFolder  ]);
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent minimum 0 5 _Flow waterTemp'],'png');
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  minimum 0 5_Flow waterTemp'],'fig');

x1 = TempDailyMean.Data;
x2 =FlowIN.Data;    % Contains NaN data
y = Denitri_Min.Data;
X = [ones(size(x1)) x1 x2 ];
[bWhole,bint,r,rint,statsWhole] = regress(y,X) ; 
figure
scatter3(x1,x2,y,'filled')
hold on

