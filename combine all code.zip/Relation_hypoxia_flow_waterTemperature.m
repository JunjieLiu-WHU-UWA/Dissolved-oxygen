% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead

file =  [dicmodel currentFolder '\Output\' ];
FlowIn = [ file '2. Flow\FlowInDaily_wholeWetland.csv'];
fid = fopen(FlowIn,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
FlowIN.Date = dateTime;
FlowIN.Data = data{1,2}; % the unit is m3/s
[ FlowINnonStorm,  FlowINStorm ]   = divide2period( FlowIN);

fileHypoxia = [ file '4. Oxygen\Hypoxia_DepthAveDay_daily.csv'];
fid = fopen(fileHypoxia,'rt');
data = textscan(fid,'%s %f %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
Hypoxia_Min.Date = dateTime;
Hypoxia_Min.Data = data{1,3}; % the minium  percent
[ Hypoxia_MinnonStorm,  Hypoxia_MinStorm ]   = divide2period( Hypoxia_Min);

fileDenitri = [ file '4. Oxygen\Denitri_DepthAveDay_daily.csv'];
fid = fopen(fileDenitri,'rt');
data = textscan(fid,'%s %f %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
Denitri_Max.Date = dateTime;
Denitri_Max.Data = data{1,2}; % the maximum percent
[ Denitri_MaxnonStorm,  Denitri_MaxStorm ]   = divide2period( Denitri_Max);

fileBC =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(fileBC ,'rt');
str = repmat('%f ', [1 27] );
data = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Temp.Date = ISOTime;
Temp.Data = data{1,4}
TempDay = dailyDelta(Temp) % calculate daily maximum, minimum, delta, mean temperature.
TempDailyMean.Date =  TempDay.Date;
TempDailyMean.Data = TempDay.varMean;

[ TempDailyMeannonStorm,  TempDailyMeanStorm ]   = divide2period( TempDailyMean);

figure
subplot(2,1,1)
h(1) = plot( TempDailyMeannonStorm.Data  , Hypoxia_MinnonStorm.Data, '*b');
hold on 
h(2) = plot( TempDailyMeanStorm.Data  , Hypoxia_MinStorm.Data, '*r');
leg1 = legend(h(1:2), 'Non storm period','Storm event');
set(leg1,'Position',[0.121430184680557 0.866375991995791 0.392166836215666 0.0435578330893118],...
    'Orientation','horizontal', ...
    'box', 'on');
title([ 'scenario'  currentFolder  ]);
ylabel('Daily minimum percent of hypoxia');
xlabel(' Water temp (^{\circ}C)');

x1 = TempDailyMeannonStorm.Data;
y = Hypoxia_MinnonStorm.Data;
X = [ones(size(x1)) x1 ];
[bnonStorm_WT_Y, bint_WT_Y, r_WT_Y, rint_WT_Y, statsnonStorm_WT_Y] = regress(y,X)  ;

x1 = TempDailyMeanStorm.Data;
y = Hypoxia_MinStorm.Data;
X = [ones(size(x1)) x1 ];
[bStorm_WT_Y, bint_WT_Y, r_WT_Y, rint_WT_Y, statsStorm_WT_Y] = regress(y,X)  ;

x1 = TempDailyMean.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 ];
[b_WT_Y, bint_WT_Y, r_WT_Y, rint_WT_Y, stats_WT_Y] = regress(y,X)  ;


% set(pp, 'XScale','log');
subplot(2, 1, 2)
h(1) = semilogx(FlowINnonStorm.Data  ,  Hypoxia_MinnonStorm.Data, '*b');
hold on
h(2) = semilogx( FlowINStorm.Data  ,  Hypoxia_MinStorm.Data, '*r');
hold on
leg1 = legend(h(1:2), 'Non storm period','Storm event');
set(leg1,'Position',[0.121430184680557 0.866344058100564 0.392166836215666 0.0436217008797654],...
    'Orientation','horizontal', ...
    'box', 'on');
% title([ 'scenario'  currentFolder  ]);
ylabel('Daily minimum percent of hypoxia');
xlabel('Inflow rate (m^{3}/s)');

x1 = FlowINnonStorm.Data;
y = Hypoxia_MinnonStorm.Data;
X = [ones(size(x1)) x1 ];
[bnonStorm_Q_Y, bint_Q_Y, r_Q_Y, rint_Q_Y, statsnonStorm_Q_Y] = regress(y,X)  ;

x1 = FlowINStorm.Data;
y = Hypoxia_MinStorm.Data;
X = [ones(size(x1)) x1 ];
[bStorm_Q_Y, bint_Q_Y, r_Q_Y, rint_Q_Y, statsStorm_Q_Y] = regress(y,X)  ;

x1 = FlowIN.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 ];
[b_Q_Y, bint_Q_Y, r_Q_Y, rint_Q_Y, stats_Q_Y] = regress(y,X)  ;

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2_waterTemp_flow'],'png');
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2_ waterTemp_flow'],'fig');



% figure
% 
% % set(pp, 'XScale','log');
%  set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 20; ySize = 10;
% xLeft = 0; yTop = 0;
% 
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% % saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2 _Flow'],'png');
% % saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2_Flow'],'fig');




figure
scatter3(TempDailyMeannonStorm.Data, FlowINnonStorm.Data, Hypoxia_MinnonStorm.Data,'*b')
hold on
scatter3(TempDailyMeanStorm.Data,  FlowINStorm.Data,   Hypoxia_MinStorm.Data,'*r')
hold on
grid on 
xlabel(' Water temp (^{\circ}C)', 'Rotation',30);
ylabel('Inflow rate (m^{3}/s)', 'Rotation',-30);
zlabel('Daily minimum percent of hypoxia');

leg1 = legend('Non storm period','Storm event');
set(leg1,...
    'Position',[0.22104526958291 0.645307917888567 0.219226856561546 0.0773460410557185]);

title([ 'scenario'  currentFolder  ]);
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2 _Flow waterTemp_double'],'png');
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2_Flow waterTemp_double'],'fig');

% non storm 
x1 = TempDailyMeannonStorm.Data;
x2 = FlowINnonStorm.Data;    % Contains NaN data
y = Hypoxia_MinnonStorm.Data;
X = [ones(size(x1)) x1 x2 ];
[bnonStorm_WT_Q_Y,bint,r,rint,statsnonStorm_WT_Q_Y] = regress(y,X)  ;


%
x1 = TempDailyMeanStorm.Data;
x2 = FlowINStorm.Data;    % Contains NaN data
y = Hypoxia_MinStorm.Data;
X = [ones(size(x1)) x1 x2 ];
[bStorm_WT_Q_Y,bint,r,rint,statsStorm_WT_Q_Y] = regress(y,X)  ;

x1 = TempDailyMean.Data;
x2 =FlowIN.Data;    % Contains NaN data
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 x2 ];
[bWhole_WT_Q_Y,bint,r,rint,statsWhole_WT_Q_Y] = regress(y,X) ; 


% figure
% scatter3(x1,x2,y,'filled')
% hold on

fileBC =  [ dicmodel currentFolder   '\BCs\'   'Met_sourthPerth_2005_2018.csv' ];
fid = fopen(fileBC ,'rt');
str = repmat('%f ', [1 7] );
data = textscan(fid, ['%s' str], 'Headerlines',1,'Delimiter',',');
ISOTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
SolarRadiation.Date = ISOTime;
SolarRadiation.Data = data{1,6}; % w/m2

SolarRadiationDay  = dailyCummulativeRadiation(SolarRadiation); %  % the unit will be kJ

ss =  find(     sTime <= SolarRadiationDay.Date & SolarRadiationDay.Date <=  eTime );
SolarRadiationDayPeriod.Date = SolarRadiationDay.Date(ss);
SolarRadiationDayPeriod.Data = SolarRadiationDay.Data(ss);




x1 = TempDailyMean.Data;
x2 = FlowIN.Data;    % Contains NaN data
x3 = SolarRadiationDayPeriod.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 x2 x3 ];
[bWhole_AT_Q_SR_Y, bint, r,  rint, statsWhole_AT_Q_SR_Y] = regress(y,X) ; 



%%%%%

WindSpeed.Date = anvil.Met.DAFWA.LRD.southPerth.SP.mDate;

WindSpeed.Data = anvil.Met.DAFWA.LRD.southPerth.SP.WS * 1000 /3600;% m/s

WindSpeedDay  = dailyDelta(WindSpeed); %  % the unit will be m/s
WindSpeedDailyMean.Date =  WindSpeedDay.Date;
WindSpeedDailyMean.Data = WindSpeedDay.varMean;% average wind speed every day. m/s

ss =  find(     sTime <= WindSpeedDailyMean.Date & WindSpeedDailyMean.Date <=  eTime );
WindSpeedDayPeriod.Date = WindSpeedDailyMean.Date(ss);
WindSpeedDayPeriod.Data = WindSpeedDailyMean.Data(ss);

figure
plot(WindSpeedDayPeriod.Data   ,Hypoxia_Min.Data, '*'  )

x1 = TempDailyMean.Data;
x2 = FlowIN.Data;    % Contains NaN data
x3 = WindSpeedDayPeriod.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 x2 x3 ];
[bWhole_WT_Q_WS_Y,bint,r,rint,statsWhole_WT_Q_WS_Y] = regress(y,X) ; 



x1 = TempDailyMean.Data;
x2 = FlowIN.Data;    % Contains NaN data
 x3 = SolarRadiationDayPeriod.Data;
x4 = WindSpeedDayPeriod.Data;
y = Hypoxia_Min.Data;
X = [ones(size(x1)) x1 x2 x3  x4 ];
[bWhole_WT_Q_SR_WS_Y,bint,r,rint, statsWhole_WT_Q__SR_WS_Y] = regress(y,X) ; 