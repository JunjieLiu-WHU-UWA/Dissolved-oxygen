% --- - This script is to  calibriate flow, water temperature and DO
% together.


% clearvars -except anvil
% close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead


fileOutput =  [dicmodel currentFolder '\Output\'  ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

% obeserved data flow
%flow
 obseveWeirFlow = anvil.Hydrology.MSANVCBOUT.HRD.Route.YY2015.Discharge_5min_Mean;
 ss =  find (   sTime <=  obseveWeirFlow.Date  & obseveWeirFlow.Date <= eTime  );
 observeWeirFlow0405.Date = obseveWeirFlow.Date(ss,1);
 observeWeirFlow0405.Data = obseveWeirFlow.Data(ss,1);
 % water temperature
 obMidTemp = anvil.SWQ.Main_stream.Temperature;
 ssMidTemp = find( sTime <=obMidTemp.Date  & obMidTemp.Date <= eTime);
  obMidTemp0405.Date = obMidTemp.Date(ssMidTemp,1 );
 obMidTemp0405.Data = obMidTemp.Data(ssMidTemp,1);
 %DO
 obMidOxy = anvil.SWQ.Main_stream.Dissolved_Oxygen;
ssMidDO = find( sTime <=obMidOxy.Date  & obMidOxy.Date <= eTime);
  obMidOxy0405.Date = obMidOxy.Date(ssMidDO,1 );
 obMidOxy0405.Data = obMidOxy.Data(ssMidDO,1);
 
 % read the modelled data
 
 %flow
 file = [ fileOutput '2. Flow\Outflow_weir_10min.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Flow_weir_10min.Date =  dateTime;
Flow_weir_10min.Data =  data{1,2};
% water temperature
 file = [ fileOutput '3. Temperature\WaterTemperatureSensorDepth_10min.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
TempSensor_mid_10min.Date =  dateTime;
TempSensor_mid_10min.Data =  data{1,2};

% oxygen
 file = [ fileOutput '4. Oxygen\DissolvedOxygenSensorDepth_10min.csv'];
fid = fopen(file,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
OxySensor_mid_10min.Date =  dateTime;
OxySensor_mid_10min.Data =  data{1,2};


%%%%%%%%%%%%%%%%%%%%%%

figure
subplot(3, 1, 1)
pp =  plot(observeWeirFlow0405.Date, observeWeirFlow0405.Data, 'b*')
 hold on
 set(pp,'MarkerSize',2.0 );
pp = plot(Flow_weir_10min.Date, Flow_weir_10min.Data, 'r') 
 hold on
 leg1 = legend('Measured',  'Modelled');
 set(leg1,'Location','northwest');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',''  );
% title([ currentFolder '     discharge at  weir']);
xlim([sTime  eTime]);
ylabel('Flowrate (m^{3}/s)'); 
% xlabel('Date (2015)');
grid on 
 text(0.01,1.1,'(a) ','units','normalized');
subplot(3, 1, 2)

pp = plot(obMidTemp0405.Date,  obMidTemp0405.Data,'b*' );
hold on
set(pp,'MarkerSize',2.0 );
plot(TempSensor_mid_10min.Date,  TempSensor_mid_10min.Data,'r' );
hold on 
  AddShade([10 10], [25  25], period  )
% leg1 = legend('Observe', 'Modelled  temperature at sensor stage');
% set(leg1,'Location','southwest');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',''  );
% title([  currentFolder ' Temp of sensor stage at mid channel ']);
xlim([sTime  eTime]);
ylabel('Water temp (^{\circ}C)'); 
% xlabel('Date (2015)');
grid on 
 text(0.01,1.1,'(b) ','units','normalized');
subplot(3, 1, 3)

pp = plot(obMidOxy0405.Date,  obMidOxy0405.Data,'b*' );
hold on
set(pp,'MarkerSize',2.0 );
plot(OxySensor_mid_10min.Date,  OxySensor_mid_10min.Data,'r' );
hold on 
  AddShade([0 0], [10  10], period  )

% leg1 = legend('Observed oxygen', 'Modelled oxygen');
% set(leg1,'Position',[0.294456066945607 0.803539019963702 0.228556485355648 0.0957350272232304]);
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% title([  currentFolder ' Oxy of sensor stage at mid channel ']);
xlim([sTime  eTime]);
ylim([ 0   10]);
ylabel('DO (mg/L)'); 
xlabel('Date (2015)');
grid on 
 text(0.01,1.1,'(c) ','units','normalized');


 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 15;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf,[fileOutput  'Calibriation flow water temp Oxy'],'png');
print(gcf,[fileOutput   'fig 5 Calibriation flow water temp Oxy.tiff'],'-dtiff','-r300');
print(gcf,[fileOutput   'fig 5 Calibriation flow water temp Oxy.png'],'-dpng','-r300');
% saveas(gcf,[fileOutput  'Model Oxy of sensor stage and Observe Oxy at mid'],'fig');


figure

subplot(2, 2, 1);
 odd_len = (1: 2: length(observeWeirFlow0405.Data))';
pp = plot(observeWeirFlow0405.Data( odd_len) , Flow_weir_10min.Data, 'b*')
 hold on
 set(pp,'MarkerSize',2.0 );

 xlabel('Measured flowrate (m^{3}/s )');

      ylabel('Modelled flowrate (m^{3}/s )');
        xlim( [ 0  1.2 ]);
        ylim([ 0 1.2]);
      hline = refline(1,0);
      hline.Color = 'r';
      grid on
  text(0.01,1.1,'(a) ','units','normalized');
 
subplot(2, 2, 2);
lengOb = min([length(obMidTemp0405.Data) length(TempSensor_mid_10min.Data)]);
pp = plot(obMidTemp0405.Data,  TempSensor_mid_10min.Data(1:lengOb),'b*' );
hold on
set(pp,'MarkerSize',2.0 );
    xlabel('Measured temperature (^{\circ}C )');
      ylabel('Modelled temperature (^{\circ}C )');
      hline = refline(1,0);
      hline.Color = 'r';
      grid on
 text(0.01,1.1,'(b) ','units','normalized');
subplot(2, 2, 3);

pp = plot( obMidOxy0405.Data ,  OxySensor_mid_10min.Data(1:lengOb),'b*' );
hold on
set(pp,'MarkerSize',2.0 );

   xlabel('Measured DO (mg/L )');
      ylabel('Modelled DO (mg/L)');
      hline = refline(1,0);
      hline.Color = 'r';
      grid on
   text(0.01,1.1,'(c) ','units','normalized');    
%             title( [ currentFolder  'correlation oxygen ']);
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 15;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
  
% saveas(gcf,[fileOutput 'correlation observed and modelled oxygen '],'fig');
% saveas(gcf, [fileOutput 'correlation observed and modelled oxygen'],'png');
print(gcf,[fileOutput   'Fig S correlation observed and modelled flow water temp Oxy.tiff'],'-dtiff','-r300');
print(gcf,[fileOutput   'Fig S correlation observed and modelledflow water temp Oxy.png'],'-dpng','-r300');