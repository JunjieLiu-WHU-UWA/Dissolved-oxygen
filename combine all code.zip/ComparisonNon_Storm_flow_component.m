
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
file =  [dicmodel currentFolder '\Output\' ];
FlowIn = [ file '2. Flow\FlowInDaily_wholeWetland.csv'];
fid = fopen(FlowIn,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
FlowIN.Date = dateTime;
FlowIN.Data = data{1,2}; % the unit is m3/s

[ FlowINnonStorm,  FlowINStorm ]   = divide2period( FlowIN);

fileDO = [ file '5. Atmospheric flux\AtmFluxDaily_rate_wholeWetland.csv'];
fid = fopen(fileDO,'rt');
data = textscan(fid,'%s %f','Headerlines',1 , 'Delimiter', ',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
AtmFluxDaily.Date = dateTime;
AtmFluxDaily.Data = data{1,2}; % g/m2/d


[ AtmFluxDailynonStorm,  AtmFluxDailyStorm ]   = divide2period( AtmFluxDaily);
[h_AtmFlux,p_AtmFlux, ci, stats] = ttest2(AtmFluxDailynonStorm.Data,   AtmFluxDailyStorm.Data);
% h_FlowIN is  1, reject null hypothesis and 0 accept null hypothesis
fileSOD = [ file '6. Sediment Oxygen demand\SedOxyDaily_rate_wholeWetland.csv'];
fid = fopen(fileSOD,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
SedOxyDaily.Date = dateTime;
SedOxyDaily.Data = data{1,2};

[ SedOxyDailynonStorm,  SedOxyDailyStorm ]   = divide2period( SedOxyDaily);
[h_SedOxy,p_SedOxy, ci, stats] = ttest2(SedOxyDailynonStorm.Data,  SedOxyDailyStorm.Data);

filePelagic = [ file '7. Pelagic productivity\PelagicNetProductivityDaily_rate_wholeWetland.csv'];
fid = fopen(filePelagic,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
PelagicNetProdDaily.Date = dateTime;
PelagicNetProdDaily.Data = data{1,2};

[ PelagicNetProdDailynonStorm,  PelagicNetProdDailyStorm ]   = divide2period( PelagicNetProdDaily);
[h_PelagicProd,p_PelagicProd, ci, stats] = ...
ttest2(PelagicNetProdDailynonStorm.Data,  PelagicNetProdDailyStorm.Data);

fileBenProd = [ file '8. Benthic productivity\BenthicNetProductivityDaily_rate_wholeWetland.csv'];
fid = fopen(fileBenProd,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
BenthicProdDaily.Date = dateTime;
BenthicProdDaily.Data = data{1,2};

[ BenthicProdDailynonStorm,  BenthicProdDailyStorm ]   = divide2period( BenthicProdDaily);

[h_BenthicProd,p_BenthicProd, ci, stats] = ttest2(BenthicProdDailynonStorm.Data,  BenthicProdDailyStorm.Data);

fileMinerDOC = [ file '9. Carbon mineralisation\mineralisationDOCDaily_rate_wholeWetland.csv'];
fid = fopen(fileMinerDOC,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
MinerDOCDaily.Date = dateTime;
MinerDOCDaily.Data = data{1,2};

[ MinerDOCDailynonStorm,  MinerDOCDailyStorm ]   = divide2period( MinerDOCDaily);

[h_MinerDOC,p_MinerDOC, ci, stats] = ttest2(MinerDOCDailynonStorm.Data,  MinerDOCDailyStorm.Data);

%
fileNitrifNH4 = [ file '10. Nitrogen nitrification\nitirificationDaily_rate_wholeWetland.csv'];
fid = fopen(fileNitrifNH4,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
NitrifNH4Daily.Date = dateTime;
NitrifNH4Daily.Data = data{1,2};
[ NitrifNH4DailynonStorm,  NitrifNH4DailyStorm ]   = divide2period( NitrifNH4Daily);

lenNonStorm = length(FlowINnonStorm.Data  );
lenStorm = length(FlowINStorm.Data );
grp = [zeros(lenNonStorm, 1) ; ones( lenStorm, 1)];

fig1 = figure
FlowINBox = [FlowINnonStorm.Data ; FlowINStorm.Data];
boxplot(FlowINBox,grp)
ylabel({'Inflow rate (m^{3}/s)'});
set(gca, 'XTickLabel', '');
line([  1.5  1.5], [0  0.5], 'Color',[0 0 0]);
annotation(fig1,'textbox',...
    [0.261242375615591 0.763987991646363 0.280334728033473 0.079882352941177],...
    'String',{'Nonstorm period'},...
    'FitBoxToText','off',...
    'EdgeColor',[1 1 1]);


annotation(fig1,'textbox',...
    [0.64121338912134 0.784926470588239 0.280334728033472 0.0798823529411775],...
    'String',{'Storm event'},...
    'FitBoxToText','off',...
    'EdgeColor',[1 1 1]);



[h_FlowIN,p_FlowIN, ci, stats] = ttest2(FlowINnonStorm.Data,   FlowINStorm.Data);

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 6; ySize = 8;
xLeft = 0; yTop = 0;
set(gcf, 'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   'Comparison of  non storm flow'],'jpg');
saveas(gcf, [file   'Comparison of  non storm flow'],'fig');
%-------------------------------------
% 
all_box = [AtmFluxDailynonStorm.Data;   PelagicNetProdDailynonStorm.Data ; ...
                  BenthicProdDailynonStorm.Data;   SedOxyDailynonStorm.Data; ...
                  MinerDOCDailynonStorm.Data;   ...
                  AtmFluxDailyStorm.Data;   PelagicNetProdDailyStorm.Data ; ...
                  BenthicProdDailyStorm.Data;   SedOxyDailyStorm.Data; 
                  MinerDOCDailyStorm.Data  ]; % g O2 /m2 /d

% all_grp = [  ones( lenNonStorm, 1) *10;  ones( lenNonStorm, 1) * 9;...
%                    ones( lenNonStorm, 1) *8;  ones( lenNonStorm, 1) *7;  ...
%                    ones( lenNonStorm, 1) *6;   ...
%                      ones( lenStorm, 1) * 5; ones( lenStorm, 1) * 4; ...
%                   ones( lenStorm, 1) * 3;   ones( lenStorm, 1) *2; ...
%                     ones( lenStorm, 1) * 1  ];

all_grp = [  ones( lenNonStorm, 1) *1;  ones( lenNonStorm, 1) * 2;...
                   ones( lenNonStorm, 1) *3;  ones( lenNonStorm, 1) *4;  ...
                   ones( lenNonStorm, 1) *5;   ...
                     ones( lenStorm, 1) * 6; ones( lenStorm, 1) * 7; ...
                  ones( lenStorm, 1) * 8;   ones( lenStorm, 1) *9; ...
                    ones( lenStorm, 1) * 10;  ];

f = figure
f.Renderer = 'painters';
boxplot(all_box, all_grp);
% color_fig = { [ 0  0.4470  0.7410] , 'r' , 'c', 'm','b', 'g', 'y', 'r' , 'c', 'm'};
color_fig = { 'c' , 'r' , 'y', 'g', [ 0  0.4470  0.7410] , 'c' , 'r' , 'y', 'g', [ 0  0.4470  0.7410]  };
% the sequece is reversible to that of data
h = findobj(gca,'Tag','Box');
for j=1:length(h)
   patch(get(h(j),'XData'),get(h(j),'YData'),color_fig{j},'FaceAlpha',0.5);
%    line(get(h(j),'Tag','Median','Color',[0 0 0]);
end


set(findobj(gcf,'tag','Median'), 'Color', [ 0 0 0]);
set(findobj(gcf,'tag','Box'), 'Color', [ 0 0 0 ]);

h = findobj(gcf,'tag','Outliers');
for iH = 1:length(h)
    h(iH).MarkerEdgeColor =  [0 0 0 ];
end
%   legend( 'Mineraliation' ,  'SOD', 'BNEP','PNEP',   'Atmospheric flux');
% reorderLegend;

line([  3.5  3.5], [-1.5  2.0], 'Color',[0 0 0]);
line([  5.5  5.5], [-1.5  3.0], 'Color',[0 0 0]);
line([  8.5  8.5], [-1.5  2.0], 'Color',[0 0 0]);

set(gca,'XTick',[  2.0  4.5  7.0  9.5 ], 'XTickLabel',{'Inputs', ...
                                                          'Outputs', ...
                                                          'Inputs', ...
                                                          'Outputs'});

ylabel({'g O_{2}/m^{2}/d'});
annotation(f,'textbox',...
      [0.150559511698881 0.837518463810931 0.363173957273652 0.0595612998522896],...
    'String',{'Non-storm period'},...
    'FitBoxToText','off', ...
     'EdgeColor',[1 1 1]);

annotation(f,'textbox',...
    [0.531027466937947 0.840472673559823 0.196337741607324 0.0595612998522896],...
    'String','Storm event',...
    'FitBoxToText','off',...
    'EdgeColor',[1 1 1]);

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 6;
xLeft = 0; yTop = 0;
set(gcf, 'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file   'Comparison of four component non storm'],'jpg');
% saveas(gcf, [file   'Comparison of four component non storm'],'fig');


% print(gcf,[ file 'fig 7 Comparison of four component non storm.tiff'],'-dtiff','-r300');
print(gcf,[file 'fig 7 Comparison of four component non storm_inputs.png'],'-dpng','-r300');
%
%-----------effect of flowrate on component
color_nonStorm = [0 0 1];
color_Storm = [1 0 0];


figure
% subplot(2,1,1)
h(1) = semilogx( FlowINnonStorm.Data,  SedOxyDailynonStorm.Data , '*');
hold on
h(2) = semilogx( FlowINStorm.Data  ,SedOxyDailyStorm.Data  , 'or');
hold on
PositionEq =  [0.42429591762901 0.225719198698156 0.60308007253008 0.122040072859745];
plotTrendLine(    FlowINStorm.Data  ,  SedOxyDailyStorm.Data, 'poly1', ... 
color_Storm, PositionEq) ;
leg1 = legend(h(1:2), 'Non storm period','Storm event');

% set(leg1,  'Location','best');
set(leg1,'Position',[0.302140556120719 0.843144989339024 0.219226856561546 0.0787313432835821], ...
    'FontSize',6)
ylabel('SOD (g O_{2}/m^{2}/d)');
xlabel('Inflow rate (m^{3}/s)');


 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [file   'EffectFlowrateOnSOD'],'jpg');
% saveas(gcf, [file   'EffectFlowrateOnSOD'],'fig');

print(gcf,[ file 'fig 8 EffectFlowrateOnSOD.tiff'],'-dtiff','-r300');
print(gcf,[file 'fig 8 EffectFlowrateOnSOD.png'],'-dpng','-r300');

%%%%%%%%%%%%%%%

% [eq, gof, output ] = fit(xxx,yyy,var); %poly1 is Linear polynomial curve


%% log regression

gcf  =  figure
% subplot(2,1,1)
h(1) = semilogx( FlowINnonStorm.Data,  SedOxyDailynonStorm.Data , '*');
hold on
h(2) = semilogx( FlowINStorm.Data  ,SedOxyDailyStorm.Data  , 'or', 'MarkerSize',4);
hold on

% PositionEq =  [0.42429591762901 0.225719198698156 0.60308007253008 0.122040072859745];
% plotTrendLine(    FlowINStorm.Data  ,  SedOxyDailyStorm.Data, 'poly1', ... 
% color_Storm, PositionEq) ;

% hold on 
% PositionEq =  [0.42429591762901 0.225719198698156 0.60308007253008 0.122040072859745];
% plotTrendLine(    log(FlowIN.Data)  ,  log(SedOxyDaily.Data), 'poly1', ... 
% color_Storm, PositionEq) ;

% [eq, gof, output ] = fitlm(log(FlowIN.Data) ,log(SedOxyDaily.Data),'poly1');
mdl  = fitlm(log(FlowIN.Data) ,log(SedOxyDaily.Data));

xxx = log(FlowIN.Data);
outEquation.x = (min(xxx) : (max(xxx) - min(xxx)) /100:max(xxx))';
outEquation.y = eq(outEquation.x);

outEquation.y = mdl.Coefficients.Estimate(2).*outEquation.x +mdl.Coefficients.Estimate(1) ;
% mdl.Estimated.Coefficients
% mdl.Coefficients.Estimate(2)
semilogx(exp(outEquation.x), exp(outEquation.y), 'k');
% figure
% loglog(exp(outEquation.x), exp(outEquation.y), 'k');
hold on

xlim([ 0.001  10]);
ylim([0  4 ])
axis equal
annotation( gcf ,'textbox',...
 [0.258228363914113 0.61072986015229 0.658734219269104 0.153846153846154],...
    'String',{'ln(y) = 0.1565 ln(x) + 0.7383','R^{2} = 0.1211'},...
    'FitBoxToText','off',  'EdgeColor',[1 1 1], 'FontSize',6 );
% %  annotation(gcf,'textbox',...
%    PositionEq,...
%       'Color',[ 1 1 1], ...
%        'String',{['ln(y) = 0.1565 ln(x) + 0.7383']},...
%     'FitBoxToText','off', ...
%     'FaceAlpha',0, ...
%     'EdgeColor',[1 1 1]);
leg1 = legend(h(1:2), 'Non storm period','Storm event');
% set(leg1,  'Location','best');
set(leg1,'Position',[0.528453499898008 0.299401238533994 0.172431332655137 0.100798551481447], ...
    'FontSize',6)
ylabel('SOD (g O_{2}/m^{2}/d)');
xlabel('Inflow rate (m^{3}/s)');


 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 8; ySize = 8;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
print(gcf,[file 'fig 8 EffectFlowrateOnSOD_logFit.png'],'-dpng','-r300');

%%%%%%%%%%%%%%%
% 
% [eq, gof, output ] = fit(xxx,yyy,var); %poly1 is Linear polynomial curve









% calculate the median  during non storm period % g O2 /m2 /d
% AtmFluxDaily
componentOxyMedian_nonStorm(1 , 1 ) =  median(AtmFluxDailynonStorm.Data );
% PelagicProdDaily
componentOxyMedian_nonStorm(2 , 1 ) =  median(PelagicNetProdDailynonStorm.Data   );
% BenthicProdDaily
componentOxyMedian_nonStorm(3 , 1 ) =  median(BenthicProdDailynonStorm.Data );
% SedOxyDaily
componentOxyMedian_nonStorm(4 , 1 ) =  median(SedOxyDailynonStorm.Data );
% MinerDOCDaily
componentOxyMedian_nonStorm(5 , 1 ) =  median(MinerDOCDailynonStorm.Data); 


  
% calculate the median  during storm period % g O2 /m2 /d
% AtmFluxDaily
componentOxyMedian_Storm(1 , 1 ) =  median(AtmFluxDailyStorm.Data );
% PelagicProdDaily
componentOxyMedian_Storm(2 , 1 ) =  median(PelagicNetProdDailyStorm.Data   );
% BenthicProdDaily
componentOxyMedian_Storm(3 , 1 ) =  median(BenthicProdDailyStorm.Data );
% SedOxyDaily
componentOxyMedian_Storm(4 , 1 ) =  median(SedOxyDailyStorm.Data );
% MinerDOCDaily
componentOxyMedian_Storm(5 , 1 ) =  median(MinerDOCDailyStorm.Data); 


% calculate the median  during whole period % g O2 /m2 /d
% AtmFluxDaily
componentOxyMedian_whole(1 , 1 ) =  median(AtmFluxDaily.Data );
% PelagicProdDaily
componentOxyMedian_whole(2 , 1 ) =  median(PelagicNetProdDaily.Data   );
% BenthicProdDaily
componentOxyMedian_whole(3 , 1 ) =  median(BenthicProdDaily.Data );
% SedOxyDaily
componentOxyMedian_whole(4 , 1 ) =  median(SedOxyDaily.Data );
% MinerDOCDaily
componentOxyMedian_whole(5 , 1 ) =  median(MinerDOCDaily.Data); 


%---------------Write  component    into file ---------------------------------------------------------
 filename = [ file 'Component_Oxy_non_storm.csv'];
fid = fopen(filename,'wt');
fprintf(fid, ...
  'species (g O2 /m2/d), AtmFlux , Pelagic net production, Benthic net production,sediment oxygen demand, mineralisation\n');
fprintf(fid,'Component_Oxy_nonStorm,');
for ii = 1 : length(componentOxyMedian_nonStorm)
     if  ii == length(componentOxyMedian_nonStorm)
         
          fprintf(fid,'%4.4f\n ',    componentOxyMedian_nonStorm(ii));
     else
 fprintf(fid,'%4.4f, ',    componentOxyMedian_nonStorm(ii));
     end

 
end
fprintf(fid,'Component_Oxy_Storm,');
for ii = 1 : length(componentOxyMedian_Storm)
     if  ii == length(componentOxyMedian_Storm)
         
          fprintf(fid,'%4.4f\n ',    componentOxyMedian_Storm(ii));
     else
 fprintf(fid,'%4.4f, ',    componentOxyMedian_Storm(ii));
     end

 
end

fprintf(fid,'Component_Oxy_whole,');
for ii = 1 : length(componentOxyMedian_whole)
     if  ii == length(componentOxyMedian_whole)
         
          fprintf(fid,'%4.4f\n ',    componentOxyMedian_whole(ii));
     else
 fprintf(fid,'%4.4f, ',    componentOxyMedian_whole(ii));
     end

 
end

fclose(fid);

