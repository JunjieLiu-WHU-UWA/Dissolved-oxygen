% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead

file =  [dicmodel currentFolder '\Output\' ];
FlowIn = [ file '2. Flow\FlowInDaily_wholeWetland.csv'];
fid = fopen(FlowIn,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
FlowIN.Date = dateTime;
FlowIN.Data = data{1,2}; % the unit is m3/s
[ FlowINnonStorm,  FlowINStorm ]   = divide2period( FlowIN);

fileHypoxia = [ file '4. Oxygen\Hypoxia_DepthAveDay_daily.csv'];
fid = fopen(fileHypoxia,'rt');
data = textscan(fid,'%s %f %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
Hypoxia_Min.Date = dateTime;
Hypoxia_Min.Data = data{1,3}; % the minium  percent
[ Hypoxia_MinnonStorm,  Hypoxia_MinStorm ]   = divide2period( Hypoxia_Min);

fileDenitri = [ file '4. Oxygen\Denitri_DepthAveDay_daily.csv'];
fid = fopen(fileDenitri,'rt');
data = textscan(fid,'%s %f %f %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
Denitri_Max.Date = dateTime;
Denitri_Max.Data = data{1,2}; % the maximum percent
[ Denitri_MaxnonStorm,  Denitri_MaxStorm ]   = divide2period( Denitri_Max);

figure

h(1) = semilogx(FlowINnonStorm.Data  ,  Hypoxia_MinnonStorm.Data, '*b');
hold on

h(2) = semilogx( FlowINStorm.Data  ,  Hypoxia_MinStorm.Data, '*r');
hold on

leg1 = legend(h(1:2), 'Non storm period','Storm event');
set(leg1,'Position',[0.121430184680557 0.866375991995791 0.392166836215666 0.0435578330893118],...
    'Orientation','horizontal', ...
    'box', 'off');
title([ 'scenario'  currentFolder  ]);
ylabel('Daily minimum percent of hypoxia');
xlabel('Inflow rate (m^{3}/s)');
% set(pp, 'XScale','log');
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2 _Flow'],'png');
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  2_Flow'],'fig');



% for indicative of denitirfication
figure
h(1) = semilogx(FlowINnonStorm.Data  ,  Denitri_MaxnonStorm.Data, 'ob');
hold on

h(2) = semilogx( FlowINStorm.Data  ,  Denitri_MaxStorm.Data, 'or');
hold on
leg1 = legend(h(1:2), 'Non storm period','Storm event');
set(leg1,'Position',[0.128551242666313 0.340785577758637 0.392166836215666 0.0434941520467835],...
    'Orientation','horizontal', ...
    'box', 'off');
title([ 'scenario'  currentFolder  ]);
ylabel('Daily maximum percent for denitrification');
xlabel('Inflow rate (m^{3}/s)');
% set(pp, 'XScale','log');
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  0 5 _Flow'],'png');
saveas(gcf, [file   ' RelationshipTwoPeriod_daily percent  0 5_Flow'],'fig');
