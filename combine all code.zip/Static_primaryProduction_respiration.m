clc


addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead

% calculate the daily pelagic primary production 
file = [dicmodel  currentFolder '\Output\'];
filePela = [ file '7. Pelagic productivity\Pelagic primary productivity_wholeWetland.csv'];
fid = fopen(filePela,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
PelaPrimaryPro.Date = dateTime;
PelaPrimaryPro.Data = data{1,3};

PelaPrimaryProDaily = dailySum(PelaPrimaryPro);
filePelaDaily = [ file '7. Pelagic productivity\PelagicPrimaryProductivityDaily_rate_wholeWetland.csv'];
writeDaily(PelaPrimaryProDaily,  filePelaDaily  ,  'PelagicPrimaryProductivityDaily(g O2/m2 /d)'  );


[ PelaPrimaryProDailynonStorm,  PelaPrimaryProDailyStorm ]   = divide2period( PelaPrimaryProDaily);
[h_PelaPrimaryProDaily, p_PelaPrimaryProDaily, ci, stats] = ...
ttest2(PelaPrimaryProDailynonStorm.Data,  PelaPrimaryProDailyStorm.Data);



% pelagic respiration
filePela = [ file '7. Pelagic productivity\Pelagic reapiration_wholeWetland.csv'];
fid = fopen(filePela,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
PelaRes.Date = dateTime;
PelaRes.Data = data{1,3};

PelaResDaily = dailySum(PelaRes);
filePelaDaily = [ file '7. Pelagic productivity\PelagicRespirationDaily_rate_wholeWetland.csv'];
writeDaily(PelaResDaily,  filePelaDaily  ,  'PelagicRespirationDaily(g O2/m2 /d)'  );


[ PelaResDailynonStorm,  PelaResDailyStorm ]   = divide2period( PelaResDaily);
[h_PelaResDaily, p_PelaResDaily, ci, stats] = ...
ttest2(PelaResDailynonStorm.Data,  PelaResDailyStorm.Data);

% bethic primary production
fileBen = [ file '8. Benthic productivity\BenthicGPP_wholeWetland.csv'];
fid = fopen(fileBen,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
BenPrimaryPro.Date = dateTime;
BenPrimaryPro.Data = data{1,3};

BenPrimaryProDaily = dailySum(BenPrimaryPro);
fileBenDaily = [ file '8. Benthic productivity\BenthicPrimaryProductivityDaily_rate_wholeWetland.csv'];
writeDaily(BenPrimaryProDaily,  fileBenDaily  ,  'BenthicPrimaryProductivityDaily(g O2/m2 /d)'  );


[ BenPrimaryProDailynonStorm,  BenPrimaryProDailyStorm ]   = divide2period( BenPrimaryProDaily);

[h_BenPrimaryProDaily,p_BenPrimaryProDaily, ci, stats] = ...
    ttest2(BenPrimaryProDailynonStorm.Data,  BenPrimaryProDailyStorm.Data);




% bethic respriation
fileBen = [ file '8. Benthic productivity\Benthic  respiration_wholeWetland.csv'];
fid = fopen(fileBen,'rt');
data = textscan(fid,'%s %f %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
BenRespiration.Date = dateTime;
BenRespiration.Data = data{1,3};

BenRespirationDaily = dailySum(BenRespiration);
fileBenDaily = [ file '8. Benthic productivity\BenthicRespirationDaily_rate_wholeWetland.csv'];
writeDaily(BenRespirationDaily,  fileBenDaily  ,  'BenthicRespirationDaily(g O2/m2 /d)'  );


[ BenRespirationDailynonStorm,  BenRespirationDailyStorm ]   = divide2period( BenRespirationDaily);

[h_BenRespirationDaily,p_BenRespirationDaily, ci, stats] = ...
    ttest2(BenRespirationDailynonStorm.Data,  BenRespirationDailyStorm.Data);


PrimaryProductionResprition  = zeros(3, 4);

% nonstorm period
%pelagic primary production
PrimaryProductionResprition(1, 1) = median(PelaPrimaryProDailynonStorm.Data  ); 
% pelagic respiration
PrimaryProductionResprition(1, 2) = median(PelaResDailynonStorm.Data  ); 
% benthic primary production
PrimaryProductionResprition(1, 3) = median(BenPrimaryProDailynonStorm.Data  ); 
% benthic respiration
PrimaryProductionResprition(1, 4) = median(BenRespirationDailynonStorm.Data  ); 

% storm period

%pelagic primary production
PrimaryProductionResprition(2, 1) = median(PelaPrimaryProDailyStorm.Data  ); 
% pelagic respiration
PrimaryProductionResprition(2, 2) = median(PelaResDailyStorm.Data  ); 
% benthic primary production
PrimaryProductionResprition(2, 3) = median(BenPrimaryProDailyStorm.Data  ); 
% benthic respiration
PrimaryProductionResprition(2, 4) = median(BenRespirationDailyStorm.Data  ); 


% whole period

%pelagic primary production
PrimaryProductionResprition(3, 1) = median(PelaPrimaryProDaily.Data  ); 
% pelagic respiration
PrimaryProductionResprition(3, 2) = median(PelaResDaily.Data  ); 
% benthic primary production
PrimaryProductionResprition(3, 3) = median(BenPrimaryProDaily.Data  ); 
% benthic respiration
PrimaryProductionResprition(3, 4) = median(BenRespirationDaily.Data  ); 






%---------------Write  component    into file ---------------------------------------------------------
 filename = [ file 'PrimaryProductionResprition_benthicPelagic.csv'];
fid = fopen(filename,'wt');
fprintf(fid, ...
  'period (g O2 /m2/d), pelagic GPP , Pelagic respiration, Benthic GPP, Benthic respiration\n');
fprintf(fid,'nonStorm,');
for ii = 1 : length(PrimaryProductionResprition(1, :))
     if  ii == length(PrimaryProductionResprition(1, :))
         
          fprintf(fid,'%4.4f\n ',    PrimaryProductionResprition(1, ii));
     else
 fprintf(fid,'%4.4f, ',    PrimaryProductionResprition(1, ii));
     end

 
end
fprintf(fid,'Storm,');
for ii = 1 : length(PrimaryProductionResprition(2, :))
     if  ii == length(PrimaryProductionResprition(2, :))
         
          fprintf(fid,'%4.4f\n ',    PrimaryProductionResprition(2, ii));
     else
 fprintf(fid,'%4.4f, ',    PrimaryProductionResprition(2, ii));
     end

 
end


fprintf(fid,'Whole Period,');
for ii = 1 : length(PrimaryProductionResprition(3, :))
     if  ii == length(PrimaryProductionResprition(3, :))
         
          fprintf(fid,'%4.4f\n ',    PrimaryProductionResprition(3, ii));
     else
 fprintf(fid,'%4.4f, ',    PrimaryProductionResprition(3, ii));
     end

 
end

fclose(fid);