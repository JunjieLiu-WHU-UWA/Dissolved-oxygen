% this scrpit is to calculate minerlisation of Carbon.
% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% %  BasicRead
%--------------------------------------------------------
currentOutput = '9. Carbon mineralisation\'; 
OutputCarbon =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(OutputCarbon,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(OutputCarbon);           % if not exists, create the file of 'outdir'
end


varid = netcdf.inqVarID(ncid,'WQ_DIAG_OGM_POC_MINER');
OGM_POC_MINER = netcdf.getVar(ncid,varid) /1000* 32  ;  %mmol/m3/d to g O2 /m3/d; 

varid = netcdf.inqVarID(ncid,'WQ_DIAG_OGM_DOC_MINER');
OGM_DOC_MINER = netcdf.getVar(ncid,varid) /1000* 32  ;  %mmol/m3/d to g O2 /m3/d; 

[ OGM_POC_MINERSumSpace ,OGM_POC_MINERCVMean ]  = ThreeVolume2twoarea(OGM_POC_MINER, Basic, Cell_whole_channel);

[ OGM_DOC_MINERSumSpace ,OGM_DOC_MINERCVMean ]  = ThreeVolume2twoarea(OGM_DOC_MINER, Basic, Cell_whole_channel);




%---------------------------------------------------------------------------------------

figure
subplot(4,1,1)
plot(ResTime, OGM_POC_MINERSumSpace./ 1000) % kg/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mass flux of  decompostion of POC across the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Decompostion of POC' ' (kg O_{2}  /d)'})      
xlabel('Date (2015)');
grid on 

subplot(4,1,2)

plot(ResTime, OGM_POC_MINERCVMean)
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mean rate flux of  decompostion of POC across the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Decompostion of POC' ' (g O_{2} /m^{2}  /d)'})      
xlabel('Date (2015)');
grid on 

subplot(4,1,3)
plot(ResTime, OGM_DOC_MINERSumSpace./ 1000) % the unit is kg O2/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mass flux of  mineralisation of DOC across the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Mineraliastion of DOC' ' (kg O_{2}  /d)'})      
xlabel('Date (2015)');
grid on 



subplot(4,1,4)
plot(ResTime, OGM_DOC_MINERCVMean)

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mean rate flux of  mineralisation of DOC across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Mineralisation of DOC' ' (g O_{2} /m^{2}  /d)'})      
xlabel('Date (2015)');
grid on 


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 20;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[OutputCarbon 'Decompostion POC mineraliation DOC the whole wetland '],'png') ;
saveas(gcf,[OutputCarbon 'Decompostion POC mineraliation DOC  the whole wetland'],'fig');

filecsv =  [ OutputCarbon 'DeccomposittinPOCmineralisationDOC_wholeWetland.csv' ];
     fid = fopen(filecsv,'wt');

fprintf(fid,'ISOTime, POCSumSpace(gO2/d), POCCVmean(gO2/m2/d), DOCSumSpace(gO2/d), DOCCVmean(gO2/m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f,%4.4f,%4.4f \n', OGM_POC_MINERSumSpace(1,i), OGM_POC_MINERCVMean(1,i), ...
                                             OGM_DOC_MINERSumSpace(1,i), OGM_DOC_MINERCVMean(1,i)  );
end
fclose(fid);