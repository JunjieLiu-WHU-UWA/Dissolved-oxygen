% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information'); 
% BasicRead
% This script is to calibriate DOC and POC at inlet and outlet
currentOutput = '9. Carbon mineralisation\'; 
OutputCarbon =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(OutputCarbon,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(OutputCarbon);           % if not exists, create the file of 'outdir'
end
% calibriation of  DOC 
varid = netcdf.inqVarID(ncid,'WQ_OGM_DOC');
OGM_DOC = netcdf.getVar(ncid,varid)./1000 *12 ;   %the unit is mmol/m3/ , converted as mg/L 

%--------------------POC---------------------------------------------
varid = netcdf.inqVarID(ncid,'WQ_OGM_POC');
OGM_POC = netcdf.getVar(ncid,varid) /1000*12  ;  %mmol/m3/d to g/m3/d; 

% --------------------------inlet--------------------------------
OGM_DOC_inlet = OGM_DOC(idx2InletCell,:);

OGM_POC_inlet = OGM_POC(idx2InletCell,:);

ob_Inlet_DOC_04 = anvil.SWQ.MSANVCBIN.HRD.Storm_04.DOC;  % unit is mg/L

ob_Inlet_DOC_05 = anvil.SWQ.MSANVCBIN.HRD.Storm_05.DOC;  % unit is mg/L

DoW_DOC =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_OGM_DOC; % the unit is mmol/m3, 
ss_DOC = find(sTime  <=  DoW_DOC.Date  &    DoW_DOC.Date <= eTime );

 OutfigCalibriation( 'DOC', 'inlet', OutputCarbon , ob_Inlet_DOC_04, ob_Inlet_DOC_05,OGM_DOC_inlet  )

  
figure
plot(ResTime,OGM_POC_inlet );
hold on 
 leg1 = legend('Modelled 1 st layer', 'Modelled 2 nd layer', 'Modelled 3 st layer','Modelled 4 st layer' );
 set(leg1,...
    'Position',[0.37029501525941 0.372093023255814 0.238555442522889 0.145712209302326]);
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'concentration of POC at  inlet No observed POC']);
xlim([sTime  eTime]);
ylabel({' POC' ' (mg/L)'})      
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 5;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[OutputCarbon 'Calibration of POC at inlet'],'png') ;
saveas(gcf,[OutputCarbon 'Calibration of POC at inlet'],'fig');

%-----------------------------------------------------------------

figure
plot( DoW_DOC.Date, DoW_DOC.Data ./ 1000 *12,'s' ); % convert unit to mg/L
hold on 
datetick('x', 'yyyy')
% set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'concentration of DOC at inlet from Dow ']);
% xlim([sTime  eTime]);
ylabel({' DOC' ' (mg/L)'})      
% xlabel('Date (2015)');
grid on 

saveas(gcf,[OutputCarbon 'Concentration of DOC at inlet from Dow'],'png') ;
saveas(gcf,[OutputCarbon 'Concentration of DOC at inlet from Dow'],'fig');

%----------------------------------------------
OGM_DOC_weir = OGM_DOC(idx2weirCell,:);

OGM_POC_weir = OGM_POC(idx2weirCell,:);

ob_weir_DOC_04 = anvil.SWQ.MSANVCBOUT.HRD.Storm_04.DOC;  % unit is mg/L

ob_weir_DOC_05 = anvil.SWQ.MSANVCBOUT.HRD.Storm_05.DOC;  % unit is mg/L

DoW_DOC =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_OGM_DOC; % the unit is mmol/m3, 
ss_DOC = find(sTime  <=  DoW_DOC.Date  &    DoW_DOC.Date <= eTime );
OutfigCalibriation( 'DOC', 'outlet', OutputCarbon , ob_weir_DOC_04, ob_weir_DOC_05,OGM_DOC_weir  )
 
figure
plot(ResTime,OGM_POC_weir );
hold on 
 leg1 = legend('1 st layer', ' 2 nd layer', '3 st layer','4 st layer' );
set(leg1,...
    'Position',[0.244659206510681 0.21984011627907 0.609867751780264 0.0432412790697674],...
    'Orientation','horizontal')
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'concentration of POC at  weir No observed POC']);
xlim([sTime  eTime]);
ylabel({' POC' ' (mg/L)'})      
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 5;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[OutputCarbon 'Calibration of POC at weir'],'png') ;
saveas(gcf,[OutputCarbon 'Calibration of POC at weir'],'fig');