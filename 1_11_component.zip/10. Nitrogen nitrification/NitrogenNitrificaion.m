%
% This script is to calculate nitrification of oxygen 

% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% % BasicRead

%--------------------------------------------------------
currentOutput = '10. Nitrogen nitrification\'; 
OutputNitrogen =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(OutputNitrogen,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(OutputNitrogen);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_DIAG_NIT_NITRIF');
NIT_NITRIF = netcdf.getVar(ncid,varid) /1000* 32  ;  %mmol/m3/d to g O2 /m3/d; 
[ NIT_NITRIFSumSpace ,NIT_NITRIFCVMean ]  = ThreeVolume2twoarea(NIT_NITRIF, Basic, Cell_whole_channel);


figure
subplot(2,1,1)
plot(ResTime, NIT_NITRIFSumSpace./1000) % the unit is kg O2 /d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mass flux of  nitrification of DON across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Nitrification of DON' ' (kg O_{2}  /d)'})      
xlabel('Date (2015)');
grid on 
 
subplot(2,1,2)
plot(ResTime, NIT_NITRIFCVMean) % the unit is g /m2/d 
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mean rate flux of  nitrification of DON across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Nitrification of DON' ' (g O_{2} /m^{2}  /d'})      
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;
ySize = 20;
% xLeft = (21-xSize)/2;
% yTop = (30-ySize)/2;
xLeft = 0;
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[OutputNitrogen 'Nitrification of DON the whole wetland '],'png') ;
saveas(gcf,[OutputNitrogen 'Nitrification of DON the whole wetland'],'fig');

%---------------------------------------













%  
% varid = netcdf.inqVarID(ncid,'WQ_DIAG_NIT_NITRIF');
% NIT_NITRIF = netcdf.getVar(ncid,varid)  /1000 / 14 *32;
% % stoichiometric conersion of N to O2 is   14 /  32
% % the origianl unit is mmol /m3/d , after conversion , the unit is g O2/m3/d

 
% midchannel 727, 276 within control volume




     filecsv =  [ OutputNitrogen 'nitirification_wholeWetland.csv' ];
     fid = fopen(filecsv,'wt');

fprintf(fid,'ISOTime, NIT_NITRIFSumSpace (g O2/d ), NIT_NITRIFCVMean (g O2/m2/d)  \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f \n', NIT_NITRIFSumSpace(1,i), NIT_NITRIFCVMean(1,i));
end
fclose(fid);

% 
%      min(NIT_NITRIFCV(276,:))
%      figure
%      plot(ResTime, NIT_NITRIFCV(276,:) )
%      
%      datetick('x', 19)
% ylabel({' nitirification  '   'at mid channel(g/m2/d)'})  
%      
%         saveas(gcf,[file 'nitrification at mid channel'],'png');
%         saveas(gcf,[file 'nitrification at mid channel'],'fig');
%         


