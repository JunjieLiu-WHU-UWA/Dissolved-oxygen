% this script is to calibriation of DON and PON
% BasicRead
currentOutput = '10. Nitrogen nitrification\'; 
OutputNitrogen =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(OutputNitrogen,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(OutputNitrogen);           % if not exists, create the file of 'outdir'
end
% calibriation of  DON 
varid = netcdf.inqVarID(ncid,'WQ_OGM_DON');
OGM_DON = netcdf.getVar(ncid,varid)./1000 *14 ;   %the unit is mmol/m3/ , converted as mg/L 

%--------------------PON---------------------------------------------
varid = netcdf.inqVarID(ncid,'WQ_OGM_PON');
OGM_PON = netcdf.getVar(ncid,varid) /1000*14  ;  %mmol/m3/d to g/m3/d; 

OGM_DON_inlet = OGM_DON(idx2InletCell,:);
OGM_PON_inlet = OGM_PON(idx2InletCell,:);

ob_Inlet_DON_04 = anvil.SWQ.MSANVCBIN.HRD.Storm_04.DON;  % unit is mg/L
ob_Inlet_DON_05 = anvil.SWQ.MSANVCBIN.HRD.Storm_05.DON;  % unit is mg/L

DoW_DON =  anvil.SWQ.MSANVCBIN.LRD.DoW.WQ_OGM_DON; % the unit is mmol/m3, 
ss_DON = find(sTime  <=  DoW_DON.Date  &    DoW_DON.Date <= eTime );

%  OutfigCalibriation( 'DON', 'inlet', OutputNitrogen , ob_Inlet_DON_04, ob_Inlet_DON_05, OGM_DON_inlet  )
Variable = 'DON';
location  = 'inlet';
 figure
 plot(ob_Inlet_DON_04.Date, ob_Inlet_DON_04.Data,'*');
hold on 
plot(ob_Inlet_DON_05.Date, ob_Inlet_DON_05.Data,'o');
hold on 

plot(ResTime , OGM_DON_inlet );
hold on 
leg1 = legend('Oberved during storm 04','Oberved during storm 05', ...
    '1 st layer', ' 2 nd layer', ' 3 st layer',' 4 st layer' );
set(leg1,...
    'Position',[0.24507502543235 0.399949127906977 0.281281790437436 0.214752906976744]);
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Concentration of ' Variable '  at ' location ]);
xlim([sTime  eTime]);
ylabel({ Variable ' (mg/L)'})      
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[OutputNitrogen 'Calibration of  ' Variable 'at' location],'png') ;
saveas(gcf,[OutputNitrogen 'Calibration of '  Variable 'at' location ],'fig');
 
 
figure
plot( DoW_DON.Date, DoW_DON.Data ./ 1000 *14,'s' ); % convert unit to mg/L
hold on 
datetick('x', 'yyyy')

% set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'concentration of '  Variable  ' at   '  location    ' from Dow ']);
% xlim([sTime  eTime]);
ylabel({Variable ' (mg/L)'})      
% xlabel('Date (2015)');
grid on 

saveas(gcf,[OutputNitrogen 'Concentration of ' Variable ' at '  location    ' from Dow'],'png') ;
saveas(gcf,[OutputNitrogen 'Concentration of ' Variable ' at '  location    ' from Dow'],'fig');

%------------------DON  -----Outlet-------------------------------
OGM_DON_weir = OGM_DON(idx2weirCell,:);
OGM_PON_weir = OGM_PON(idx2weirCell,:);

ob_weir_DON_04 = anvil.SWQ.MSANVCBOUT.HRD.Storm_04.DON;  % unit is mg/L
ob_weir_DON_05 = anvil.SWQ.MSANVCBOUT.HRD.Storm_05.DON;  % unit is mg/L

DoW_DON =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_OGM_DON; % the unit is mmol/m3, 
ss_DON = find(sTime  <=  DoW_DON.Date  &    DoW_DON.Date <= eTime );

%  OutfigCalibriation( 'DON', 'weir', OutputNitrogen , ob_weir_DON_04, ob_weir_DON_05, OGM_DON_weir  )
Variable = 'DON';
location  = 'weir';
 figure
 plot(ob_weir_DON_04.Date, ob_weir_DON_04.Data,'*');
hold on 
plot(ob_weir_DON_05.Date, ob_weir_DON_05.Data,'o');
hold on 

plot(ResTime , OGM_DON_weir );
hold on 
leg1 = legend('Oberved during storm 04','Oberved during storm 05', ...
    '1 st layer', ' 2 nd layer', ' 3 st layer',' 4 st layer' );
set(leg1,...
    'Position',[0.24507502543235 0.399949127906977 0.281281790437436 0.214752906976744]);
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Concentration of ' Variable '  at ' location ]);
xlim([sTime  eTime]);
ylabel({ Variable ' (mg/L)'})      
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[OutputNitrogen 'Calibration of  ' Variable 'at' location],'png') ;
saveas(gcf,[OutputNitrogen 'Calibration of '  Variable 'at' location ],'fig');
 
 
figure
plot( DoW_DON.Date, DoW_DON.Data ./ 1000 *14,'s' ); % convert unit to mg/L
hold on 
datetick('x', 'yyyy')

% set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'concentration of '  Variable  ' at   '  location    ' from Dow ']);
% xlim([sTime  eTime]);
ylabel({Variable ' (mg/L)'})      
% xlabel('Date (2015)');
grid on 

saveas(gcf,[OutputNitrogen 'Concentration of ' Variable ' at '  location    ' from Dow'],'png') ;
saveas(gcf,[OutputNitrogen 'Concentration of ' Variable ' at '  location    ' from Dow'],'fig');

%------------DON  weir-------------

OGM_DON_weir = OGM_DON(idx2weirCell,:);
OGM_PON_weir = OGM_PON(idx2weirCell,:);

ob_weir_DON_04 = anvil.SWQ.MSANVCBOUT.HRD.Storm_04.DON;  % unit is mg/L
ob_weir_DON_05 = anvil.SWQ.MSANVCBOUT.HRD.Storm_05.DON;  % unit is mg/L

DoW_DON =  anvil.SWQ.MSANVCBOUT.LRD.DoW.WQ_OGM_DON; % the unit is mmol/m3, 
ss_DON = find(sTime  <=  DoW_DON.Date  &    DoW_DON.Date <= eTime );

%  OutfigCalibriation( 'DON', 'weir', OutputNitrogen , ob_weir_DON_04, ob_weir_DON_05, OGM_DON_weir  )
Variable = 'DON';
location  = 'weir';
 figure
 plot(ob_weir_DON_04.Date, ob_weir_DON_04.Data,'*');
hold on 
plot(ob_weir_DON_05.Date, ob_weir_DON_05.Data,'o');
hold on 

plot(ResTime , OGM_DON_weir );
hold on 
leg1 = legend('Oberved during storm 04','Oberved during storm 05', ...
    '1 st layer', ' 2 nd layer', ' 3 st layer',' 4 st layer' );
set(leg1,...
    'Position',[0.24507502543235 0.399949127906977 0.281281790437436 0.214752906976744]);
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Concentration of ' Variable '  at ' location ]);
xlim([sTime  eTime]);
ylabel({ Variable ' (mg/L)'})      
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[OutputNitrogen 'Calibration of  ' Variable 'at' location],'png') ;
saveas(gcf,[OutputNitrogen 'Calibration of '  Variable 'at' location ],'fig');
 
 
figure
plot( DoW_DON.Date, DoW_DON.Data ./ 1000 *14,'s' ); % convert unit to mg/L
hold on 
datetick('x', 'yyyy')

% set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'concentration of '  Variable  ' at   '  location    ' from Dow ']);
% xlim([sTime  eTime]);
ylabel({Variable ' (mg/L)'})      
% xlabel('Date (2015)');
grid on 

saveas(gcf,[OutputNitrogen 'Concentration of ' Variable ' at '  location    ' from Dow'],'png') ;
saveas(gcf,[OutputNitrogen 'Concentration of ' Variable ' at '  location    ' from Dow'],'fig');