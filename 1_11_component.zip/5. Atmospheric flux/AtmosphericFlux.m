

% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
%--------------------------------------------------------
currentOutput = '5. Atmospheric flux\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'idx2');
idx2 = netcdf.getVar(ncid,varid); 

varid = netcdf.inqVarID(ncid,'stat');  
wetDry = netcdf.getVar(ncid,varid);   % the state of the cell, wet or dry.


 varid = netcdf.inqVarID(ncid,'WQ_DIAG_OXY_ATM_OXY_FLUX');  
AtmFlux = netcdf.getVar(ncid,varid) * 32 /1000 ;  
% convert  the unit of atmospheric flux is mmol/m2/s to g/m2/d
% max(max(AtmFlux)) % 1.3141 * 10^(-4)
AtmFluxSumSpace = zeros(1, size(AtmFlux,2));      % sum all the atmospheric flux within the  whole wetland every step.
AtmFluxCV = zeros(length(cellCV),size(AtmFlux,2));  %  every cell within the whole wetland every step
wetDryCV = zeros(length(cellCV),size(AtmFlux,2));    %   every cell within the whole wetland every step
for ii = 1 : length( cellCV )  % iterative from one cell to one cell.
        ss = find(idx2 == cellCV(ii));
     for jj = 1 : length(ResTime) % iterative from one step to one step
%     if wetDry(cellCV(ii),jj)== -1
        % find the bottom layer at corresponding cell 
        AtmFluxCV(ii, jj) = AtmFlux(ss(end),jj); % the unit is g/m2/d  
         
        wetDryCV(ii,jj) =    wetDry(cellCV(ii),jj);
%     end
    end
 
end
AtmFluxSumSpace =   areaCV' * AtmFluxCV     ;     %multiplied by area %  the unit is g/d

ss = find(  wetDryCV == 0);
AtmFluxCV(ss) = nan;
AtmFluxCVMean = nanmean(AtmFluxCV);
    
% AtmFluxCV =  mean(AtmFluxCV);  % the unit is g/m2/d

figure
subplot(2,1,1)
plot(ResTime, AtmFluxSumSpace./1000) % the unit is kg/d

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Atmospheric mass flux  across  the whole  wetland ']);
xlim([sTime  eTime]);
ylabel({'Atmospheric flux' ' (kg O_{2} /d)'}) 
xlabel('Date (2015)');
grid on 

subplot(2,1,2)
plot(ResTime, AtmFluxCVMean)

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder '   ' 'Atmospheric rate flux  across  the whole  wetland']);
xlim([sTime  eTime]);
ylabel({' Atmospheric flux'  ' (g O_{2} / m^{2} /d)'}) 
xlabel('Date (2015)');
grid on 


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;
ySize = 15;
% xLeft = (21-xSize)/2;
% yTop = (30-ySize)/2;
xLeft = 0;
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Atmospheric mass flux  across the whole wetland'],'png');
saveas(gcf,[fileOutput  'Atmospheric mass flux  across the whole wetland'],'fig');


 filecsv=  [ fileOutput  'AtmFlux_wholeWetland.csv' ];
 fid = fopen(filecsv,'wt');
fprintf(fid,'ISOTime, AtmFluxSumSpace (gO2/d),AtmFluxCVMean (g O2/m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f \n', AtmFluxSumSpace(1,i) ,AtmFluxCVMean(1,i));
                       
end
fclose(fid);



