% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead

%---------------------------------------------------

currentOutput = '11. Residence time\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_TRC_AGE');
RET = netcdf.getVar(ncid,varid) ./3600 ./24 ; % convert second to days



RET_weir = mean(RET(idx2weirCell, :));

figure 
plot(ResTime, RET_weir )
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' residence time at weir ']);
xlim([sTime  eTime]);
ylabel('Days'); 
xlabel('Date (2015)');
grid on 
saveas(gcf,[fileOutput  'Model residence time at weir'],'png');
saveas(gcf,[fileOutput  'Model residence time at weir'],'fig');


filename = [fileOutput   'Residence_Time_weir.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'time, residence time weir (d) \n');
for i = 1:length( ResTime)
    fprintf(fid,'%s,', datestr( ResTime(i), 'dd/mm/yyyy HH:MM:SS') ) ;
    fprintf(fid, '%4.4f\n ' , RET_weir(i) );

        
end
fclose(fid);


