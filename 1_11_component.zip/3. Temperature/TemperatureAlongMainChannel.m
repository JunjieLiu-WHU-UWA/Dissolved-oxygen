clearvars -except anvil sTime eTime   timeTick timeLable dicmodel currentFolder
clc
close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% sTime  = datenum('2015/04/01 00:00:00');
% eTime  = datenum('2015/05/31 23:55:00');
% timeTick = {'2015/04/01 00:00:00'...
%                   '2015/04/10 00:00:00'...
%                   '2015/04/20 00:00:00'...
%                   '2015/05/01 00:00:00'...
%                   '2015/05/10 00:00:00'...
%                   '2015/05/20 00:00:00'...
%                   '2015/05/31 00:00:00'}';
%  timeLable = {' Apr 01' ' Apr 10'  ' Apr 20'   ' May 01' ' May 10'   ' May 20'  ' May 31'   }';  
% dicmodel   = 'E:\Simulation_UWA_WD\';
% currentFolder  =  '20190103 3D';

filename =  [dicmodel currentFolder '\Output\anvil.nc' ];
ncid = netcdf.open(filename,'NC_NOWRITE');  
basicInfor = ncinfo(filename);

positionInlet = [399615.76118518575  	6460376.307198627];
positionMid  = [399565.077639184   6460035.742578388];
positionWeir =  [399481.1  6459913.827];
geofile = [ dicmodel currentFolder '\Input\log\anvil_geo.nc' ];
inletCell = ID_CellnearestNeighbor(geofile, positionInlet);
weirCell = ID_CellnearestNeighbor(geofile, positionWeir);
midCell = ID_CellnearestNeighbor(geofile, positionMid);

varid = netcdf.inqVarID(ncid,'ResTime');
ResTime = netcdf.getVar(ncid,varid) ./24 +  datenum(2001,1,1);
%---------------------------------------------------
currentOutput = '3. Temperature\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

% note: the main line along the channel . 
% the first step is to determine the number of cell in the channel.
% The second step is to determine the coordinates of cell
% the coordinates  are used to calculate distance.

 varid = netcdf.inqVarID(ncid,'idx2');
idx2 = netcdf.getVar(ncid,varid) ;

varid = netcdf.inqVarID(ncid,'TEMP');
TEMP = netcdf.getVar(ncid,varid);

fid = fopen('Finalmainline.csv','rt');
dataPoint = textscan(fid,'%f %f ','Headerlines',1,'Delimiter',',');
ss = ~isnan(dataPoint{1,1});
upchannel = dataPoint{1,1}(ss,1);
mainWetland = dataPoint{1,2};
cellMain = zeros(length(upchannel) + length(mainWetland),1);
cellMain(1:length(upchannel), 1 ) = upchannel;
cellMain(length(upchannel) + 1 : length(upchannel) + length(mainWetland) , 1 ) = mainWetland;

load('rawGeo.mat');
sXX = rawGeo.cell_ctrd(1,cellMain)';  %  the coordinates of cell in cellMain
sYY = rawGeo.cell_ctrd(2,cellMain)';

Distance(1:length(sXX),1) = 0;  % set the data as zero.
for ii = 1:length(sXX)-1        %the distance  is between two points, and we do not need to read the last point
    temp_d = sqrt((sXX(ii+1)-sXX(ii)) .^2 + (sYY(ii+1) - sYY(ii)).^2);  % the distance between the two adjacent point 
    Distance(ii+1,1) = Distance(ii,1) + temp_d;                                        % the Cumulative distance
end



for ii =1 :length(cellMain)
    flag =   find(idx2 ==   cellMain(ii,1));
DistanceTemp(ii,:) = TEMP( flag(1),: );  % surface temperature
deltaTemp(ii,:)   =    TEMP( flag(1,1),: )  -TEMP( flag(end,1),: ) ;  % the differenct between surface and bottom
end

indexCellmid  = 42;
indexCellWeir = 53;

figure
subplot(2,1,1)
contourf( Distance,ResTime, DistanceTemp',  'LineStyle','none')
xlabel('Distance from inlet (m)');
ylabel('Date (2015)');
lineRer = line([round(Distance(indexCellWeir)) round(Distance(indexCellWeir))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellWeir)) -5  , ResTime(end,1) + 2.0 ,'Weir');

lineRer = line([round(Distance(indexCellmid)) round(Distance(indexCellmid))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellmid)) - 25  , ResTime(end,1) + 2.0 ,'Mid channel');

% legend('temp', 'weir')

 xlim([ 0   650])


set(gca,'YTick', [ datenum(timeTick )], 'YTickLabel',timeLable  );

grid on
title([ currentFolder 'surface water temperature along the main channel  varied with time'],'Units',' normalized', 'Position', [0.53 1.04]);
 minTemp =  floor (min(min(DistanceTemp')))     ;
 maxTemp =   ceil (max(max(DistanceTemp')))  ; 
tickTemp = (linspace(     minTemp       ,        maxTemp        , 5 ) )';
 
ccc = colorbar('Ticks', tickTemp,...
         'TickLabels',num2str(tickTemp));
          
 ccc = colorbar( 'Limits',[  minTemp              maxTemp     ]);
  ccc.Label.String = 'Water temp (^{\circ}C) ';
%   
%   
%   [maxT, indexT ] = max(DistanceTemp');
%  max(max(DistanceTemp'))

%   temperature difference between surface and bottom
 
 subplot(2,1,2)
contourf( Distance,ResTime, deltaTemp',  'LineStyle','none')
xlabel('Distance from inlet (m)');
ylabel('Date (2015)');
lineRer = line([round(Distance(indexCellWeir)) round(Distance(indexCellWeir))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellWeir)) -5  , ResTime(end,1) + 2.0 ,'Weir');

lineRer = line([round(Distance(indexCellmid)) round(Distance(indexCellmid))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellmid)) - 25  , ResTime(end,1) + 2.0 ,'Mid channel');

% legend('temp', 'weir')

 xlim([ 0   337])


set(gca,'YTick', [ datenum(timeTick )], 'YTickLabel',timeLable  );

grid on
title([ currentFolder '  temperature  difference between surface and bottom along the main channel'],'Units',' normalized', 'Position', [0.53 1.04]);
 minTemp =  floor (min(min(deltaTemp)))     ;
 maxTemp =   ceil (max(max(deltaTemp)))  ; 
tickTemp = (linspace(     minTemp       ,        maxTemp        , 5 ) )';
 
ccc = colorbar('Ticks', tickTemp,...
         'TickLabels',num2str(tickTemp));
          
 ccc = colorbar( 'Limits',[  minTemp              maxTemp     ]);
  ccc.Label.String = 'Water temp (^{\circ}C) ';
  
  
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;
ySize = 29;
% xLeft = (21-xSize)/2;
% yTop = (30-ySize)/2;

xLeft = 0;
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput  ' temperature along the main channel'],'png');
saveas(gcf, [fileOutput  ' temperature along the main channel'],'fig');
  