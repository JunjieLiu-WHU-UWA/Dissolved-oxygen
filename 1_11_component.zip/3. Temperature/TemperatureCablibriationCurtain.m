
% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
%---------------------------------------------------
currentOutput = '3. Temperature\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end
%-------------------------------------------------------


obMidTemp = anvil.SWQ.Main_stream.Temperature;
 ssMidTemp = find( sTime <=obMidTemp.Date  & obMidTemp.Date <= eTime);
 
 obMidTemp0405.Date = obMidTemp.Date(ssMidTemp,1 );
 obMidTemp0405.Data = obMidTemp.Data(ssMidTemp,1);
 

 
 varid = netcdf.inqVarID(ncid,'TEMP');
Temp = netcdf.getVar(ncid,varid);


idx2MidCell = find(  idx2 == midCell );

midTempSur =  Temp( idx2MidCell(1,1), : );      % midTemp is the surface water temperature 
midTempBot =  Temp( idx2MidCell(end,1), : );  % bottom water temperauter at mid channel
midTempProfile =  Temp( idx2MidCell, : );         % profile of  water temperature



H = Basic.H;
cell_Zb = Basic.cell_Zb;
midStage =  H(midCell,:) - cell_Zb(midCell,:);    % It is  not watetr depth, it is water elevation. zero point is  bottom.
sigma_Stage = [1.0  0.75  0.5 0.25  ]';   % zero  point is at the bottom.
cellStage = sigma_Stage * midStage;

tempSenor = zeros(  length(ResTime)  , 1);
for ii = 1: length(ResTime)

    
    tempSenor(ii,1) = interp1(cellStage(:,ii), midTempProfile (:,ii), 0.35, 'linear','extrap' );
end
%---------------------Observed Temperature and modelled temperature at sensor stage-------------------------
figure
 
pp = plot(obMidTemp0405.Date,  obMidTemp0405.Data,'b*' );
hold on
set(pp,'MarkerSize',2.0 );
plot(ResTime,  tempSenor,'r' );
hold on 
  AddShade([12 12], [24  24], period  )
leg1 = legend('Observe', 'Modelled  temperature at sensor stage');
set(leg1,'Location','southwest');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' Temp of sensor stage at mid channel ']);
xlim([sTime  eTime]);
ylabel('Water temp (^{\circ}C)'); 
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])



saveas(gcf,[fileOutput  'Model Temp of sensor stage and Observe Temp at mid'],'png');
saveas(gcf,[fileOutput  'Model Temp of sensor stage  and Observe Temp at mid'],'fig');


 filename = [ fileOutput 'WaterTemperatureSensorDepth_10min.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, water temperature SensorDepth (degree) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',    tempSenor(i) );
end
fclose(fid);



% model performance for calibriation

lengOb = min([length(obMidTemp0405.Date) length(tempSenor)]);
[mae, rmse, ns]    = modelPerformance( obMidTemp0405.Data,   tempSenor(1:lengOb) );


 filename = [ fileOutput 'model_performance_temperature.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'mae, RMSE, Nash-Sutcliffe model efficiency \n');
 fprintf(fid,'%4.4f, %4.4f, %4.4f  \n', mae, rmse, ns   );
fclose(fid);










%%%      
      figure
      plot( obMidTemp0405.Data,tempSenor(1:lengOb), '*' )
      xlabel('observed temperature (^{\circ}C )');
      ylabel('modelled temperature (^{\circ}C )');
      hline = refline(1,0);
      hline.Color = 'r';
      grid on
 
      title( [ currentFolder  'correlation temperature ']);
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 10; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
  
saveas(gcf,[fileOutput 'correlation observed and modelled temperature '],'fig');
saveas(gcf, [fileOutput 'correlation observed and modelled temperature'],'png');
      
      
      
      

 %---------------------------Observed DO and modelled temperature profile ------------------------------------------------------------------
 
figure
 
pp = plot(obMidTemp0405.Date,  obMidTemp0405.Data,'b*' );
hold on
set(pp,'MarkerSize',2.0 );
plot(ResTime,  midTempProfile);
hold on 

leg1 = legend('observe', 'modelled  temperature at 1st layer', 'modelled  temperature at 2nd layer', 'modelled  temperature at 3st layer' , 'modelled  temperature at 4st layer');
set(leg1,'Location','southwest');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' Temp of sensor stage at mid channel ']);
xlim([sTime  eTime]);
ylabel('Water temp (^{\circ}C)'); 
xlabel('Date (2015)');
grid on 

saveas(gcf,[fileOutput  'Model Temp of each layer and Observe Temp at mid'],'png');
saveas(gcf,[fileOutput  'Model Temp of each layer and Observe Temp at mid'],'fig');

 %-------------  Curtain ----------------------------------
 
for ii = 1:length(sigma_Stage)
mTime(ii,:) =  ResTime';
end

figure
contourf(mTime, cellStage, midTempProfile ,  'LineStyle','none')

xlabel('Date (2015)');
ylim([ 0   2.0])
ylabel('Water  Stage  (m)');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );

grid on
title(' mid channel temp');
%  tickTemp = (linspace(    floor (min(min(midTemp)))            ,        ceil (max(max(midTemp)))         , 5 ) )';
 tickTemp  = [10 15 20 25  ]';
ccc = colorbar('Ticks', tickTemp,...
         'TickLabels',num2str(tickTemp),...
         'Limits',[min(tickTemp) max(tickTemp)]);
 ccc.Label.String = 'Water temp ^{\circ}C ';

saveas(gcf, [  fileOutput   'Water temperature curtain at mid' ],'png');
saveas(gcf, [  fileOutput   'Water temperature curtain at mid' ],'fig');


