
% addpath('E:\Simulation_UWA_WD\1 water balance');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead;

currentOutput = '3. Temperature\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end


% extinction of coefficient


 varid = netcdf.inqVarID(ncid,'WQ_DIAG_TOT_EXTC');
TOT_EXTC = netcdf.getVar(ncid,varid);

 varid = netcdf.inqVarID(ncid,'WQ_DIAG_TOT_LIGHT');
TOT_LIGHT = netcdf.getVar(ncid,varid);

 varid = netcdf.inqVarID(ncid,'WQ_DIAG_TOT_PAR');
TOT_PAR = netcdf.getVar(ncid,varid);

 varid = netcdf.inqVarID(ncid,'WQ_DIAG_PHY_PAR');
PHY_PAR = netcdf.getVar(ncid,varid);


mid_TOT_EXTC =  TOT_EXTC(idx2midCell, : );  % TOT_EXTC

figure

plot(ResTime, mid_TOT_EXTC(1,:),'r' );
hold on
plot(ResTime,  mid_TOT_EXTC(2,:),'g' );
hold on
plot(ResTime,  mid_TOT_EXTC(3,:),'b' );
hold on
plot(ResTime,  mid_TOT_EXTC(4,:),'c' );
hold on

leg_1 = legend( '1', '2', '3', '4');
set(leg_1, 'Location','best')
title('TOT EXTC at midchannel')
ylabel({' TOT EXTC  in each layer (mg/L)'});
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
xlim([sTime  eTime]);
grid on
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'TOT EXTC mid channel'],'png');
saveas(gcf,[fileOutput  'TOT EXTC mid channel'],'fig');




mid_TOT_LIGHT =  TOT_LIGHT(idx2midCell, : );  % TOT_LIGHT

figure

plot(ResTime, mid_TOT_LIGHT(1,:),'r' );
hold on
plot(ResTime,  mid_TOT_LIGHT(2,:),'g' );
hold on
plot(ResTime,  mid_TOT_LIGHT(3,:),'b' );
hold on
plot(ResTime,  mid_TOT_LIGHT(4,:),'c' );
hold on

leg_1 = legend( '1', '2', '3', '4');
set(leg_1, 'Location','best')
title('TOT LIGHT at midchannel')
ylabel({' TOT  LIGHT  in each layer (W/m^{2})'});
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
xlim([sTime  eTime]);
grid on
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'TOT LIGHT mid channel'],'png');
saveas(gcf,[fileOutput  'TOT LIGHT mid channel'],'fig');

%---------------------------


mid_TOT_PAR =  TOT_PAR(idx2midCell, : );  % TOT_PAR

figure

plot(ResTime, mid_TOT_PAR(1,:),'r' );
hold on
plot(ResTime,  mid_TOT_PAR(2,:),'g' );
hold on
plot(ResTime,  mid_TOT_PAR(3,:),'b' );
hold on
plot(ResTime,  mid_TOT_PAR(4,:),'c' );
hold on

leg_1 = legend( '1', '2', '3', '4');
set(leg_1, 'Location','best')
title('TOT PAR at midchannel')
ylabel({' TOT  PAR  in each layer (W/m^{2})'});
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
xlim([sTime  eTime]);
grid on
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'TOT PAR mid channel'],'png');
saveas(gcf,[fileOutput  'TOT PAR mid channel'],'fig');





mid_PHY_PAR =  PHY_PAR(idx2midCell, : );  % PHY_PAR

figure

plot(ResTime, mid_PHY_PAR(1,:),'r' );
hold on
plot(ResTime,  mid_PHY_PAR(2,:),'g' );
hold on
plot(ResTime,  mid_PHY_PAR(3,:),'b' );
hold on
plot(ResTime,  mid_PHY_PAR(4,:),'c' );
hold on

leg_1 = legend( '1', '2', '3', '4');
set(leg_1, 'Location','best')
title('PHY PAR at midchannel')
ylabel({' PHY PAR  in each layer (W/m^{2})'});
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
xlim([sTime  eTime]);
grid on
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'PHY PAR mid channel'],'png');
saveas(gcf,[fileOutput  'PHY PAR mid channel'],'fig');