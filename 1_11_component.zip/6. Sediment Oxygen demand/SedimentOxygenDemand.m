
% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
%--------------------------------------------------------
currentOutput = '6. Sediment Oxygen demand\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end


varid = netcdf.inqVarID(ncid,'stat');  
wetDry = netcdf.getVar(ncid,varid);   % the state of the cell, wet or dry.


varid = netcdf.inqVarID(ncid,'WQ_DIAG_OXY_SED_OXY');
SedOxy = netcdf.getVar(ncid,varid) * 32 /1000 * (-1); % convert mmol/m2/day to g/m2/d.
% 
% 'WQ_DIAG_SDF_FSED_OXY'
% 
% varid = netcdf.inqVarID(ncid,'WQ_DIAG_SDF_FSED_OXY');
% FsedOxy = netcdf.getVar(ncid,varid) * 32 /1000 * (-1); % convert mmol/m2/day to g/m2/d.

 [ SedOxySumSpace ,  SedOxyCVMean  ]  =  bottomLayer( SedOxy, Basic,Cell_whole_channel);
% the unit of SedOxySumSpace is g/d
% the unit of SedOxyCV  is g/m2/d
 



figure
subplot(2,1,1)
plot(ResTime, SedOxySumSpace./1000) % the unit is kg/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mass flux of  SOD across all the wetland ']);
xlim([sTime  eTime]);
ylabel({'Sediment oxygen demand'  '(kg O_{2} /d)'})    
xlabel('Date (2015)');
grid on 


subplot(2,1,2)
plot(ResTime, SedOxyCVMean)
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mean rate flux of  SOD across the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Sediment oxygen demand'  ' (g O_{2} /m^{2} /d)'})   
xlabel('Date (2015)');
grid on 


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;
ySize = 15;
% xLeft = (21-xSize)/2;
% yTop = (30-ySize)/2;
xLeft = 0;
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Sediment oxygen demand  across the whole wetland'],'png');
saveas(gcf,[fileOutput  'Sediment oxygen demand across  the whole wetland'],'fig');




 filecsv =  [ fileOutput  'SOD_wholeWetland.csv' ];
 fid = fopen(filecsv,'wt');
fprintf(fid,'ISOTime, SedOxySumSpace (g O2 /d),SedOxyCVMean (g O2 /m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f \n', SedOxySumSpace(1,i) ,SedOxyCVMean(1,i));
                       
end
fclose(fid);