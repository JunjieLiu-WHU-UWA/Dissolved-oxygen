
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead

%---------------------------------------------------

currentOutput = '4. Oxygen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_OXY_OXY');
Oxy = netcdf.getVar(ncid,varid) /1000 *32; % the unit is mg/L
idx2inletCell = find(  idx2 == inletCell );
idx2weirCell = find(  idx2 == weirCell );

inletOxyProfile = Oxy( idx2inletCell, : );  % profile of  DO
weirOxyProfile = Oxy( idx2weirCell, : );  % profile of  DO

figure
subplot(2,1,1)
plot(ResTime,  inletOxyProfile);
hold on 
leg1 = legend('Oxy at 1st layer', ' Oxy at 2nd layer', 'Oxy at 3st layer' , 'Oxy at 4st layer');
set(leg1,'Location','northwest');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder '   Oxy profile at inlet ']);
xlim([sTime  eTime]);
ylabel(' Oxygen concentration (mg/L)'); 
xlabel('Date (2015)');
grid on 

subplot(2,1,2)
plot(ResTime,  weirOxyProfile);
hold on 
leg1 = legend('Oxy at 1st layer', ' Oxy at 2nd layer', 'Oxy at 3st layer' , 'Oxy at 4st layer');
set(leg1,'Location','northwest');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder '   Oxygen profle at weir']);
xlim([sTime  eTime]);
ylabel(' Oxygen concentration (mg/L)'); 
xlabel('Date (2015)');
grid on 

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 20;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput   ' Inflow and outflow  oxygen flux'],'png');

saveas(gcf,[fileOutput  'Model Oxy of each layer at inlet and outlet'],'png');
saveas(gcf,[fileOutput  'Model Oxy of each layer at inlet and outlet'],'fig');

% idx2Cell21 = find(  idx2 == 21);
% OxyProfile21 = Oxy( idx2Cell21, : );  % profile of  DO
% figure
% plot(ResTime,  OxyProfile21);
% hold on 
% set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
%------------------additional point for test ---------------------------------------------------
% idx2Cell185 = find(  idx2 == 185);
% OxyProfile185 = Oxy( idx2Cell185, : );  % profile of  DO
% figure
% plot(ResTime,  OxyProfile185);
% hold on 
% set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% 
% idx2Cell629 = find(  idx2 == 629);
% OxyProfile629 = Oxy( idx2Cell629, : );  % profile of  DO
% figure
% plot(ResTime,  OxyProfile629);
% hold on 
% set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
% 
% idx2Cell1245 = find(  idx2 == 1245);
% OxyProfile1245 = Oxy( idx2Cell1245, : );  % profile of  DO
% figure
% plot(ResTime,  OxyProfile1245);
% hold on 
% set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );

% comparison of mean concentration at inlet and outlet.

%------------------------------------calculate delta DO-----------------------
file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
Inlet_DO.Date = ISOTime_in;
Inlet_DO.Data = data_inlet{1,8} /1000 *32;


inletOxyMean.Data = Inlet_DO.Data ; % use the data at boundary file instead of at data of cell
inletOxyMean.Date = Inlet_DO.Date;






weirOxyMean.Data = mean( weirOxyProfile)';
weirOxyMean.Date = ResTime;

 filename = [ fileOutput 'Weir_mean_10min.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, oxygen concentration (mg/L) \n');
for i = 1:length(weirOxyMean.Date)
    fprintf(fid,'%s,',datestr(weirOxyMean.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',    weirOxyMean.Data(i));
end
fclose(fid);


inletDaily = dailyDelta(inletOxyMean);
weirDaily = dailyDelta(weirOxyMean);
weir_inlet_deltaDO.Data =   weirDaily.varDelta  ./ inletDaily.varDelta;
weir_inlet_deltaDO.Date = inletDaily.Date;

weir_inlet_deltaDO_substract.Date = inletDaily.Date;
weir_inlet_deltaDO_substract.Data = weirDaily.varDelta  - inletDaily.varDelta;

 filename = [ fileOutput 'InflowDO_daily.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, oxygen_max (mg/L), Oxgen_min (mg/L), Oxgen_delta (mg/L) \n');
for i = 1:length(inletDaily.Date)
    fprintf(fid,'%s,',datestr(inletDaily.Date(i),'yyyy/mm/dd'));
    fprintf(fid,'%4.4f, %4.4f, %4.4f \n',    inletDaily.varMax(i), inletDaily.varMin(i), ...
                                                                inletDaily.varDelta(i) );
end
fclose(fid);
%--------------------
 filename = [ fileOutput 'WeirDO_10min.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, weir oxygen (mg/L) \n');
for i = 1:length(weirOxyMean.Date )
    fprintf(fid,'%s,',datestr(weirOxyMean.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f  \n', weirOxyMean.Data(i)   );
end
fclose(fid);

 filename = [ fileOutput 'WeirDO_daily.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, oxygen_max (mg/L), Oxgen_min (mg/L), Oxgen_delta (mg/L),weir_inlet_deltaDO (-), weir_inlet_deltaDO_substract (-)\n');
for i = 1:length(weirDaily.Date)
    fprintf(fid,'%s,',datestr(weirDaily.Date(i),'yyyy/mm/dd'));
    fprintf(fid,'%4.4f, %4.4f, %4.4f, %4.4f, %4.4f  \n',    weirDaily.varMax(i), weirDaily.varMin(i), ...
                                                                             weirDaily.varDelta(i), weir_inlet_deltaDO.Data(i), ...
                                                                             weir_inlet_deltaDO_substract.Data(i));
end
fclose(fid);

[ weir_inlet_deltaDOnonStorm,  weir_inlet_deltaDOStorm ]   = divide2period( weir_inlet_deltaDO);


[ weir_inlet_deltaDO_substractnonStorm,  weir_inlet_deltaDO_substractStorm ]   = divide2period( weir_inlet_deltaDO_substract);


figure 

h(1)= plot( weir_inlet_deltaDOnonStorm.Date    ,weir_inlet_deltaDOnonStorm.Data,'*' );
hold on
h(2) = plot( weir_inlet_deltaDOStorm.Date    ,weir_inlet_deltaDOStorm.Data,'o' );
hold on

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder '   Delta DO at outlet / Delta DO at inlet ']);
xlim([sTime  eTime]);
hline = refline([0 1]);
% hline = refline([0 1]);
hline.Color = 'g';
hline.DisplayName = '';
leg1 = legend(h(1:2),'Non storm period','Storm event');
set(leg1,'Position',[0.316945606694561 0.80409090909091 0.131276150627615 0.0959090909090909]);

xlabel('Date (2015)');
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 8;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'Delta DO ratio of  outlet to inlet'],'png');
saveas(gcf,[fileOutput  'Delta DO ratio of  outlet to inlet'],'fig');


%-----
figure 

h(1)= plot( weir_inlet_deltaDO_substractnonStorm.Date    ,weir_inlet_deltaDO_substractnonStorm.Data,'*' );
hold on
h(2) = plot( weir_inlet_deltaDO_substractStorm.Date    ,weir_inlet_deltaDO_substractStorm.Data,'o' );
hold on

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder '   Delta DO at outlet - Delta DO at inlet ']);
xlim([sTime  eTime]);
hline = refline([0 0]);
% hline = refline([0 1]);
hline.Color = 'g';
hline.DisplayName = '';
leg1 = legend(h(1:2),'Non storm period','Storm event');
set(leg1,'Position',[0.316945606694561 0.80409090909091 0.131276150627615 0.0959090909090909]);

xlabel('Date (2015)');
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 8;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'Delta DO substract of  outlet to inlet'],'png');
saveas(gcf,[fileOutput  'Delta DO substract of  outlet to inlet'],'fig');
%---------------------------------------------------

figure('PaperType','A4');
plot(Inlet_DO.Date,Inlet_DO.Data);
hold on 
plot(ResTime,  mean(weirOxyProfile));
hold on 
  AddShade([0 0], [12  12 ], period  )
leg1 = legend('Inlet', 'Outlet');
set(leg1,'Position',[0.316945606694561 0.80409090909091 0.131276150627615 0.0959090909090909]);
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder '   Oxy comparison at inlet and outlet ']);
xlim([sTime  eTime]);
ylabel(' Oxygen concentration (mg/L)'); 
xlabel('Date (2015)');
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'Comparison DO at inlet and outlet'],'png');
saveas(gcf,[fileOutput  'Comparison DO at inlet and outlet'],'fig');
