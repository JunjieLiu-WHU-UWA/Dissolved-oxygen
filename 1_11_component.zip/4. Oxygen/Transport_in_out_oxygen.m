
% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
%--------------------------------------------------------------------

currentOutput = '4. Oxygen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

%----------------------------------------------------------------------------------



 % transport in   
 file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
Inflow.Date = ISOTime_in;
Inflow.Data = data_inlet{1,2};

InflowOxy.Date  = ISOTime_in;
InflowOxy.Data  = data_inlet{1,8} ;  %  the unit is  mmol /m3

transInOxy   = calculationFlux(Inflow.Date,   Inflow.Data,   InflowOxy.Data); % mmol/s
transInOxy.Data = transInOxy.Data  * Oxy_mmol_g  * day_second  ; % the unit is g/d


file_Mars =  [ dicmodel currentFolder   '\BCs\'      BC_Mars ];
fid = fopen(file_Mars ,'rt');
str = repmat('%f ', [1 24] );
data_Mars = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in_Mars = datenum(data_Mars{1,1},'dd/mm/yyyy HH:MM:SS');
InflowMars.Date = ISOTime_in_Mars;
InflowMars.Data = data_Mars{1,2};    % the uni is m3/s      
   
InflowMarOxy.Date  = ISOTime_in_Mars;
InflowMarOxy.Data  = data_Mars{1,8};  %  the unit is mmol/m3
     
transInMarsOxy   = calculationFlux(InflowMars.Date,  InflowMars.Data,   InflowMarOxy.Data); % mmol/s
transInMarsOxy.Data = transInMarsOxy.Data  * Oxy_mmol_g * day_second  ; % the unit is g/d    

transTotal_inflow.Date = transInMarsOxy.Date;
transTotal_inflow.Data = transInOxy.Data + transInMarsOxy.Data ;

fileweir = [  dicmodel currentFolder  '\Output\4. Oxygen\'  'Weir_mean_10min.csv'];
 fid = fopen(fileweir,'rt');
data = textscan(fid,'%s %f','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Weir_DO_10min.Date = dateTime ;
Weir_DO_10min.Data = data{1,2} * 1000 / 32; %convert mg/L to mmol/m3

transOut  = calculationFlux(Flux.NS11.mDate, Flux.NS11.Flow, Weir_DO_10min.Data);% mmol/s
transOut.Data = transOut.Data  * 32 /1000  * day_second ; % the unit is g/d
% figure
% plot(  Flux.NS11.mDate   , Flux.NS11.OXY_oxy /1000*32 )
% ylabel('oxygen output (mg/L)')

figure
plot(transTotal_inflow.Date,transTotal_inflow.Data./1000  , 'Color',[0 0 1]);  % kg/d 
hold on 
pp = plot(transOut.Date , transOut.Data./ 1000  , 'Color',[1 0 0]);  % kg/d 
leg1 = legend('Tansport in oxygen',  'Tansport out oxygen');
set(leg1,'Location','northwest');
set(gca,'XTick', [ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Oxygen Input', '(kg/d)'});
%  text( sTime + 8,800,'(a)');
%  text(0.08,1.1,'(a)','units','normalized');
 title([  currentFolder '       Oxygen input and output'])
 grid on 
 
 %---------------------------------------
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput   ' Inflow and outflow  oxygen flux'],'png');
%---------------------
%---------------Write transport DO at inlet  into file ---------------------------------------------------------
 filename = [ fileOutput 'Transport_in_Oxygen_10min.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, TransportInOxygen (g/d)\n');
for i = 1:length(transTotal_inflow.Date)
    fprintf(fid,'%s,',datestr(transTotal_inflow.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f\n',    transTotal_inflow.Data(i) );
end
fclose(fid);


%---------------Write transport DO at weir  into file ---------------------------------------------------------
 filename = [ fileOutput 'Transport_outflow_Oxygen_10min.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, TransportOutOxygen (g/d)\n');
for i = 1:length(transOut.Date)
    fprintf(fid,'%s,',datestr(transOut.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',     transOut.Data(i));
end
fclose(fid);
