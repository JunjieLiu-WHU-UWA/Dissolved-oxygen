

% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead

%---------------------------------------------------

currentOutput = '4. Oxygen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end


obMidOxy = anvil.SWQ.Main_stream.Dissolved_Oxygen;
ssMidDO = find( sTime <=obMidOxy.Date  & obMidOxy.Date <= eTime);
 
 obMidOxy0405.Date = obMidOxy.Date(ssMidDO,1 );
 obMidOxy0405.Data = obMidOxy.Data(ssMidDO,1);

varid = netcdf.inqVarID(ncid,'WQ_OXY_OXY');
Oxy = netcdf.getVar(ncid,varid) /1000 *32; % the unit is mg/L

[OxyAveLayer, OxyAveSheet]  = Average3D2D(Oxy,Basic, Cell_whole_channel );


 filename = [ fileOutput 'DO concentrationAverageDepthSheet.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, Oxy_ave_sheet (mg/L)\n');
for i = 1:length(OxyAveSheet.Date)
    fprintf(fid,'%s,',datestr(OxyAveSheet.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f\n',    OxyAveSheet.Data(i) );
end
fclose(fid);






idx2MidCell = find(  idx2 == midCell );

midOxySur =  Oxy( idx2MidCell(1), : );  % midOxy is the surface DO 
midOxyBot =  Oxy( idx2MidCell(end), : );  % bottom DO at mid channel
midOxyProfile = Oxy( idx2MidCell, : );  % depth averaged DO

H = Basic.H;
cell_Zb = Basic.cell_Zb;
midStage =  H(midCell,:) - cell_Zb(midCell,:);    % It is  not watetr depth, it is water elevation. zero point is  bottom.
sigma_Stage = [1.0  0.75  0.5 0.25  ]';   % zero  point is at the bottom.
cellStage = sigma_Stage * midStage;

for ii = 1: length(ResTime)
     OxySenor(ii,1) = interp1(cellStage(:,ii), midOxyProfile(:,ii), 0.35, 'linear','extrap' );
end


%---------------------Observed Temperature and modelled temperature at sensor stage-------------------------
figure
 
pp = plot(obMidOxy0405.Date,  obMidOxy0405.Data,'b*' );
hold on
set(pp,'MarkerSize',2.0 );
plot(ResTime,  OxySenor,'r' );
hold on 
  AddShade([0 0], [12  12], period  )

leg1 = legend('Observed oxygen', 'Modelled oxygen');
set(leg1,'Position',[0.294456066945607 0.803539019963702 0.228556485355648 0.0957350272232304]);
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder ' Oxy of sensor stage at mid channel ']);
xlim([sTime  eTime]);
ylim([ 0   10]);
ylabel('DO (mg/L)'); 
xlabel('Date (2015)');
grid on 

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'Model Oxy of sensor stage and Observe Oxy at mid'],'png');
saveas(gcf,[fileOutput  'Model Oxy of sensor stage and Observe Oxy at mid'],'fig');



 filename = [ fileOutput 'DissolvedOxygenSensorDepth_10min.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, dissolved oxygen SensorDepth (mg/L) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',    OxySenor(i) );
end
fclose(fid);


%-------------------------------------------
lengOb = min([length(obMidOxy0405.Data) length(OxySenor)]);
[mae, rmse, ns]    = modelPerformance( obMidOxy0405.Data,   OxySenor(1:lengOb) );

 filename = [ fileOutput 'model_performance_oxygen.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'mae, RMSE, Nash-Sutcliffe model efficiency \n');
 fprintf(fid,'%4.4f, %4.4f, %4.4f  \n', mae, rmse, ns   );
fclose(fid);



      figure
      plot( obMidOxy0405.Data, OxySenor(1:lengOb), '*' )
      xlabel('Observed DO (mg/L )');
      ylabel('Modelled DO (mg/L)');
      hline = refline(1,0);
      hline.Color = 'r';
      grid on
 
      title( [ currentFolder  'correlation oxygen ']);
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 10; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
  
saveas(gcf,[fileOutput 'correlation observed and modelled oxygen '],'fig');
saveas(gcf, [fileOutput 'correlation observed and modelled oxygen'],'png');
    
   
 %---------------------------Observed DO and modelled Oxy profile ------------------------------------------------------------------
 
figure
pp = plot(obMidOxy0405.Date,  obMidOxy0405.Data,'b*' );
hold on
set(pp,'MarkerSize',2.0 );
plot(ResTime,  midOxyProfile);
hold on 

leg1 = legend('observe', 'modelled  Oxy at 1st layer', 'modelled  Oxy at 2nd layer', 'modelled  Oxy at 3st layer' , 'modelled  Oxy at 4st layer');
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder '   Oxy of sensor stage at mid channel ']);
xlim([sTime  eTime]);
ylabel(' Oxygen concentration (mg/L)'); 
xlabel('Date (2015)');
grid on 

saveas(gcf,[fileOutput  'Model Oxy of each layer and Observe Oxy at mid'],'png');
saveas(gcf,[fileOutput  'Model Oxy of each layer and Observe Oxy at mid'],'fig');


 %---------------------------Observed DO and modelled Oxy profile ------------------------------------------------------------------
 
figure
pp = plot(obMidOxy0405.Date,  obMidOxy0405.Data,'b*' );
hold on
set(pp,'MarkerSize',2.0 );
plot(ResTime,  midOxyProfile);
hold on 

leg1 = legend('observe', 'modelled  Oxy at 1st layer', 'modelled  Oxy at 2nd layer', 'modelled  Oxy at 3st layer' , 'modelled  Oxy at 4st layer');
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder '   Oxy of sensor stage at mid channel ']);
xlim([sTime  eTime]);
ylabel(' Oxygen concentration (mg/L)'); 
xlabel('Date (2015)');
grid on 

 %-------------  Curtain ----------------------------------
 
for ii = 1:length(sigma_Stage)
mTime(ii,:) =  ResTime';
end

figure
contourf(mTime, cellStage, midOxyProfile ,  'LineStyle','none')

xlabel('Date (2015)');
ylim([ 0   2.0])
ylabel('Water  Stage  (m)');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );

grid on
title([currentFolder  '    mid channel Oxy']);
%  tickOxy = (linspace(    floor (min(min(midOxy)))            ,        ceil (max(max(midOxy)))         , 5 ) )';
 tickOxy  = [0  2 4 6 8 10   ]';
ccc = colorbar('Ticks', tickOxy,...
         'TickLabels',num2str(tickOxy),...
         'Limits',[min(tickOxy) max(tickOxy)]);
 ccc.Label.String = 'Oxy mg/L';

% saveas(gcf, [  fileOutput   'Oxy curtain at mid' ],'png');
% saveas(gcf, [  fileOutput   'Oxy curtain at mid' ],'fig');


% print(gcf,[ fileOutput ' Oxy curtain at mid.tiff'],'-dtiff','-r300');
print(gcf,[fileOutput 'Oxy curtain at mid.png'],'-dpng','-r300');