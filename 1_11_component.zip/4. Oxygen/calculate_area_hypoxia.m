
% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead

%---------------------------------------------------

currentOutput = '4. Oxygen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_OXY_OXY');
OXY = netcdf.getVar(ncid,varid) / (1000/32);
fileBasicmat = [dicmodel currentFolder '\Output\Basic.mat'];
% save Flux.mat Flux
% load(fileBasicmat, 'Basic');

status = Basic.stat;
[row , col] = size(OXY);
% all cell depth average 

[ Oxylay1, Oxylay2, Oxylay3, Oxylay4, depthAveOxy  ]  =  retriveEachLayer(OXY);

perDO_1 = zeros(1, col);
perDO_2 = zeros(1, col);
perDO_3 = zeros(1, col);
perDO_4 = zeros(1, col);
DOthres = 2;  % the threshold concentration of DO
Hypoxia_DepthAve.Date = ResTime;
Hypoxia_DepthAve.Data = zeros(1, col); % the threshold is 2 mg/L
Denitri_DepthAve.Date = ResTime;
Denitri_DepthAve.Data = zeros(1,col);% the threshold is 0.5 mg/L for denitrification
for ii = 1: col
perDO_1(1, ii) =   PercentHyoxia( Oxylay1(:,ii), DOthres, Basic, status(:, ii), Cell_whole_channel);
perDO_2(1, ii) =   PercentHyoxia( Oxylay2(:,ii), DOthres, Basic, status(:, ii), Cell_whole_channel);
perDO_3(1, ii) =   PercentHyoxia( Oxylay3(:,ii), DOthres, Basic, status(:, ii), Cell_whole_channel);
perDO_4(1, ii) =   PercentHyoxia( Oxylay4(:,ii), DOthres, Basic, status(:, ii), Cell_whole_channel);
Hypoxia_DepthAve.Data(1,ii) = PercentHyoxia( depthAveOxy(:,ii), DOthres, Basic, status(:, ii), Cell_whole_channel);
Denitri_DepthAve.Data(1,ii) = PercentHyoxia( depthAveOxy(:,ii), 0.5, Basic, status(:, ii), Cell_whole_channel);
end






% depth average 
figure
plot( Hypoxia_DepthAve.Date , Hypoxia_DepthAve.Data )
 AddShade([0 0], [100  100 ], period  )
%  leg1 = legend('1 st layer');
%  set(leg1,'location','best');
 set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
 title([  currentFolder ' percent of area with depth-average DO < 2 mg/L ']);
 xlim([sTime  eTime]);
 ylim([ 0   100]);
 ylabel('%'); 
 xlabel('Date (2015)');
 grid on 
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'percent of area with depth average DO less 2'],'png');
saveas(gcf,[fileOutput  'percent of area with depth average DO less 2'],'fig');

filename = [ fileOutput 'percent of area with depth average DO less 2.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, percent of area with depth average DO less 2\n');
for i = 1:length(Hypoxia_DepthAve.Date)
    fprintf(fid,'%s,',datestr(Hypoxia_DepthAve.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',   Hypoxia_DepthAve.Data(i));
end
fclose(fid);


% depth average 
figure
plot( Denitri_DepthAve.Date , Denitri_DepthAve.Data )
 AddShade([0 0], [100  100 ], period  )
%  leg1 = legend('1 st layer');
%  set(leg1,'location','best');
 set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
 title([  currentFolder ' percent of area with depth-average DO < 0.5 mg/L ']);
 xlim([sTime  eTime]);
 ylim([ 0   100]);
 ylabel('%'); 
 xlabel('Date (2015)');
 grid on 
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  'percent of area with depth average DO less 0 5 '],'png');
saveas(gcf,[fileOutput  'percent of area with depth average DO less 0 5'],'fig');

filename = [ fileOutput 'percent of area with depth average DO less 0 5.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, percent of area with depth average DO less 0 5 \n');
for i = 1:length(Denitri_DepthAve.Date)
    fprintf(fid,'%s,',datestr(Denitri_DepthAve.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',   Denitri_DepthAve.Data(i));
end
fclose(fid);


%----------------
Hypoxia_DepthAveDay = dailyDelta(Hypoxia_DepthAve);

 filename = [ fileOutput 'Hypoxia_DepthAveDay_daily.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, hypoxia_max (mg/L), hypoxia_min (mg/L), hypoxia_delta (mg/L) \n');
for i = 1:length(Hypoxia_DepthAveDay.Date)
    fprintf(fid,'%s,',datestr(Hypoxia_DepthAveDay.Date(i),'yyyy/mm/dd'));
    fprintf(fid,'%4.4f, %4.4f, %4.4f \n',    Hypoxia_DepthAveDay.varMax(i), Hypoxia_DepthAveDay.varMin(i), ...
                                                                Hypoxia_DepthAveDay.varDelta(i) );
end
fclose(fid);


 Denitri_DepthAveDay = dailyDelta(Denitri_DepthAve);

 filename = [ fileOutput 'Denitri_DepthAveDay_daily.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, Denitri_max (mg/L), Denitri_min (mg/L), Denitri_delta (mg/L) \n');
for i = 1:length(Denitri_DepthAveDay.Date)
    fprintf(fid,'%s,',datestr(Denitri_DepthAveDay.Date(i),'yyyy/mm/dd'));
    fprintf(fid,'%4.4f, %4.4f, %4.4f \n',    Denitri_DepthAveDay.varMax(i), Denitri_DepthAveDay.varMin(i), ...
                                                                Denitri_DepthAveDay.varDelta(i) );
end
fclose(fid);



 
%------------------------------------------------------
%  figure
%  subplot(4,1,1)
%  plot(ResTime,perDO_1 )
%  hold on 
% 
% 
%  AddShade([0 0], [100  100 ], period  )
%  leg1 = legend('1 st layer');
%  set(leg1,'location','best');
%  set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
%  title([  currentFolder ' percent of area with DO < 0.5mg/L ']);
%  xlim([sTime  eTime]);
% %  ylim([ 0   100]);
%  ylabel('%'); 
%  xlabel('Date (2015)');
%  grid on 
% 
%  
%  
%  
% subplot(4,1,2)
%   plot(ResTime,perDO_2 )
%  hold on
%  AddShade([0 0], [100  100 ], period  );
%  leg1 = legend('2 st layer');
%  set(leg1,'location','best');
%  set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
%  title([  currentFolder ' percent of area with DO < 0.5mg/L ']);
%  xlim([sTime  eTime]);
%  ylim([ 0   100]);
%  ylabel('%'); 
%  xlabel('Date (2015)');
%  grid on 
% 
%  
%  subplot(4,1,3)
%  plot(ResTime,perDO_3 )
%  hold on
%  AddShade([0 0], [100  100 ], period  );
%  leg1 = legend('3 st layer');
%  set(leg1,'location','best');
%  set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
%  title([  currentFolder ' percent of area with DO < 0.5mg/L ']);
%  xlim([sTime  eTime]);
%  ylim([ 0   100]);
%  ylabel('%'); 
%  xlabel('Date (2015)');
%  grid on 
%  
%  
%   subplot(4,1,4)
%  plot(ResTime,perDO_4 )
%  hold on 
%   AddShade([0 0], [100  100 ], period  );
%    leg1 = legend('4 st layer');
%  set(leg1,'location','best');
%  set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
%  title([  currentFolder ' percent of area with DO < 0.5mg/L ']);
%  xlim([sTime  eTime]);
%  ylim([ 0   100]);
%  ylabel('%'); 
%  xlabel('Date (2015)');
%  grid on 
% 
%     
%  set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 20; ySize = 20;
% xLeft = 0;   yTop = 0;
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf,[fileOutput  'percent of area with DO less 0 5'],'png');
% saveas(gcf,[fileOutput  'percent of area with DO less 0 5'],'fig');

%------------------------

% 
%  figure
% 
%  plot(ResTime,perDO_1 )
%  hold on 
%   yyaxis right
%  SolRad = anvil.Met.DAFWA.LRD.southPerth.SolRad;
% ss = find( sTime <= SolRad.Date &SolRad.Date <= eTime );
%  plot(SolRad.Date(ss,1), SolRad.Data(ss,1));
%  AddShade([0 0], [100  100 ], period  )
% %  leg1 = legend('1 st layer');
% %  set(leg1,'location','best');
%  set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
%  title([  currentFolder ' percent of area with DO < 0.5mg/L ']);
%  xlim([sTime  eTime]);
% %  ylim([ 0   100]);
% %  ylabel('%'); 
%  xlabel('Date (2015)');
%  grid on 
%  
% PerDO_1_time.Date = ResTime;
%  PerDO_1_time.Data = perDO_1';
%  
%  figure
%  for jj = 1:30
% 
% sTime = datenum(2015,4,jj);
% eTime = datenum(2015,4,jj+1);
% ss = find(  sTime <=PerDO_1_time.Date &   PerDO_1_time.Date < eTime );
% 
% sub = subplot(3,  10,    jj);
%  plot( PerDO_1_time.Date(ss,1), PerDO_1_time.Data(ss,1),'LineWidth',1) 
%  set(sub,'FontSize',8)
% %  set(sub,'FontSize',8,'XGrid','on','XTick',(sTime + eTime) /2,'XTickLabel',{'12'});
% %  set(sub,'XTickLabel','');
% %  set(sub,'FontSize',8,'XTick',[736055 736056],'XTickLabel','');
% title( [datestr(sTime, 'mm/dd') ], 'FontWeight','bold','FontSize',8)
%  timeTick_April(1,1) = sTime  + 6/24;
%   timeTick_April(1,2) = sTime  + 12/24;
%     timeTick_April(1,3) = sTime  + 18/24;
%     
% set(sub,'XTick', timeTick_April , 'XTickLabel', datestr(timeTick_April,'HH')  );
% grid on
% set(sub,'GridAlpha',0.3)
% % ylabel(' ^{\circ}C')
% %  datetick('x', 'HH')
%  ylim([ 0   100])
% % axis off
% end