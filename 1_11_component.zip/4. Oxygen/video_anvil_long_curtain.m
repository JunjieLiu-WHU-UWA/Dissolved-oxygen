
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead

ncfile  = [ dicmodel currentFolder '\Output\anvil.nc']; 
geofile = [ dicmodel currentFolder '\Input\log\' 'anvil_geo.nc' ];
ncid = netcdf.open(ncfile ,'NC_NOWRITE');  

geoncid = netcdf.open(geofile,'NC_NOWRITE');
for ii = 1: 30
    [varname{ii}, xtype(ii), vardimids{ii} ] = netcdf.inqVar(geoncid, ii-1);
    rawGeo.(varname{ii})  = netcdf.getVar(geoncid,ii-1 );
end


fid = fopen('Finalmainline.csv','rt');
dataPoint = textscan(fid,'%f %f ','Headerlines',1,'Delimiter',',');
ss = ~isnan(dataPoint{1,1});
upchannel = dataPoint{1,1}(ss,1);
mainWetland = dataPoint{1,2};
cellMain = zeros(length(upchannel) + length(mainWetland),1);
cellMain(1:length(upchannel), 1 ) = upchannel;
cellMain(length(upchannel) + 1 : length(upchannel) + length(mainWetland) , 1 ) = mainWetland;


ylimit = [7 12];
xlimit = [0 620]; % in m
% disTick = [0 50 100 150 200 250 300 337]';
disTick = [0 50 100 150 200 250 300 350 400 450 500 550 600]';
cax = [0 10]; % the range of the y

varname = 'WQ_OXY_OXY';

title_fig = 'DO (mg/L)';
save_images = 1; 
outdir = [ dicmodel currentFolder '\Output\videoLongCurtain_May\' ];

   if ~exist(outdir,'dir')
        mkdir(outdir);
    end
%__________________________________________________________________________
frames_per_second = 18; % Lowest is 6

% clear hvid;
 hvid = VideoWriter([outdir,varname,'.mp4'],'MPEG-4');
    set(hvid,'Quality',100);
    set(hvid,'FrameRate',frames_per_second);
    framepar.resolution = [1024,768];
    
    open(hvid);


ncid = netcdf.open(ncfile,'NC_NOWRITE');  
varid = netcdf.inqVarID(ncid,'ResTime');
ResTime = netcdf.getVar(ncid,varid) ./24 +  datenum(2001,1,1);

% dat = tfv_readnetcdf(ncfile,'time',1);
% timesteps = dat.Time;

% load('cellMainXY.mat')

% [pt_id,geodata,cells_idx2] = tfv_searchnearest(cellMainXY,rawGeo);  %search the nearest point


cells_idx2 = cellMain;
geodata.X = rawGeo.cell_ctrd(1,cells_idx2)';
geodata.Y = rawGeo.cell_ctrd(2,cells_idx2)';
geodata.Z = rawGeo.cell_Zb(cells_idx2,1);

figure
plot(geodata.X, geodata.Y,'*')
axis equal


sXX = geodata.X(1:end);          
sYY = geodata.Y(1:end);

figure
plot(sXX,sYY)
axis equal

curt.dist(1:length(geodata.X),1) = 0;  % why set the data as zero.
for ii = 1:length(geodata.X)-1        %the distance  is between two points, and we do not need to read the last point
    temp_d = sqrt((sXX(ii+1)-sXX(ii)) .^2 + (sYY(ii+1) - sYY(ii)).^2);  % the distance between the two adjacent point 
    curt.dist(ii+1,1) = curt.dist(ii,1) + temp_d;                                        % the Cumulative distance
end

curt.base = geodata.Z;  %get the elevation   % I dont understand the length of geodata.z is 503

figure
plot(curt.dist, curt.base);

inc = 1;


NN = length(curt.dist);
for ii =  1: NN -1
fillxxx{ii}  = [   curt.dist(ii);...
                  curt.dist(ii) ;...
                  curt.dist(ii+1) ;... 
                   curt.dist(ii+1) ];
fillyyy{ii} =  [   curt.base(ii);...
                7;...
                  7 ;... 
                   curt.base(ii) ];
end

 fillX = cell2mat(fillxxx);
 fillY = cell2mat(fillyyy);
%  figure 
%  patch(fillX, fillY, [0.6 0.6 0.6 ],'edgecolor','none' )

  midCell = 669;
 varid = netcdf.inqVarID(ncid,'WQ_OXY_OXY');
Oxy = netcdf.getVar(ncid,varid) /1000 *32; % the unit is mg/L

 varid = netcdf.inqVarID(ncid,'idx2');
idx2 = netcdf.getVar(ncid,varid) ; 

flag = find(  idx2 == midCell );
midOxyProfile =  Oxy( flag, : )';  % depth averaged DO
% TL = 1:1:length(ResTime)/2 TL = length(ResTime)/2:1:length(ResTime)
for TL = length(ResTime)/2: 1 :length(ResTime)
%     TL= length(ResTime)/3 + 50; TL = length(ResTime)/2:1:length(ResTime)
 hfig = figure('position',[ 250.333333333333          213.666666666667                       636          436.666666666667],'color','w');

 
    subplot(2,1,1);

hhh = plot(ResTime,  midOxyProfile );
hold on 
plot([ResTime(TL)  ResTime(TL)], [0 9 ], 'LineWidth',1.5,'LineStyle','--',...
    'Color',[0 0 0] )
leg1 = legend(hhh,{ 'DO at 1st layer', 'DO at 2nd layer','DO at 3st layer','DO at 4st layer'});
set(leg1,'Location','northwest');
% leg1 = legend('modelled depth averaged DO ');
% set(leg1,'Location','northwest');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable );

xlim([sTime  eTime]);
ylabel('DO  (mg/L)'); 
xlabel('Date (2015)');
grid on 
title(' DO Profile at mid channel' );
    
    data = tfv_readnetcdf(ncfile,'timestep',TL);
    
%     clear functions
    %
    % Build Patch Grid_________________________________________________
    N = length(geodata.X);
    
    for n = 1 : (N - 1)
%         n =16
        i2 = cells_idx2(n);     
        % Traditionl
        NL = data.NL(i2);
        i3 = data.idx3(i2);
        i3z = i3 + i2 -1;
        
        xv{n} = repmat([curt.dist(n);...               %Repeat copies of array
            curt.dist(n);...
            curt.dist(n+1);...
            curt.dist(n+1)],...
            [1 NL]);
        
        zv{n} = zeros(4,NL);
        for i = 1 : NL    % NL represent the vertical layers.
            zv{n}(:,i) = [data.layerface_Z(i3z); ...
                data.layerface_Z(i3z+1); ...
                data.layerface_Z(i3z+1); ...
                data.layerface_Z(i3z)];  % use four point to create a rectangle per column
            i3z = i3z + 1;
        end
        
        SAL{n} = data.(varname)(i3:i3+NL-1) /1000 * 32; %   converion unit of mg/L
    end
    
    model.x = cell2mat(xv);
    model.z = cell2mat(zv);
    
%     for i = 1 : 52
%     
%     zvmax(i) = max(max(zv{i}));
% end    
    
    model.SAL = cell2mat(SAL');
    
            
    
      subplot(2,1,1);
%     axes('position',[0.1 0.15 0.8 0.8],'color','k'); % Bottom Left
    axes('Position',[0.127291242362525 0.15 0.774949083503054 0.33], 'color','k');
    
    P1 = patch(model.x ,model.z,model.SAL','edgecolor','none');hold on
% figure
% % patch(model.x ,model.z,model.SAL','edgecolor','none');
% patch(model.x ,model.z,model.SAL','edgecolor','none');
 patch(fillX, fillY, [0.6 0.6 0.6 ],'edgecolor','none' )
%    max(max( model.SAL))
%     F1 = fill(fillX,fillY,[0.6 0.6 0.6]);
    
    xlim(xlimit);
    ylim(ylimit);
    xlabel('Distance(m)','fontsize',12,'FontWeight','bold','color','k');
    ylabel('Elevation (mAHD)','fontsize',12,'FontWeight','bold','color','k');
    set(gca,'YColor','k','XColor','k','box','on');

    set(gca,'XTick',disTick ,'XTickLabel',num2str(disTick))

    text(0.05,0.9,title_fig,'Color','w','units','normalized','fontsize',16,'FontWeight','bold');
    text(0.65,0.9,datestr(ResTime(TL),'yyyy/mm/dd HH:MM:SS'),'Color','w','units','normalized','fontsize',10,'FontWeight','bold');
    %curt.dist(18,1) location of mid channel
   
 lineRer = line([curt.dist(42,1) curt.dist(42,1)], [7  12]); % the cell number of mid channel is 669
set(lineRer,'LineWidth',1.5, 'Color',[1 0 0]);
text(curt.dist(42,1) - 25  , 12+ 0.2 ,'Mid channel');
    
    caxis(cax);
    
    cb = colorbar;
    
    set(cb,'position',[0.916109979633401 0.15 0.0099999999999999 0.33],'YColor','k');
    colorTitleHandle = get(cb,'Title');
    set(colorTitleHandle ,'String','','color','k','fontsize',8);
    
    
    inc = inc + 1;
        writeVideo(hvid,getframe(hfig));

        
            if (save_images && (mod(TL,6) == 1) )
    
        img_dir = [outdir,varname,'/'];
        if ~exist(img_dir,'dir')
            mkdir(img_dir);
        end
        
        img_name =[img_dir,datestr(ResTime(TL),'yyyymmddHHMM'),'.png'];
        
        saveas(hfig ,img_name);
        
          end
        
        
    close
    
   end
 
  close(hvid);

