
% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead

%---------------------------------------------------

currentOutput = '4. Oxygen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_OXY_OXY');
OXY = netcdf.getVar(ncid,varid) / (1000/32);

varid = netcdf.inqVarID(ncid,'TEMP');
TEMP = netcdf.getVar(ncid,varid);

fileBasicmat = [dicmodel currentFolder '\Output\Basic.mat'];

load(fileBasicmat, 'Basic');

filerawGeomat = [dicmodel currentFolder '\Output\rawGeo.mat'];
load(filerawGeomat, 'rawGeo');
idx2 = Basic.idx2; 
idx3 = Basic.idx3;


cell_X = Basic.cell_X;
cell_Y = Basic.cell_Y;

rawcell_X = rawGeo.face_ctrd(1,:);
rawcell_Y = rawGeo.face_ctrd(2,:);

figure
plot(cell_X, cell_Y,'*')
hold on
plot(rawcell_X, rawcell_Y,'o')

H = Basic.H;

tempIf  = 1;
fid = fopen('Finalmainline.csv','rt');
dataPoint = textscan(fid,'%f %f ','Headerlines',1,'Delimiter',',');
ss = ~isnan(dataPoint{1,1});
upchannel = dataPoint{1,1}(ss,1);
mainWetland = dataPoint{1,2};
cellMain = zeros(length(upchannel) + length(mainWetland),1);
cellMain(1:length(upchannel), 1 ) = upchannel;
cellMain(length(upchannel) + 1 : length(upchannel) + length(mainWetland) , 1 ) = mainWetland;

indexCellWeir = 51+24;
indexCellmid = 24+18;

Distance = zeros(length(cellMain), 2) * nan;

Distance(1,:) = 0;
for ii = 2 : length(cellMain) 
      Distance(ii,1) =  sqrt( (cell_X(cellMain(ii-1),1)  -      cell_X(cellMain(ii),1))^2  + (cell_Y(cellMain(ii-1),1)  -      cell_Y(cellMain(ii),1))^2        );
 end

Distance(:,2) = cumsum(Distance(:,1 ));

for ii =1 :length(cellMain)
    flag =   find(idx2 ==   cellMain(ii,1));
DistanceTemp(ii,:) = mean(TEMP( flag,: ));
deltaTemp(ii,:)   =    TEMP( flag(1,1),: )  -TEMP( flag(end,1),: ) ;  % the differenct between surface and bottom
end

flag = find(idx2 ==  weirCell);

weirTemp = TEMP( flag(1),: );

flag = find(idx2 ==   weirCell);
weirH = H(723,:);

figure
plot(  ResTime , weirTemp)
datetick('x', 19)

figure
plot(  ResTime , weirH)
datetick('x', 19)





figure
subplot(2,1,1)
contourf( Distance(:,2),ResTime, DistanceTemp',  'LineStyle','none')
xlabel('Distance from inlet (m)');
ylabel('Date (2015)');
lineRer = line([round(Distance(indexCellWeir,2)) round(Distance(indexCellWeir,2))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellWeir,2)) -5  , ResTime(end,1) + 1.0 ,'Weir');

lineRer = line([round(Distance(indexCellmid,2)) round(Distance(indexCellmid,2))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellmid,2)) - 25  , ResTime(end,1) + 1.0 ,'Mid channel');
% title([ 'scenario'  currentFolder  ]);
% legend('temp', 'weir')

 xlim([ 0   650])
%  refline(gca,[ 0 Distance(12,2)] ) 
% h = vline(round(Distance(12,2)),'g','The Answer');
% h = vline(round(Distance(12,2)),'g');

set(gca,'YTick', [ datenum(timeTick )], 'YTickLabel',timeLable  );

grid on
title(['Depth averaged water temperature along the main channel' currentFolder  ],'Units',' normalized', 'Position', [0.53 1.04]);
 minTemp =  floor (min(min(DistanceTemp')))     ;
 maxTemp =   ceil (max(max(DistanceTemp')))  ; 
tickTemp = (linspace(     minTemp       ,        maxTemp        , 5 ) )';
 
 
 
% tickTemp = [ 6 8 10 12 14 16 18 20 22]';
% tickTemp = [ 6 8 10 12 14 16 18 20 60]';

ccc = colorbar('Ticks', tickTemp,...
         'TickLabels',num2str(tickTemp))
          
 ccc = colorbar( 'Limits',[  minTemp              maxTemp     ]);
       
       
       
       
       
       
 ccc.Label.String = 'Water temp (^{\circ}C) ';
  [maxT, indexT ] = max(DistanceTemp');
 max(max(DistanceTemp'))
   %-----------------------------------------------------------------------------------------
 subplot(2,1,2)
 contourf( Distance(:,2),ResTime, deltaTemp',  'LineStyle','none')
 
 
 xlabel('Distance from inlet (m)');
ylabel('Date (2015)');
lineRer = line([round(Distance(indexCellWeir,2)) round(Distance(indexCellWeir,2))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellWeir,2)) -5  , ResTime(end,1) + 1.0 ,'Weir');

lineRer = line([round(Distance(indexCellmid,2)) round(Distance(indexCellmid,2))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellmid,2)) - 25  , ResTime(end,1) + 1.0 ,'Mid channel');
  xlim([ 0   650]);
  set(gca,'YTick', [ datenum(timeTick )], 'YTickLabel',timeLable  );

grid on
title('Difference of Water temperature between surface and bottom','Units',' normalized', 'Position', [0.53 1.04]);

 minTemp =  floor (min(min(deltaTemp')))     ;
 maxTemp =   ceil (max(max(deltaTemp')))  ; 
 tickTemp = (linspace(     minTemp ,   maxTemp , 5 ) )';
% tickTemp  = [ -2 0  2 4 6 8 10 12]';
% tickTemp  = [ -5 0  2 4 6 8 10 170]';
ccc = colorbar('Ticks', tickTemp,...
         'TickLabels',num2str(tickTemp))
          
 ccc = colorbar( 'Limits',[  minTemp ,   maxTemp   ]);
      
      
 ccc.Label.String = 'Water temp (^{\circ}C) ';

 
 
 %-----------------save--------------------------------------
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;
ySize = 29;
% xLeft = (21-xSize)/2;
% yTop = (30-ySize)/2;

xLeft = 0;
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf, [ fileOutput  '2 Temperature along the main channel  varied with time ' ],'png');
% saveas(gcf,  [ output '2 Temperature along the main channel  varied with time' ] ,'fig');


%------------------'WQ_OXY_OXY'--------------------------------------------------------------------------------------------
for ii =1 :length(cellMain)
    flag =   find(idx2 ==   cellMain(ii,1));
DistanceOxy(ii,:) = mean(OXY( flag,: ));
deltaOxy(ii,:)   =    OXY( flag(1,1),: )  - OXY( flag(end,1),: ) ;  % the differenct between surface and bottom
end


figure
subplot(2,1,1)
contourf( Distance(:,2),ResTime, DistanceOxy',  'LineStyle','none')
xlabel('Distance from inlet of upstream channel (m)');
ylabel('Date (2015)');
lineRer = line([round(Distance(indexCellWeir,2)) round(Distance(indexCellWeir,2))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellWeir,2)) -5  , ResTime(end,1) + 2.0 ,'Outlet');

lineRer = line([round(Distance(indexCellmid,2)) round(Distance(indexCellmid,2))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellmid,2)) - 25  , ResTime(end,1) + 2.0 ,'Mid channel');
% title([ 'scenario'  currentFolder  ]);
 xlim([ 0   650])

set(gca,'YTick', [ datenum(timeTick )], 'YTickLabel',timeLable  );

grid on
% title(['Depth averaged DO along main channel' currentFolder ],'Units',' normalized', 'Position', [0.53 1.04]);
minOxy = floor (min(min(DistanceOxy'))) ;
maxOxy = ceil (max(max(DistanceOxy'))) ;
 tickTemp = (linspace(   minOxy          ,     maxOxy            , 5 ) )';
ccc = colorbar('Ticks', tickTemp,...
         'TickLabels',num2str(tickTemp));
     ccc = colorbar( 'Limits',[  minOxy ,   maxOxy    ]);
 ccc.Label.String = 'DO (mg/L) ';
  text(0.01,1.05,'(a) ','units','normalized');
   %-----------------------------------------------------------------------------------------
 subplot(2,1,2)
 contourf( Distance(:,2),ResTime, deltaOxy',  'LineStyle','none')
 
 
 xlabel('Distance from inlet of upstream channel (m)');
ylabel('Date (2015)');
lineRer = line([round(Distance(indexCellWeir,2)) round(Distance(indexCellWeir,2))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellWeir,2)) - 5  , ResTime(end,1) + 2.0 ,'Outlet');

lineRer = line([round(Distance(indexCellmid,2)) round(Distance(indexCellmid,2))], [ResTime(1,1)  ResTime(end,1)]);
set(lineRer,'LineWidth',1.5, 'Color',[0.850980392156863 0.329411764705882 0.101960784313725]);
text(round(Distance(indexCellmid,2)) - 25  , ResTime(end,1) + 2.0 ,'Mid channel');
  xlim([ 0   650]);
  set(gca,'YTick', [ datenum(timeTick )], 'YTickLabel',timeLable  );

grid on
% title('the difference of DO between surface and bottom','Units',' normalized', 'Position', [0.53 1.04]);
mindeltaOxy =  floor (min(min(deltaOxy')))   ;
maxdeltaOxy =   ceil (max(max(deltaOxy')))      ;
 tickTemp = (linspace(   -4      ,      4      , 6 ) )';
ccc = colorbar('Ticks', tickTemp,...
         'TickLabels',num2str(tickTemp))
          ccc = colorbar( 'Limits',[ -4,  4   ]);
 ccc.Label.String = 'DO_{surface} - DO_{bottom} (mg/L)';
   text(0.01,1.05,'(b) ','units','normalized');
 %-----------------save--------------------------------------
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15;
ySize = 21;
% xLeft = (21-xSize)/2;
% yTop = (30-ySize)/2;

xLeft = 0; 
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

% saveas(gcf, [  fileOutput  '2 DO along the main channel  varied with time ' ],'png');
% saveas(gcf,  [ output '2 DO along the main channel  varied with time' ] ,'fig');
% print(gcf,[ fileOutput 'Fig 9 DO along the main channel  varied with time.tiff'],'-dtiff','-r300');
print(gcf,[fileOutput 'Fig 9 DO along the main channel  varied with time.png'],'-dpng','-r300');