
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead

currentOutput = '4. Oxygen\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];

if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end
fidHypoxia = [ fileOutput  'percent of area with depth average DO less 2.csv'];
fid = fopen(fidHypoxia,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
Hypoxia.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Hypoxia.Data = data{1,2};


file =  [dicmodel currentFolder '\Output\' ];
fidAnaerobic = [ file '4. Oxygen\percent of area with depth average DO less 0 5.csv'];
fid = fopen(fidAnaerobic,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
Anaerobic.Date = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Anaerobic.Data = data{1,2};

typicalTime = (datenum(2015, 4, 21, 0, 0, 0 ) : 1/24/60 * 10:  datenum(2015, 4, 23, 23, 50, 0 ))';

typicalStime = datenum(2015, 4, 21, 0, 0, 0 );
typicalEtime = datenum(2015, 4, 23, 23, 50, 0 );



 typicalTimeTick = {'2015/04/21 00:00:00'...
                  '2015/04/21 06:00:00'...
                  '2015/04/21 12:00:00'...
                  '2015/04/21 18:00:00'...
                  '2015/04/22 00:00:00'...
                  '2015/04/22 06:00:00'...
                  '2015/04/22 12:00:00'...
                  '2015/04/22 18:00:00'...
                  '2015/04/23 00:00:00'...
                  '2015/04/23 06:00:00'...
                  '2015/04/23 12:00:00'...
                  '2015/04/23 18:00:00'...
                  '2015/04/24 00:00:00'}';
typicalTimeLable = { ' 00'   '06'  '12'   ' 18' ...
                                   ' 00' ' 06'  '12'   ' 18' ...
                                   ' 00' ' 06'  '12'   ' 18' ...
                                   ' 00'}';  
% --------------typical pattern-------------------
 figure1 = figure;
 ss = find(  typicalStime      <=      Hypoxia.Date &        Hypoxia.Date <= typicalEtime );
 plot(  Hypoxia.Date(ss)      , Hypoxia.Data(ss)  )
 hold on 
 ss = find(  typicalStime      <=      Anaerobic.Date &       Anaerobic.Date<= typicalEtime );
 plot(  Anaerobic.Date(ss) , Anaerobic.Data(ss)  )
 leg1 = legend('Hypoxia', 'Anaerobic area');
set(leg1,...
    'Position',[0.289821125805358 0.5844406512605041 0.343336724313327 0.04375],...
    'Orientation','horizontal');
 set(gca,'XTick',[ datenum( typicalTimeTick )],'XTickLabel',typicalTimeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
grid on 
ylabel('%');

annotation(figure1,'textbox',...
    [0.0966256358087489 0.00294117647058821 0.137351983723296 0.0558823529411765],...
    'String','Apr 21',...
    'LineStyle','none',...
    'FitBoxToText','off');

annotation(figure1,'textbox',...
    [0.354001017293999 0.00294117647058826 0.137351983723296 0.0558823529411765],...
    'String','Apr 22',...
    'LineStyle','none',...
    'FitBoxToText','off');

annotation(figure1,'textbox',...
    [0.616462868769075 0.00294117647058826 0.137351983723296 0.0558823529411764],...
    'String','Apr 23',...
    'LineStyle','none',...
    'FitBoxToText','off');

  set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 9;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput 'typical pattern of  hypoxia and anaerobic '],'png');

print(gcf,[ fileOutput 'Fig 11 typical pattern of  hypoxia and anaerobic.tiff'],'-dtiff','-r300');
print(gcf,[fileOutput 'Fig 11 typical pattern of  hypoxia and anaerobic.png'],'-dpng','-r300');


%-----------------dynamic of hypoxia and anaerobic area---------------------
figure
subplot(2,1,1)
plot(Hypoxia.Date, Hypoxia.Data)
hold on 

AddShade([0 0] , [100  100] , period );
%  leg1 = legend('Hypoxia' );
% set(leg1,...
%     'location','best',...
%     'Orientation','horizontal');
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% grid on
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Hypoxia (%)'});
% title([currentFolder ])
%
subplot(2,1,2)
 plot(  Anaerobic.Date, Anaerobic.Data)

AddShade([0 0] , [100  100] , period );
%  leg1 = legend('Anaerobic area');
% set(leg1,...
%     'position', [0.517203289250594 0.390730031838316 0.2029501525941 0.0442708333333332] ,...
%     'Orientation','horizontal');
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% grid on
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Anaerobic area (%)'});

%  grid on 
 
  set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 7.5;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [fileOutput 'Dynamic of hypoxia and anaerobic area'],'png');
print(gcf,[ fileOutput 'Dynamic of hypoxia and anaerobic area_seperate.tiff'],'-dtiff','-r300');
print(gcf,[fileOutput 'Dynamic of hypoxia and anaerobic area_seperate.png'],'-dpng','-r300');

%--------------------target percent ----------------------

HypoxiaNight50 = StartEndtimePercent( Hypoxia, 50 ); % the unit of duration is hour

HypoxiaNight80 = StartEndtimePercent( Hypoxia, 80 ); % the unit of duration is hour

figure
subplot(2, 1, 1)
h(1) = plot( HypoxiaNight50.Date ,HypoxiaNight50.durt, '*' ) ;
hold on
 h(2) = plot( HypoxiaNight80.Date ,HypoxiaNight80.durt, 'o' ) ;
hline = refline([0 24]);
hline.Color = 'r';
AddShade([0 0] , [40 40] , period );
 leg1 = legend(h(1:2), '50%','80%');
set(leg1,'Location','best',...
    'Orientation','horizontal', ...
    'box', 'on');
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({'Hypoxia ', '(Hours)'});
%  text( sTime + 8,800,'(a)');
%  text(0.08,1.1,'(f)','units','normalized');
% title([currentFolder '   ' 'Duration of hypoxia >50% and 80%' ])
 grid on 
 
%   set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperUnits', 'centimeters');
% xSize = 20; ySize = 10;
% xLeft = 0;   yTop = 0;
% set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [fileOutput 'Duration hypoxia 50 80'],'png');

% anaerobic



Anaerobic50 = StartEndtimePercent( Anaerobic, 50 ); % the unit of duration is hour

Anaerobic80 = StartEndtimePercent( Anaerobic, 80 ); % the unit of duration is hour

subplot(2, 1, 2)
h(1) = plot( Anaerobic50.Date ,Anaerobic50.durt, '*' ) ;
hold on
 h(2) = plot( Anaerobic80.Date ,Anaerobic80.durt, 'o' ) ;
% hline = refline([0 24]);
% hline.Color = 'r';
AddShade([0 0] , [20 20] , period );
 leg1 = legend(h(1:2), '50%','80%');
set(leg1,'Location','best',...
    'Orientation','horizontal', ...
    'box', 'on');
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
ylabel({ 'Anaerobic ', '(Hours)'});
%  text( sTime + 8,800,'(a)');
%  text(0.08,1.1,'(f)','units','normalized');
% title([currentFolder '   ' 'Duration of anaerobic >50% and 80%' ])
 grid on 
 
  set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 7.5;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf, [fileOutput  'Duration anaerobic hypoxia 50 80'],'png');

print(gcf,[ fileOutput 'Fig 12 Duration anaerobic hypoxia 50 80.tiff'],'-dtiff','-r300');
print(gcf,[fileOutput 'Fig 12 Duration anaerobic hypoxia 50 80.png'],'-dpng','-r300');


%%%%%%%%%%%%%%%%%%%%%
% combine hypoxia and anaerrobic area
figure

h(1) = plot(Hypoxia.Date, Hypoxia.Data);
hold on 

AddShade([0 0] , [100  100] , period );
%  leg1 = legend('Hypoxia' );
% set(leg1,...
%     'location','best',...
%     'Orientation','horizontal');
% set(gca,'XTick',[ datenum(timeTick )],'XTickLabel','','TickLength',[0.005 0.015]);
% set(gca,'GridAlpha',0.5);
% % grid on
% % set(pp, 'Color',[0 0 0]); % black
% box(gca,'on');
% clear ss
% xlim([sTime  eTime]);
% ylabel({'Hypoxia (%)'});
% % title([currentFolder ])
%
% subplot(2,1,2)
 h(2) = plot(  Anaerobic.Date, Anaerobic.Data);

AddShade([0 0] , [100  100] , period );
 leg1 = legend(h(1:2), 'Hypoxia'   , 'Anaerobic');
%  set(leg1,...
%     'location','best',...
%     'Orientation','vertical');
set(leg1,...
    'position', [0.717203289250594 0.690730031838316 0.2029501525941 0.0442708333333332] ,...
    'Orientation','vertical');
set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
set(gca,'GridAlpha',0.5);
% grid on
% set(pp, 'Color',[0 0 0]); % black
box(gca,'on');
clear ss
xlim([sTime  eTime]);
% ylabel({'Anaerobic area (%)'});
ylabel({'%'});
%  grid on 
 
  set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 15; ySize = 7.5;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
% saveas(gcf, [fileOutput 'Dynamic of hypoxia and anaerobic area'],'png');
print(gcf,[ fileOutput 'Fig 10 Dynamic of hypoxia and anaerobic area.tiff'],'-dtiff','-r300');
print(gcf,[fileOutput 'Fig 10 Dynamic of hypoxia and anaerobic area.png'],'-dpng','-r300');