% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
%--------------------------------------------------------
currentOutput = '7. Pelagic productivity\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'WQ_DIAG_PHY_GPP');
PHY_GPP = netcdf.getVar(ncid,varid) /1000* 32 ;  %mmol/m3/d to g O2 /m3/d; 
PHY_GPP = PHY_GPP *(-1) ;


varid = netcdf.inqVarID(ncid,'WQ_PHY_PHY_GRN');
PHY_GRN = netcdf.getVar(ncid,varid) /1000* 12  ;  %mmol/m3/d to g C /m3/d; 


[ PHY_GPPSumSpace ,PHY_GPPCVMean ]  = ThreeVolume2twoarea(PHY_GPP, Basic, Cell_whole_channel);

[ PHY_GRNSumSpace ,PHY_GRNCVMean ]  = ThreeVolume2twoarea(PHY_GRN, Basic, Cell_whole_channel);

figure
subplot(2, 1, 1)
plot(ResTime, PHY_GPPSumSpace./1000) % the unit is kg/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mass flux of  pelagic primary productivity across  the whole  wetland ']);
xlim([sTime  eTime]);
ylabel({'Pelagic parimary producitvity' ' (kg O_{2}  /d)'})      
xlabel('Date (2015)');
grid on 

subplot(2, 1, 2)
plot(ResTime, PHY_GPPCVMean)
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
 title([  currentFolder   '    ' ' Mean rate flux of  pelagic primary productivity across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Pelagci primary producitvity' ' (g O_{2} /m^{2}/d)'})      
xlabel('Date (2015)');
grid on 


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;
ySize = 15;
% xLeft = (21-xSize)/2;
% yTop = (30-ySize)/2;
xLeft = 0;
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Pelagic primary productivity across  the whole wetland'],'png');
saveas(gcf,[fileOutput  'Pelagic primary productivity across  the whole wetland'],'fig');



    filecsv =  [ fileOutput 'Pelagic primary productivity_wholeWetland.csv' ];
    
    fid = fopen(filecsv,'wt');

fprintf(fid,'ISOTime, PHY_GPPSumSpace(g O2 /d), PHY_GPPCVMean (g O2 /m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f \n',  PHY_GPPSumSpace(1,i), PHY_GPPCVMean(1,i) );
end
fclose(fid);

% calculate the daily value 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PHY_GPPDaily = dailySum(PHY_GPPCVMean);
% filePelaDaily = [ currentOutput 'PelagicPrimaryProductivityDaily_rate_wholeWetland.csv'];
% writeDaily(PHY_GPPDaily,  filePelaDaily  ,  'PelagicPrimaryProductivityDaily(g O2/m2 /d)'  );
% [ PHY_GPPDailynonStorm,  PHY_GPPDailyStorm ]   = divide2period( PHY_GPPDaily);
% [h_PHY_GPPDaily,p_PHY_GPPDaily, ci, stats] = ...
% ttest2(PHY_GPPDailynonStorm.Data,  PHY_GPPDailyStorm.Data);





% plegaic net productivity
varid = netcdf.inqVarID(ncid,'WQ_DIAG_PHY_NCP');
PHY_NCP = netcdf.getVar(ncid,varid) /1000* 32;  %mmol/m3/d to g O2 /m3/d; 
PHY_NCP  = PHY_NCP * (-1);


%-------------pelagic reapiration ----------------------


PHY_P_res = PHY_GPP - PHY_NCP ;
PHY_P_res = PHY_P_res * (-1);
[ PHY_P_resSumSpace ,PHY_P_resCVMean ]  = ThreeVolume2twoarea(PHY_P_res, Basic, Cell_whole_channel);


figure
subplot(2, 1, 1)
plot(ResTime, PHY_P_resSumSpace./1000) % the unit is kg/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mass flux of  pelagic respiration across  the whole  wetland ']);
xlim([sTime  eTime]);
ylabel({'Pelagci respiration' ' (kg O_{2}  /d)'})      
xlabel('Date (2015)');
grid on 

subplot(2, 1, 2)
plot(ResTime, PHY_P_resCVMean)
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
 title([  currentFolder   '    ' ' Mean rate flux of  pelagic respiration across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Pelagci respiration' ' (g O_{2} /m^{2}/d)'})      
xlabel('Date (2015)');
grid on 


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Pelagic respiration across  the whole wetland'],'png');
saveas(gcf,[fileOutput  'Pelagic respiration across  the whole wetland'],'fig');



    filecsv =  [ fileOutput 'Pelagic reapiration_wholeWetland.csv' ];
    
    fid = fopen(filecsv,'wt');

fprintf(fid,'ISOTime, PHY_P_resSumSpace(g O2 /d), PHY_P_resCVMean (g O2 /m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f \n',  PHY_P_resSumSpace(1,i), PHY_P_resCVMean(1,i) );
end
fclose(fid);




%
PHY_NCP = PHY_GPP - PHY_P_res;  % this net production is calculated by myself. 
[ PHY_NCPSumSpace ,PHY_NCPCVMean ]  = ThreeVolume2twoarea(PHY_NCP, Basic, Cell_whole_channel);


figure
subplot(2, 1, 1)
plot(ResTime, PHY_NCPSumSpace./1000) % the unit is kg/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mass flux of  pelagic net productivity across  the whole  wetland ']);
xlim([sTime  eTime]);
ylabel({'Pelagci net producitvity' ' (kg O_{2}  /d)'})      
xlabel('Date (2015)');
grid on 

subplot(2, 1, 2)
plot(ResTime, PHY_NCPCVMean)
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
 title([  currentFolder   '    ' ' Mean rate flux of  pelagic net productivity across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Pelagci net producitvity' ' (g O_{2} /m^{2}/d)'})      
xlabel('Date (2015)');
grid on 


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Pelagic net productivity across  the whole wetland'],'png');
saveas(gcf,[fileOutput  'Pelagic net productivity across  the whole wetland'],'fig');



    filecsv =  [ fileOutput 'Pelagic net productivity_wholeWetland.csv' ];
    
    fid = fopen(filecsv,'wt');

fprintf(fid,'ISOTime, PHY_NCPSumSpace(g O2 /d), PHY_NCPCVMean (g O2 /m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f \n',  PHY_NCPSumSpace(1,i), PHY_NCPCVMean(1,i) );
end
fclose(fid);











%--------------------------------------------------------------------
  
 varid = netcdf.inqVarID(ncid,'WQ_DIAG_PHY_TCHLA');
TCHLA = netcdf.getVar(ncid,varid);  % the unit is ug/L
idx2midCell = find(  idx2 == midCell );

midTCHLAProfile = TCHLA(idx2midCell(:,1),: );

ob_TCHLA = anvil.SWQ.Main_stream.AAQ_April.Chl_a;

ob_TCHLA_hour =  Second2hour(ob_TCHLA); 
% figure
% plot(ob_TCHLA_hour.Date, ob_TCHLA_hour.Data)

figure
plot(ob_TCHLA_hour.Date, ob_TCHLA_hour.Data, '*'); % the unit of observed data is ug/L
hold on 
plot(ResTime,  midTCHLAProfile );

legend('Observed ', 'modelled 1st layer total chlorophyll-a',  'modelled 2st layer total chlorophyll-a', 'modelled 3st layer total chlorophyll-a', 'modelled 4st mid total chlorophyll-a');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([ currentFolder    '    ' 'Total chlorophyll-a at mid channel ']);
xlim([sTime  eTime]);
ylabel({'Total chlorophyll-a' '(ug/L)'}); 
xlabel('Date (2015)');
grid on 

%------------------------------------------------
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;
ySize = 15;

xLeft = 0;
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput 'Total chlorophyll-a Mid channel Model'],'png');
saveas(gcf,[fileOutput 'Total chlorophyll-a  Mid channel Model'],'fig');
    


 filecsv = [ fileOutput 'midTCHLA.csv'];
fid = fopen( filecsv,'wt');
fprintf(fid,'ISOTime, first layer of  Chlorophyll, second layer of  Chlorophyll, third layer of  Chlorophyll, fourth layer of  Chlorophyll (ug/L) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f, %4.4f, %4.4f,%4.4f \n',    midTCHLAProfile(1,i),  midTCHLAProfile(2,i),  midTCHLAProfile(3,i),  midTCHLAProfile(4,i));
end
fclose(fid);
 

%------------------------------------------------------------------

  
figure
subplot(2, 1, 1)
plot(ResTime, PHY_GRNSumSpace./1000) % the unit is kg/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' '  pelagic biomass across  the whole  wetland ']);
xlim([sTime  eTime]);
ylabel({'Pelagic biomass' ' (g C/m2/.d )'})      
xlabel('Date (2015)');
grid on 

subplot(2, 1, 2)
plot(ResTime, PHY_GRNCVMean)
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
 title([  currentFolder   '    ' ' pelagic biomass across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Pelagci biomass' ' (g C/m2 )'})      
xlabel('Date (2015)');
grid on 


set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;
ySize = 15;
% xLeft = (21-xSize)/2;
% yTop = (30-ySize)/2;
xLeft = 0;
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Pelagic biomass across  the whole wetland'],'png');
saveas(gcf,[fileOutput  'Pelagic biomass across  the whole wetland'],'fig');



    filecsv =  [ fileOutput 'Pelagic biomass_wholeWetland.csv' ];
    
    fid = fopen(filecsv,'wt');

fprintf(fid,'ISOTime, PHY_GRNSumSpace(g C /d), PHY_GRNCVMean (g C /m2/d) \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f \n',  PHY_GRNSumSpace(1,i), PHY_GRNCVMean(1,i) );
end
fclose(fid);


%--------------------------------------------------------------------
