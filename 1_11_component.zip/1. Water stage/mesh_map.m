addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead

shpfile = [ dicmodel  currentFolder '\Geo\Anvil_sed_CV_elevation_95_cont.shp' ];

shp = shaperead(shpfile);
figure
mapshow(shp)
figure
mapshow(shp.X, shp.Y)
% figure
% mapshow(shp, 'FaceColor', [1 1 1], 'EdgeColor', [ 0 0 0], 'FaceAlpha', 0.1,'EdgeAlpha', 0.5);
% hold on
% 
% figur

file_2dm =  [dicmodel  currentFolder '\Geo\Anvil_sed_CV_elevation_95.2dm'];

[XX,YY,ZZ,nodeID,faces,X,Y,Z,ID,MAT] = tfv_get_node_from_2dm(file_2dm);

figure
contour(XX, YY, ZZ)


% x=xyz(:,1);
% y=xyz(:,2);
% z=xyz(:,3);
[Xg,Yg]=meshgrid(min(XX):max(XX),  min(YY):max(YY));
Zg=griddata(XX, YY, ZZ, Xg, Yg);
figure
contour(Xg, Yg, Zg)
