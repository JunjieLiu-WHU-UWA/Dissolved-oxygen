
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
currentOutput = '1. Water stage\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end


% read boundary for daily inflow


file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
FlowIN.Date = ISOTime_in;
FlowIN.Data = data_inlet{1,2};
 FlowInDaily =  dailySum(FlowIN); % the unit is m3/s 
 
 FlowInDaily.Data = FlowInDaily.Data * 24*3600; 
 
 %   daily stage at weir 
 
fileStageweir = [ dicmodel currentFolder  '\Output\1. Water stage\WeirWaterStage.csv'];
fid = fopen(fileStageweir,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'dd/mm/yyyy HH:MM:SS');
Stageweir.Date = dateTime;
Stageweir.Data = data{1,2}; % the unit is m
 
dailyStartStageweir =  dailyCertain(Stageweir); %unit is m3

dailyStartVolume.Date = dailyStartStageweir.Date;
dailyStartVolume.Data = zeros(length(dailyStartStageweir.Date  )   ,   1);

load('E:\Research in UWA\overview of data available in anvil\1. BATHYMETRY/bathy.mat');

 for ii = 1: length(dailyStartVolume.Date  )

      ss = find(   abs(bathy.stage - dailyStartStageweir.Data(ii) ) < 0.0006  );
        
      if ss
          dailyStartVolume.Data(ii,1) = bathy.vol(ss(1),1); % the unit is m3
      end

  end
 
 ratio_update.Date = FlowInDaily.Date;
 ratio_update.Data = FlowInDaily.Data ./  dailyStartVolume.Data;
 
 figure
 plot(ratio_update.Date ,ratio_update.Data, '*' );
%  figure
%  plot( dailyStartStageweir.Date , dailyStartStageweir.Data, '*'  )
 

 filename = [ fileOutput 'ratio_update_daily.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime,  ratio_uptake (-) \n');
for i = 1:length(ratio_update.Date)
    fprintf(fid,'%s,',datestr(ratio_update.Date(i),'yyyy/mm/dd'));
    fprintf(fid,'%4.4f \n',    ratio_update.Data(i));
end
fclose(fid);

 
 
