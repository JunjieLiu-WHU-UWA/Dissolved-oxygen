
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead


shpfile = [ dicmodel  currentFolder '\Geo\Anvil_sed_CV_elevation_95_cont.shp' ];




shp = shaperead(shpfile);
contour(shp)
figure
mapshow(shp)
        mapshow(shp, 'FaceColor', [1 1 1], 'EdgeColor', [ 0, 0.4470, 0.7410], 'FaceAlpha', 0.1);
axis off

% 
% 'FaceColor', [0.3 0.5 1]
% geoshow( shp, 'FaceColor', [0.5 0.7 0.5])
% 
% figure 
% plot(shp.X, shp.Y )