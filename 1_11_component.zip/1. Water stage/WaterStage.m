% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
%-----------------------------------------------------------------------------

currentOutput = '1. Water stage\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

varid = netcdf.inqVarID(ncid,'H');
H = netcdf.getVar(ncid,varid);
max(max(H))
min(min(H))
ModelWeirH.Date = ResTime;
ModelWeirH.Data = H(weirCell,:);

 obseveWeirH = anvil.Hydrology.MSANVCBOUT.HRD.Route.YY2015.Stage_5min_Mean;
 ss =  find (   sTime <=  obseveWeirH.Date  & obseveWeirH.Date <= eTime  );
 observeWeirH0405.Date = obseveWeirH.Date(ss,1);
 observeWeirH0405.Data = obseveWeirH.Data(ss,1);
 figure
 plot(ModelWeirH.Date, ModelWeirH.Data)
 hold on
  plot(observeWeirH0405.Date, observeWeirH0405.Data)
 hold on
 
leg1 = legend(' Modelled water stage',  'obseved water stage');
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([     currentFolder   '   -- water stage at  weir']);
xlim([sTime  eTime]);
ylabel('Water stage (m)'); 
xlabel('Date (2015)');
grid on 

 saveas(gcf,[fileOutput ' Weir water stage modelled and observed'],'png');
 saveas(gcf,[fileOutput  ' Weir water stage modelled and observed'],'fig'); 

 Var = ModelWeirH;
  filename = [ fileOutput  'WeirWaterStage.csv'];

fid = fopen(filename,'wt');

fprintf(fid,'ISOTime, WeirWaterStage (m)\n');

for i = 1:length(Var.Date )
    fprintf(fid,'%s,',datestr(Var.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',    Var.Data(i)  );
end
fclose(fid);

figure

ModelinletH.Date = ResTime;
ModelinletH.Data = H(inletCell ,:);
plot(ModelinletH.Date  ,  ModelinletH.Data   )

hold on
 obseveInletH = anvil.Hydrology.MSAB2.HRD.Route.YY2015.Stage_5min_Mean;
 ss =  find (   sTime <=  obseveInletH.Date  & obseveInletH.Date <= eTime  );
 observeInletH0405.Date = obseveInletH.Date(ss,1);
 observeInletH0405.Data = obseveInletH.Data(ss,1);
 
  plot(observeInletH0405.Date, observeInletH0405.Data)
 hold on
 
 leg1 = legend(' Modelled water stage',  'obseved water stage');
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([     currentFolder   '   -- water stage at  inlet']);
xlim([sTime  eTime]);
ylabel('Water stage (m)'); 
xlabel('Date (2015)');
grid on 

 saveas(gcf,[fileOutput 'Inlet water stage modelled and observed'],'png');
 saveas(gcf,[fileOutput  'Inlet water stage modelled and observed'],'fig'); 


