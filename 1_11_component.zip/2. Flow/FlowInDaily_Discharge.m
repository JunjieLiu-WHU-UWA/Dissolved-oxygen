% clearvars -except anvil
% close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
BasicRead
file =  [dicmodel currentFolder '\Output\' ];

currentOutput = '2. Flow\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

file_inflow =  [ dicmodel currentFolder   '\BCs\'   BC_inflow ];
fid = fopen(file_inflow ,'rt');
str = repmat('%f ', [1 24] );
data_inlet = textscan(fid,['%s' str],'Headerlines',1,'Delimiter',',');
ISOTime_in = datenum(data_inlet{1,1},'dd/mm/yyyy HH:MM:SS');
FlowIN.Date = ISOTime_in;
FlowIN.Data = data_inlet{1,2};


figure
plot(FlowIN.Date   , FlowIN.Data )
AddShade([0,0] , [1.2,1.2], period  )
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder '   Inflow rate ']);
xlim([sTime  eTime]);
ylabel('(m^{3}/s)');
xlabel('Date (2015)');
grid on 
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 8;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
saveas(gcf,[fileOutput  ' Inflow rate'],'png');
saveas(gcf,[fileOutput  ' Inflow rate'],'fig');


% daily discharge 

flowINDaily = dailySumFlow(FlowIN);
fileFlowINDaily = [ file '2. Flow\FlowInDaily_wholeWetland.csv'];
writeDaily(flowINDaily,  fileFlowINDaily  ,  'flowIn(m3/s)'  );

% InflowOxy.Date  = ISOTime_in;
% InflowOxy.Data  = data_inlet{1,8} ;  %  the unit is  mmol /m3

% transInOxy   = calculationFlux(FlowIN.Date,   FlowIN.Data,   InflowOxy.Data); % mmol/s
% transInOxy.Data = transInOxy.Data  * Oxy_mmol_g  * day_second  ; % the unit is g/d


%-------------------------------------read flux file --------------------------------------

fileFluxmat = [ dicmodel currentFolder  '\Output\Flux.mat'];
% save Flux.mat Flux
load(fileFluxmat, 'Flux');



ModelWeirFlow.Date = Flux.NS12.mDate;
ModelWeirFlow.Data = Flux.NS12.Flow + Flux.NS13.Flow + Flux.NS14.Flow + ...
                                    Flux.NS15.Flow + Flux.NS16.Flow;


 obseveWeirFlow = anvil.Hydrology.MSANVCBOUT.HRD.Route.YY2015.Discharge_5min_Mean;
 ss =  find (   sTime <=  obseveWeirFlow.Date  & obseveWeirFlow.Date <= eTime  );
 observeWeirFlow0405.Date = obseveWeirFlow.Date(ss,1);
 observeWeirFlow0405.Data = obseveWeirFlow.Data(ss,1);
 
 
 % the interval of observeWeirFlow0405.Data is 5 min, while the interval of
 % ModelWeirFlow.Data is 10 min. 
 % So extract the data from odd sequence
 odd_len = (1: 2: length(observeWeirFlow0405.Data))';

[mae, rmse, ns]    = modelPerformance( observeWeirFlow0405.Data( odd_len),   ModelWeirFlow.Data );

 filename = [ fileOutput 'model_performance_flowrate.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'mae, RMSE, Nash-Sutcliffe model efficiency \n');
 fprintf(fid,'%4.4f, %4.4f, %4.4f  \n', mae, rmse, ns   );
fclose(fid);


figure
plot( observeWeirFlow0405.Data( odd_len) ,  ModelWeirFlow.Data , '*' )

  xlabel('Measured flowrate (m^{3}/s )');

      ylabel('Modelled flowrate (m^{3}/s )');
        xlim( [ 0  1.2 ]);
        ylim([ 0 1.2]);
      hline = refline(1,0);
      hline.Color = 'r';
      grid on
 
      title( [ currentFolder  'correlation flowrate ']);
 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 10; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf, [fileOutput 'correlation observed and modelled Flowrate'],'png');


 
 figure
 plot(ModelWeirFlow.Date, ModelWeirFlow.Data)
 hold on
 plot(observeWeirFlow0405.Date, observeWeirFlow0405.Data)
 hold on
 leg1 = legend(' Modelled water flow',  'Measured water flow');
 set(leg1,'Location','northwest');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([ currentFolder '     discharge at  weir']);
xlim([sTime  eTime]);
ylabel('Discharge (m3/s)'); 
xlabel('Date (2015)');
grid on 

 set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 10;
xLeft = 0;   yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])
 saveas(gcf,[fileOutput 'Weir Discharge modelled and observed'],'png');
 saveas(gcf,[fileOutput 'Weir Discharge modelled and observed'],'fig');  

 filename = [ fileOutput 'Outflow_weir_10min.csv'];
fid = fopen(filename,'wt');
fprintf(fid,'ISOTime, Outflow (m3/s)\n');
for i = 1:length(ModelWeirFlow.Date)
    fprintf(fid,'%s,',datestr(ModelWeirFlow.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',     ModelWeirFlow.Data(i));
end
fclose(fid);

flowOutDaily = dailySumFlow(ModelWeirFlow);
fileFlowOutDaily = [ file '2. Flow\FlowOutDaily_wholeWetland.csv'];
writeDaily(flowOutDaily,  fileFlowOutDaily  ,  'flowOut(m3/s)'  );




% comparison between inlet and outlet
figure
plot(FlowIN.Date , FlowIN.Data , 'Color',[0 0 1])
hold on
plot(ModelWeirFlow.Date, ModelWeirFlow.Data, 'Color',[1 0 0] )
 hold on

leg1 = legend(' Inlet',  'Outflow');
set(leg1,'Location','northwest');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([ currentFolder '     Discharge at  inlet and  weir']);
xlim([sTime  eTime]);
ylabel('Discharge (m3/s)'); 
xlabel('Date (2015)');
grid on 
 saveas(gcf,[fileOutput 'ComparisonBetweenInletOutlet'],'png');
 saveas(gcf,[fileOutput 'ComparisonBetweenInletOutlet'],'fig');  


function   varDaily =  dailySumFlow(var);
[yy, mm, dd, HH, MM, ~] = datevec(var.Date);
year = unique(yy);
month = unique(mm);
day = unique(dd);
hour = unique(HH);
minute = unique(MM);
flag = 0;
for yi = 1:length(year)
    for mi =1: length(month)
        for di =1: length(day)
                      ss = find(  yy == year(yi) & mm== month(mi) & dd == day(di)  );
                      if ~isempty(ss)
			           flag = flag +1; 
			           varDaily.Date(flag,1) = datenum(year(yi), month(mi),  day(di) );
                       varDaily.Data(flag,1) = trapz(var.Date(ss,1) , var.Data(ss,1) ) ;
                     end
       
           
		end
		end
end
end