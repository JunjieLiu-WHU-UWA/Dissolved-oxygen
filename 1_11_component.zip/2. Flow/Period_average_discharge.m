% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% BasicRead


file =  [dicmodel currentFolder '\Output\' ];


FlowIn = [ file '2. Flow\FlowInDaily_wholeWetland.csv'];
fid = fopen(FlowIn,'rt');
data = textscan(fid,'%s %f ','Headerlines',1,'Delimiter',',');
dateTime = datenum(data{1,1},'yyyy/mm/dd');
FlowIN.Date = dateTime;
FlowIN.Data = data{1,2}; % the unit is m3/s


FlowIN_Period = PeriodAverageFlow(FlowIN);

 filename = [ file '\2. Flow\Discharge_inlet_period.csv'];
fid = fopen(filename,'wt');

fprintf(fid,' Discharge_inlet_period (m3/s)  \n');

for i = 1:length(FlowIN_Period)
    fprintf(fid,'%4.4f \n',   ....
    FlowIN_Period(i)  );
 
end
fclose(fid);


function   varPeriod = PeriodAverageFlow(var)

Period_1(1,1) = datenum('2015\04\01'); Period_1(2,1) = datenum('2015\04\06');
Period_2(1,1) = datenum('2015\04\07'); Period_2(2,1) = datenum('2015\04\14');
Period_3(1,1) = datenum('2015\04\15'); Period_3(2,1) = datenum('2015\05\02');
Period_4(1,1) = datenum('2015\05\03'); Period_4(2,1) = datenum('2015\05\05');
Period_5(1,1) = datenum('2015\05\06'); Period_5(2,1) = datenum('2015\05\15');
Period_6(1,1) = datenum('2015\05\16'); Period_6(2,1) = datenum('2015\05\21');
Period_7(1,1) = datenum('2015\05\22'); Period_7(2,1) = datenum('2015\05\31');

ss_1 =  find( Period_1(1,1) <=    var.Date &   var.Date  <=    Period_1(2,1) )  ;
varPeriod(1,1) = mean(var.Data(ss_1,1));

ss_2 = find(   Period_2(1,1) <=    var.Date &   var.Date  <=    Period_2(2,1) )     ;
varPeriod(2,1) = mean(var.Data(ss_2,1));

ss_3 =   find(Period_3(1,1) <=    var.Date &   var.Date  <=    Period_3(2,1)     ) ;
varPeriod(3,1) = mean(var.Data(ss_3,1));

ss_4 =  find ( Period_4(1,1) <=    var.Date &   var.Date  <=    Period_4(2,1) )    ;
varPeriod(4,1) = mean(var.Data(ss_4,1));

ss_5 =  find( Period_5(1,1) <=    var.Date &   var.Date  <=    Period_5(2,1)   )   ;
varPeriod(5,1) = mean(var.Data(ss_5,1));

ss_6 =  find( Period_6(1,1) <=    var.Date &   var.Date  <=    Period_6(2,1)   )   ;
varPeriod(6,1) = mean(var.Data(ss_6,1));

ss_7 =  find( Period_7(1,1) <=    var.Date &   var.Date  <=    Period_7(2,1) )     ;
varPeriod(7,1) = mean(var.Data(ss_7,1));

end