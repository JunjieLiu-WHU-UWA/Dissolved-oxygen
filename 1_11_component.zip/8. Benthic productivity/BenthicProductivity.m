% load('D:\Research in UWA\overview of data available in anvil\all_togehter_plotting\anvil.mat');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
% addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% % BasicRead
%--------------------------------------------------------
currentOutput = '8. Benthic productivity\'; 
fileOutput =  [dicmodel currentFolder '\Output\' currentOutput ];
if ~exist(fileOutput,'dir')      % check  whether the outdir  exists in the file of 'dir';
    mkdir(fileOutput);           % if not exists, create the file of 'outdir'
end

%----------------- Benthic biomass ------------------------------------------------
varid = netcdf.inqVarID(ncid,'WQ_DIAG_PHY_MPB'); % benthic biomass
PHY_MPB = netcdf.getVar(ncid,varid) /1000 *12; % mmol C /m2 to gC/m2 


 [ PHY_MPBSumSpace ,   PHY_MPBCVMean ]  =  bottomLayer( PHY_MPB, Basic,Cell_whole_channel);

figure
plot(ResTime, PHY_MPBCVMean)

set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mean benthic biomass across  the whole  wetland ']);
xlim([sTime  eTime]);
ylabel({'Benthic biomass'  '(g C /m2)'})      
xlabel('Date (2015)');
grid on 

 saveas(gcf,[fileOutput 'Mean benthic biomass across  the whole  wetland '],'png');
 saveas(gcf,[fileOutput  'Mean benthic biomass across  the whole  wetland'],'fig');
 
%------------------------Benthic productivity--------------------------------------

varid = netcdf.inqVarID(ncid,'WQ_DIAG_PHY_BPP'); %benthic gross primary production
PHY_BPP = netcdf.getVar(ncid,varid) * 32 /1000; % convert mmol/m2/day to g/m2/d.

 [ PHY_BPPSumSpace ,   PHY_BPPCVMean ]  =  bottomLayer( PHY_BPP , Basic,Cell_whole_channel);



figure
subplot(2,1,1)
plot(ResTime, PHY_BPPSumSpace./ 1000) % the unit is kg/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mass flux of  benthic GPP across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Benthic GPP'  '(kg O_{2} /d)'})      
xlabel('Date (2015)');
grid on 


subplot(2,1,2)
plot(ResTime, PHY_BPPCVMean)
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mean rate flux of  benthic GPP across  the whole  wetland ']);
xlim([sTime  eTime]);
ylabel({'Benthic GPP'  '(g O_{2} /m^{2}/d)'}) ;     
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;
ySize = 15;
% xLeft = (21-xSize)/2;
% yTop = (30-ySize)/2;
xLeft = 0;
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Benthic  GPP across  the whole wetland'],'png');
saveas(gcf,[fileOutput  'Benthic  GPP across  the whole wetland'],'fig');


   filecsv =  [ fileOutput 'BenthicGPP_wholeWetland.csv' ];
    
    fid = fopen(filecsv,'wt');

fprintf(fid,'ISOTime, PHY_BPPSumSpace (gO2/d), PHY_BPPCVMean(g O2/m2/d)  \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f\n',  PHY_BPPSumSpace(1,i), PHY_BPPCVMean(1,i));
end
fclose(fid);


%----------------net benthic producitivity ---------------------------------
        
varid = netcdf.inqVarID(ncid,'WQ_DIAG_PHY_BCP'); %benthic net production
PHY_BCP = netcdf.getVar(ncid,varid) * 32 /1000 ; % convert mmol/m2/day to g/m2/d.
 [ PHY_BCPSumSpace ,   PHY_BCPCVMean ]  =  bottomLayer( PHY_BCP , Basic,Cell_whole_channel);


figure
subplot(2,1,1)
plot(ResTime, PHY_BCPSumSpace./ 1000) % the unit is kg/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '   ' 'Mass flux of  benthic net productivity (BCP) across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Benthic net productivity'  '(kg O_{2} /d)'})      
xlabel('Date (2015)');
grid on 


subplot(2,1,2)
plot(ResTime, PHY_BCPCVMean)  %g/m2/d.
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mean rate flux of  benthic net productivity (BCP) across  the whole  wetland ']);
xlim([sTime  eTime]);
ylabel({'Benthic net productivity'  '(g O_{2} /m^{2}/d)'}) ;     
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20;
ySize = 15;
% xLeft = (21-xSize)/2;
% yTop = (30-ySize)/2;
xLeft = 0;
yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Benthic  net productivity BCP across  the whole wetland'],'png');
saveas(gcf,[fileOutput  'Benthic  net productivity BCP across  the whole wetland'],'fig');


   filecsv =  [ fileOutput 'Benthic net productivityBCP_wholeWetland.csv' ];
    
    fid = fopen(filecsv,'wt');

fprintf(fid,'ISOTime, PHY_BCPSumSpace (gO2/d), PHY_BCPCVMean(g O2/m2/d)  \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f\n',  PHY_BCPSumSpace(1,i), PHY_BCPCVMean(1,i));
end
fclose(fid);


%------------------------------------respiration--------------

PHY_B_RES =  PHY_BPP  -  PHY_BCP;
[ PHY_B_RESSumSpace ,   PHY_B_RESCVMean ]  =  bottomLayer( PHY_B_RES , Basic,Cell_whole_channel);


figure
subplot(2,1,1)
plot(ResTime, PHY_B_RESSumSpace./ 1000) % the unit is kg/d
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '   ' 'Mass flux of  benthic respiration across  the whole wetland ']);
xlim([sTime  eTime]);
ylabel({'Benthic respriation'  '(g O_{2} /d)'})      
xlabel('Date (2015)');
grid on 


subplot(2,1,2)
plot(ResTime, PHY_B_RESCVMean)
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Mean rate flux of  benthic respiration across  the whole  wetland ']);
xlim([sTime  eTime]);
ylabel({'Benthic respiration'  '(g O_{2} /m^{2}/d)'}) ;     
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 15;
xLeft = 0; yTop = 0;

set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[fileOutput  'Benthic  respiration across  the whole wetland'],'png');
saveas(gcf,[fileOutput  'Benthic  respiration across  the whole wetland'],'fig');


   filecsv =  [ fileOutput 'Benthic  respiration_wholeWetland.csv' ];
    
    fid = fopen(filecsv,'wt');

fprintf(fid,'ISOTime, PHY_B_RESSumSpace (gO2/d), PHY_B_RESCVMean(g O2/m2/d)  \n');
for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f,%4.4f\n',  PHY_B_RESSumSpace(1,i), PHY_B_RESCVMean(1,i));
end
fclose(fid);
