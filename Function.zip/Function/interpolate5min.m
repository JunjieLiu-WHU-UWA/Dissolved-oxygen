function  varFinal  =  interpolate5min(  var);

sTime  = datenum('2015/04/01 00:00:00');
eTime  = datenum('2015/05/31 23:55:00');

varFinal.Date = (sTime : 1/24 /60 * 5  : eTime)';
varFinal.Data = interp1(var.Date, var.Data   ,varFinal.Date,'linear','extrap'); 

end