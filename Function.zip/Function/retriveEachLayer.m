function  [ lay1, lay2, lay3, lay4 , depthAve ]  =    retriveEachLayer(oxy)

[row , col] = size(oxy);

rowLay1 = 1: 4: 8049;
rowLay2 = 2: 4: 8050;
rowLay3 = 3: 4: 8051;
rowLay4 = 4: 4: 8052;

 rowOnelayer = row/ 4;
 
lay1 = zeros(  rowOnelayer , col);
lay2 = zeros(  rowOnelayer , col);
lay3 = zeros(  rowOnelayer , col);
lay4 = zeros(  rowOnelayer , col);
depthAve = zeros( rowOnelayer , col );
for ii = 1: col
    
  flag = oxy(:, ii);
  lay1(:, ii) = flag(rowLay1 );
  lay2(:, ii) = flag(rowLay2 );
  lay3(:, ii) = flag(rowLay3 );
  lay4(:, ii) = flag(rowLay4 );
all_cell = reshape(  flag,4 , rowOnelayer );
depthAve(:, ii) = mean(all_cell)';
end

end