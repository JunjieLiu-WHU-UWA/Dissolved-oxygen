function   [ Base , Quick ]  =     BaseflowQuick(Flow )

Base.Date = Flow.Date;
Base.Data = zeros(length(Flow.Data), 1);

Quick.Date = Flow.Date;
Quick.Data = zeros(length(Flow.Data), 1);


for ii = 2 : length( Flow.Date)
  if isnan(Flow.Data(ii-1))
    Quick.Data(ii) = 0.925 * Quick.Data(ii -1) + ( Flow.Data(ii) -  Flow.Data(ii-1)) * (1 + 0.925 ) / 2;
  end
end 
% ss = find(Quick.Data <0);
% Quick.Data(ss) = 0;
Base.Data =  Flow.Data  -  Quick.Data;

end