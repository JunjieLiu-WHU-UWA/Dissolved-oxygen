   
function      writeDaily(var, filecsv, varTitle)

     fid = fopen(filecsv,'wt');

fprintf(fid,['ISOTime, ' varTitle ' \n']);
for i = 1:length(var.Date) 
    fprintf(fid,'%s,', datestr(var.Date(i),'yyyy/mm/dd'));
    fprintf(fid,'%4.4f \n',var.Data(i));
end
fclose(fid);

end