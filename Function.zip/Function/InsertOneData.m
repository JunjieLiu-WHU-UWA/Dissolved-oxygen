function      VarNew = InsertOneData( Var , date_val, data_val  )
   ss_less = find(  Var.Date < date_val );
   ss_large = find( Var.Date > date_val );
   len_up = length(ss_less);
   len_down = length(ss_large);
   VarNew.Date = zeros( len_up + len_down +1, 1);
   VarNew.Data = zeros( len_up + len_down +1, 1);
   up = 1;
   down = len_up;
   VarNew.Date(up:down, 1) = Var.Date(ss_less);
   VarNew.Data(up: down, 1) = Var.Data(ss_less);
   
   up = down + 1;
   down = down + 1;
   VarNew.Date(up:down, 1) = date_val;
   VarNew.Data(up: down, 1) = data_val;

  up = down + 1;
  down = down +   len_down;
 VarNew.Date(up:down, 1) = Var.Date(ss_large);
 VarNew.Data(up: down, 1) = Var.Data(ss_large);



end