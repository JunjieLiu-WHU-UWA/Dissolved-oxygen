function   ModelWriteVariable(ResTime, Var, filecsv, VarTitle )

fid = fopen(filecsv,'wt');
fprintf(fid,['ISOTime,'   VarTitle '\n']);
    for i = 1:length(ResTime)
    fprintf(fid,'%s,',datestr(ResTime(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',  Var(i)  );
	

    end
fclose(fid);
end