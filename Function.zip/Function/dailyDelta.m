
function varDay = dailyDelta(Var)

% this function aims to calculate the daily maximum, minimum,
%and the difference between maximum and minimum 



[yy, mm, dd, HH, MM, SS] = datevec(Var.Date);
year = unique(yy);
month = unique(mm);
day = unique(dd);

flag = 0;
for yi = 1:length(year)
    for mi =1: length(month)
        for di =1: length(day)
   
           ss = find(  yy == year(yi) & mm== month(mi) & dd == day(di)  ); 
     
			if ~isempty(ss)
			 flag = flag +1; 
                     
			varDay.Date(flag,1) = datenum(year(yi), month(mi), day(di),0, 0,0);
            varDay.varMax(flag,1) = max(Var.Data(ss)); 
           varDay.varMin(flag,1) = min(Var.Data(ss));  
           varDay.varDelta(flag,1) = max(Var.Data(ss))   - min(Var.Data(ss));
           varDay.varMean(flag,1) = mean(Var.Data(ss)); 

			end
		end
		end
end
end