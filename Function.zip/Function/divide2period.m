function [ nonStorm,  Storm ]    = divide2period( var)

period = { '01/04/2015', '06/04/2015' , ...
                 '07/04/2015',   '14/04/2015', ...
                   '15/04/2015',   '30/04/2015', ...
                   '01/05/2015',  '5/05/2015', ...
                   '6/05/2015',    '15/05/2015', ...
                   '16/05/2015',    '21/05/2015', ...
                   '22/05/2015', '31/05/2015' };
               % 6 , 16, 
               periodnon = [6, 16, 10, 10];
               periodstorm = [ 8 , 5, 6 ];
               NonSLen = cumsum(periodnon); % the cumulative length of each period
               SLen = cumsum(periodstorm); % the cumulative period
     nonStormDate = zeros(42, 1);          
     nonStormData = zeros(42, 1);
     StormDate = zeros(19,1);
     StormData = zeros(19,1);
     ss = find( datenum(period{1},'dd/mm/yyyy') <= var.Date & var.Date <= datenum(period{2},'dd/mm/yyyy')  ) ;
     nonStormDate(1: NonSLen(1),1) = var.Date(ss);
     nonStormData(1: NonSLen(1),1) = var.Data(ss);
     
     ss = find( datenum(period{3},'dd/mm/yyyy') <= var.Date & var.Date <= datenum(period{4},'dd/mm/yyyy')  ) ;
     StormDate(1: SLen(1),1) = var.Date(ss);
     StormData(1: SLen(1),1) = var.Data(ss);
     
     ss = find( datenum(period{5},'dd/mm/yyyy') <= var.Date & var.Date <= datenum(period{6},'dd/mm/yyyy')  ) ;
     nonStormDate(NonSLen(1) + 1: NonSLen(2),1) = var.Date(ss);
     nonStormData(NonSLen(1) + 1: NonSLen(2),1) = var.Data(ss);
     
     ss = find( datenum(period{7},'dd/mm/yyyy') <= var.Date & var.Date <= datenum(period{8},'dd/mm/yyyy')   ) ;
     StormDate(SLen(1)+ 1: SLen(2),1) = var.Date(ss);
     StormData(SLen(1) + 1: SLen(2),1) = var.Data(ss);
     
     ss = find( datenum(period{9},'dd/mm/yyyy') <= var.Date & var.Date <= datenum(period{10},'dd/mm/yyyy')  ) ;
     nonStormDate(NonSLen(2) + 1: NonSLen(3),1) = var.Date(ss);
     nonStormData(NonSLen(2) + 1: NonSLen(3),1) = var.Data(ss);

     ss = find( datenum(period{11},'dd/mm/yyyy') <= var.Date & var.Date <= datenum(period{12},'dd/mm/yyyy')  ) ;
     StormDate(SLen(2)+ 1: SLen(3),1) = var.Date(ss);
     StormData(SLen(2) + 1: SLen(3),1) = var.Data(ss);
     
     ss = find( datenum(period{13},'dd/mm/yyyy') <= var.Date & var.Date <= datenum(period{14},'dd/mm/yyyy')   ) ;
     nonStormDate(NonSLen(3) + 1: NonSLen(4),1) = var.Date(ss);
     nonStormData(NonSLen(3) + 1: NonSLen(4),1) = var.Data(ss);
     
     nonStorm.Date = nonStormDate;
     nonStorm.Data = nonStormData;
     
     Storm.Date =StormDate;
     Storm.Data =StormData;
     
          
end