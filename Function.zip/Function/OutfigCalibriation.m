function     OutfigCalibriation( Variable, location , output,  ob_Inlet_DOC_04, ob_Inlet_DOC_05,OGM_DOC_inlet  )
global timeTick timeLable currentFolder  sTime eTime ResTime
% sTime  = datenum('2015/04/01 00:00:00');
% eTime  = datenum('2015/05/31 23:55:00');
% timeTick = {'2015/04/01 00:00:00'...
%                   '2015/04/10 00:00:00'...
%                   '2015/04/20 00:00:00'...
%                   '2015/05/01 00:00:00'...
%                   '2015/05/10 00:00:00'...
%                   '2015/05/20 00:00:00'...
%                   '2015/05/31 00:00:00'}';
%  timeLable = {' Apr 01' ' Apr 10'  ' Apr 20'   ' May 01' ' May 10'   ' May 20'  ' May 31'   }';  

figure
plot(ob_Inlet_DOC_04.Date, ob_Inlet_DOC_04.Data,'*');
hold on 
plot(ob_Inlet_DOC_05.Date, ob_Inlet_DOC_05.Data,'o');
hold on 

plot(ResTime , OGM_DOC_inlet );
hold on 
leg1 = legend('Oberved during storm 04','Oberved during storm 05', ...
    '1 st layer', ' 2 nd layer', ' 3 st layer',' 4 st layer' );
set(leg1,'Location','best');
set(gca,'XTick', [ datenum(timeTick )], 'XTickLabel',timeLable  );
title([  currentFolder   '    ' 'Concentration of ' Variable '  at ' location ]);
xlim([sTime  eTime]);
ylabel({ Variable ' (mg/L)'})      
xlabel('Date (2015)');
grid on 

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
xSize = 20; ySize = 5;
xLeft = 0; yTop = 0;
set(gcf,'paperposition',[xLeft yTop xSize ySize])

saveas(gcf,[output  'Calibration of  ' Variable 'at' location],'png') ;
saveas(gcf,[output 'Calibration of '  Variable 'at' location ],'fig');
end