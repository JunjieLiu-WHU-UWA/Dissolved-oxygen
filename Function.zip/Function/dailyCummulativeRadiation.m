function  VarDay  = dailyCummulativeRadiation(Var)
% datestr(SolRad.Date(end),'yyyy/mm/dd HH:MM:SS')
% ss = find (isnan(SolRad.Data));
% datestr(SolRad.Date(ss,1),'yyyy/mm/dd HH:MM:SS')
% Var = SolRad;
[yy, mm, dd, ~, ~, ~] = datevec(Var.Date);
year = unique(yy);
month = unique(mm);
day = unique(dd);

flag = 0;
for yi = 1:length(year)
    for mi =1: length(month)
        for di =1: length(day)
   
           ss = find(  yy == year(yi) & mm== month(mi) & dd == day(di)  ); 
     
			if ~isempty(ss)
			 flag = flag +1; 
			VarDay.Date(flag,1) = datenum(year(yi) ,  month(mi) , day(di));
            VarDay.Data(flag,1) = sum(Var.Data(ss,1) ) * 3600 / 1000 ;  % the unit will be kJ
			end
		end
		end

end
