function  flow_target    =  findFlowDateNutrients( NutrientDate, Flow )
%    NutrientDate = finalVar.Date;
%    Flow =   gene_ob_flow ;
len = length(NutrientDate );
flow_target.Data = zeros(len, 1);
for ii   = 1 : len
%  ii = 7;
    ss = find(floor(NutrientDate(ii)) == Flow.Date );
    if ss
    flow_target.Date(ii, 1) = floor(NutrientDate(ii));
flow_target.Data(ii, 1) = Flow.Data(ss);
    end
end
% Flow.Date(ss)
end