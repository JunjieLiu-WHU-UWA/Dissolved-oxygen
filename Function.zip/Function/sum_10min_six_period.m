function [ nonStorm,  Storm, sumVarperiod ]    = sum_10min_six_period( var,  period_10min )
% var = transInOxy;
% the uint of var.Data is g/d
% the unit of nonStorm,  Storm sumVarperiod is g
sumVarperiod = zeros(7,1);

 for ii = 1: 7
   left_index  = ii *2 -1; 
   right_index = ii * 2;
     ss = find( datenum(period_10min{left_index, 1},'dd/mm/yyyy HH:MM:SS') <= var.Date & ...
    var.Date <= datenum(period_10min{right_index,1},'dd/mm/yyyy HH:MM:SS')  ) ;
     sumVarperiod(ii,1) = trapz(var.Date(ss)  , var.Data(ss)   );
 end 
       
 nonStorm = sumVarperiod(1,1)  + sumVarperiod(3,1) + sumVarperiod(5,1) + sumVarperiod(7,1) ;
  Storm = sumVarperiod(2,1)  + sumVarperiod(4,1) + sumVarperiod(6,1) ;
 
end