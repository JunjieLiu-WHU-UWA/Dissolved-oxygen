function     kvData   =   CalcuKvData(inletData, outletData,  SampleResNeibourData)
% this function is designed to calculate kv, the unit of kv is /d
% the unit of sampleResNeibour is d

if  length(inletData) == length(outletData)

kvData =  (-1) * log(outletData ./inletData   )  ./ SampleResNeibourData;
else
    error('Inlet do not correspond to outlet');
end
    

end