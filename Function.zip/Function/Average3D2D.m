function    [OxyAveLayer, OxyAveSheet ]  = Average3D2D(Oxy,Basic, Cell_whole_channel )

% this function is to  calculate the average DO concentration over depth
% and sheet. the unit remain unchanged. 
%
lay_number  = length(Basic.diffSigmaZ );
cell_number = length(Basic.cell_area); 
time_number = length(Basic.ResTime);

cellCV = Cell_whole_channel{1,5};  % the control volume across the wetland , the number of cell.
cellCV_time = repmat(cellCV, 1, time_number);  
ResTime = Basic.ResTime;
idx2 = Basic.idx2; 
wetDry = Basic.stat;   % -1 is wet, 0 is dry
Oxy_shape = reshape(Oxy,  lay_number, cell_number, time_number);

wet_CV = cellCV_time & wetDry; 

% first setp is to set the dry cell and cell outside control volume as 'nan' 
for ii = 1:  lay_number
    
         
         Oxy_wetCV = Oxy_shape(ii, :, :);
         ss = find(wet_CV == 0); % 0 represent dry, -1 repreent wet
          Oxy_flag = reshape(Oxy_wetCV, cell_number, time_number); 
          Oxy_flag(ss) = nan;
          Oxy_shape(ii, :, :) = reshape(Oxy_flag  , cell_number, time_number);
         
 end
    
    Oxy_nan = reshape(Oxy_shape,  lay_number * cell_number, time_number  );
    Oxy_layer = reshape(Oxy_nan,  lay_number,   cell_number *  time_number  );
    % average over depth
    Oxy_ave_layer = nanmean(Oxy_layer);  
    %
    OxyAveLayer.Date = ResTime;
    OxyAveLayer.Data = Oxy_ave_layer;
    
    
    
     Oxy_ave_depth = reshape(Oxy_ave_layer , cell_number ,   time_number );
     % average over sheet
     Oxy_ave_sheet =  nanmean( Oxy_ave_depth);
     OxyAveSheet.Date = ResTime;
     OxyAveSheet.Data = Oxy_ave_sheet;
%     max( max(Oxy_ave_depth_2 - Oxy_ave_depth  ));
%     max( max(Oxy_ave_sheet_2 - Oxy_ave_sheet  ));
%     Oxy_ave_depth = zeros( cell_number, time_number);
%     figure
%     plot(ResTime ,Oxy_ave_sheet , '*' ) ;
%     hold on
%     plot(ResTime ,Oxy_ave_sheet_2 , 'o')
%     Oxy_ave_depth_nan = reshape( Oxy_nan, lay_number,  cell_number, time_number );
    
    % the following is another way to calcuatlet average concentration
    % over depth and sheet. 
%     
%     for ii = 1 : cell_number
%         for jj = 1 : time_number
%             flag_nan = Oxy_ave_depth_nan(:, ii, jj);
%             Oxy_ave_depth(ii, jj) = nanmean(flag_nan);
%         end
%     end
%     
%     Oxy_ave_sheet = nanmean( Oxy_ave_depth);
       
    
end
