function  numSum   = sumAcrossTime10min(var)
% this function is designed to sum all the value with time
len = length(var.Date);
numSum = 0;
for ii = 2 : len
    % convert one day to number of seconds
    timeInterval =  (var.Date(ii) - var.Date(ii-1)) * 3600 *24;
flux = mean(var.Data(ii-1:ii));
numSum = numSum +  timeInterval * flux;
end

end