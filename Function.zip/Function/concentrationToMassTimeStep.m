function mass_timeStep  = concentrationToMassTimeStep( con   , Basic, Cell_whole_channel, timeStep)


wetDry = Basic.stat(:, timeStep) * (-1);   % originally -1 represent wet,and 0 represent dry, 
                                             % now 1 represent wet, 0 represent dry..
cell_Zb =  Basic.cell_Zb;
H = Basic.H;
Stage =   H - repmat(cell_Zb, [1, size(H,2)]);  % water evelation is more proper . zero point is bottom
area = Basic.cell_area;


diffSigmaZ = Basic.diffSigmaZ;
volume = area .* Stage(:, timeStep)';

numLayer =  length(diffSigmaZ );
numCell = length(area  );
  volume_layer = reshape (diffSigmaZ    * volume, numLayer * numCell ,  1);
  volume_mass  = reshape (con  .* volume_layer, numLayer, numCell); 
  area_mass = sum(volume_mass)';
  ss_CV = Cell_whole_channel{1,5};
ss_CV_statu = ss_CV & wetDry ;
mass_timeStep = sum(area_mass(ss_CV_statu));
  end