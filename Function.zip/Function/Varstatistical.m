function  varOut =  Varstatistical(var)
% this function is calculate the maximum, minimum , average
% deviation of data
varOut = zeros(4,1);
varOut(1,1) = mean(var) ; % average
varOut(2,1) = std(var); % Standard deviation
varOut(3,1) = max(var);  % maximum 
varOut(4,1) = min(var);  % minimum

end