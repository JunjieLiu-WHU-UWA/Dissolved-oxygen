function R2_p  = R2_p_regression( y, x1, x2 ) 

   switch nargin
        case 3
             X = [ones(size(x1))  x1 x2  ];
        case 2
           X = [ones(size(x1))  x1   ];
        otherwise
           R2_p(1, 1:2)  = nan;
   end

          [~,  ~, ~, ~,  stats] = regress(y,X)  ;
          R2_p(1, 1) =  stats(1, 1);
          R2_p(1, 2) =  stats(1, 3); 
   
end