function    varHour =  Second2hour(var);



[yy, mm, dd, HH, MM, ~] = datevec(var.Date);
year = unique(yy);
month = unique(mm);
day = unique(dd);
hour = unique(HH);
minute = unique(MM);
flag = 0;
for yi = 1:length(year)
    for mi =1: length(month)
        for di =1: length(day)
            for Hi = 1:length(hour)
               
                		    ss = find(  yy == year(yi) & mm== month(mi) & dd == day(di) & HH == hour(Hi) );
                      if ~isempty(ss)
			           flag = flag +1; 
			           varHour.Date(flag,1) = datenum(year(yi) , month(mi),  day(di),   hour(Hi), 0, 0 )  ;
                       varHour.Data(flag,1) = mean(var.Data(ss,1));
                     end
          
            end
		end
		end
end

end