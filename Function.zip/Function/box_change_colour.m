function box_change_colour(ax2)
h = findobj(ax2,'tag','Box');
for j=1:length(h)
    set(h(j), 'Color', [0.85 0.33 0.1 ]);
%    line(get(h(j),'Tag','Median','Color',[0 0 0]);
end

  h = findobj(ax2,'tag','Median');
for j=1:length(h)
  set(h(j), 'Color',  [0.85 0.33 0.1 ]);
%    line(get(h(j),'Tag','Median','Color',[0 0 0]);
end


h = findobj(gcf,'tag','Outliers');
for iH = 1:length(h)
    h(iH).MarkerEdgeColor =  [0.85 0.33 0.1 ];
end



h = findobj(gcf,'tag','Upper Whisker');
for iH = 1:length(h)
    h(iH).Color =  [0.85 0.33 0.1 ];
end

h = findobj(gcf,'tag','Lower Whisker');
for iH = 1:length(h)
    h(iH).Color =  [0.85 0.33 0.1 ];
end
h = findobj(gcf,'tag','Upper Adjacent Value');
for iH = 1:length(h)
    h(iH).Color =  [0.85 0.33 0.1 ];
end

h = findobj(gcf,'tag','Lower Adjacent Value');
for iH = 1:length(h)
    h(iH).Color = [0.85 0.33 0.1 ];
end

end
