function     [nonStorm, Storm] =  seperate10minperiod(var, period_10min     )


     %%% 1 non storm
     ss = find( datenum(period_10min{1},'dd/mm/yyyy HH:MM:SS') <= var.Date & var.Date <= datenum(period_10min{2},'dd/mm/yyyy HH:MM:SS')  ) ;
    nonStorm_up = 1;
    nonStorm_down = length(ss);
     
     nonStorm.Date(nonStorm_up  : nonStorm_down,  1) = var.Date(ss);
     nonStorm.Data(nonStorm_up :  nonStorm_down, 1) = var.Data(ss);
     % 2 storm
     ss = find( datenum(period_10min{3},'dd/mm/yyyy HH:MM:SS') <= var.Date & var.Date <= datenum(period_10min{4},'dd/mm/yyyy HH:MM:SS')  ) ;
     storm_up = 1;
     storm_down =  length(ss);
     
     Storm.Date(storm_up : storm_down,1) = var.Date(ss);
     Storm.Data(storm_up : storm_down,1) = var.Data(ss);
     % 3 non storm
    ss = find( datenum(period_10min{5},'dd/mm/yyyy HH:MM:SS') <= var.Date & var.Date <= datenum(period_10min{6},'dd/mm/yyyy HH:MM:SS')  ) ;
    nonStorm_up =      nonStorm_down +  1;
    nonStorm_down =   nonStorm_down +  length(ss);
     nonStorm.Date( nonStorm_up: nonStorm_down,  1) = var.Date(ss);
     nonStorm.Data(nonStorm_up: nonStorm_down,1) = var.Data(ss);
     % 4 storm
     ss = find( datenum(period_10min{7},'dd/mm/yyyy HH:MM:SS') <= var.Date & var.Date <= datenum(period_10min{8},'dd/mm/yyyy HH:MM:SS')   ) ;
     storm_up =  storm_down  + 1;
     storm_down =  storm_down +  length(ss);
     
     Storm.Date(     storm_up:   storm_down ,1) = var.Date(ss);
     Storm.Data(storm_up:   storm_down ,1) = var.Data(ss);
     %5 non storm
     ss = find( datenum(period_10min{9},'dd/mm/yyyy HH:MM:SS') <= var.Date & var.Date <= datenum(period_10min{10},'dd/mm/yyyy HH:MM:SS')  ) ;
    nonStorm_up =      nonStorm_down +  1;
    nonStorm_down =   nonStorm_down +  length(ss);
     
     nonStorm.Date(nonStorm_up: nonStorm_down,1) = var.Date(ss);
     nonStorm.Data( nonStorm_up : nonStorm_down,1) = var.Data(ss);
    %6 storm
     ss = find( datenum(period_10min{11},'dd/mm/yyyy HH:MM:SS') <= var.Date & var.Date <= datenum(period_10min{12},'dd/mm/yyyy HH:MM:SS')  ) ;
     storm_up =  storm_down  + 1;
     storm_down =  storm_down +  length(ss);
     
     Storm.Date(storm_up: storm_down ,1) = var.Date(ss);
     Storm.Data(storm_up: storm_down ,1) = var.Data(ss);
     %7 non storm
     ss = find( datenum(period_10min{13},'dd/mm/yyyy HH:MM:SS') <= var.Date & var.Date <= datenum(period_10min{14},'dd/mm/yyyy HH:MM:SS')   ) ;
    nonStorm_up =      nonStorm_down +  1;
    nonStorm_down =   nonStorm_down +  length(ss);
     nonStorm.Date( nonStorm_up: nonStorm_down ,1) = var.Date(ss);
     nonStorm.Data(nonStorm_up: nonStorm_down ,1) = var.Data(ss);   
end