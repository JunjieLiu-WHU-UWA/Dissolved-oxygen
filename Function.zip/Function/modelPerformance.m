

function     [mae, rmse, ns]    = modelPerformance( obs, sim)
% obs = obMidTemp0405.Data;
% 
%  sim = midTemp(1:lengOb)';
% this function aims to calculate
% mean absolute error (MAE)
% root mean square error (RMSE)
% Nash-sutcliffe model efficiencey coefficient NS
%Chen, G., & Fang, X. (2015). Accuracy of hourly water temperatures in rivers 
%calculated from air temperatures. Water, 7(3), 1068-1087.
nobs = size(obs,1);
nsim = size(sim,1);
if nobs  ~= nsim 
    error('the length of two array is not equal');
end
mae = sum(abs(obs- sim)) / nobs;
rmse = sqrt( sum( (obs- sim).^2) / nobs);
ns = 1  -         sum( (obs- sim).^2  )            /     sum(       (mean(obs) - obs).^2  );
end


