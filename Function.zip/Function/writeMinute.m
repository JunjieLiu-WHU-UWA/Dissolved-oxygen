function      writeMinute(var, filecsv, varTitle)

     fid = fopen(filecsv,'wt');

fprintf(fid,['ISOTime, ' varTitle ' \n']);
for i = 1:length(var.Date) 
    fprintf(fid,'%s,', datestr(var.Date(i),'dd/mm/yyyy HH:MM:SS'));
    fprintf(fid,'%4.4f \n',var.Data(i));
end
fclose(fid);

end