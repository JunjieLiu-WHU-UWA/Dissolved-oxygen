
function     [ mass_rate ,  rate_rate ]  =  bottomLayer( Var, Basic,Cell_whole_channel)
% unit of mass_rate is mmol/d or g/d
% unit of rate_rate is mmol/m2/d or g/m2/d.
% it is decided by the unit of Var

% this function is sum the variable at the bottom
% for each time stamp, 
% reshape to matric of  layernumber * cellNumber 
% use the logical operation to chose the wet cel within  control volume
% sum all the area and mass of wet cell within control volume

% calculate rate of per meter square
% Var = SedOxy;
layerNum = length(Basic.diffSigmaZ);
timeNum = length(Basic.ResTime);
cellNum = length(Basic.cell_X);
wetDry = Basic.stat ; % -1 is wet, 0 is dry
cell_area = Basic.cell_area;
CV = Cell_whole_channel{1,5}; % the target control volume % 1 represent inside control volume, 0 represent outside control voloume
mass_rate = zeros(1  ,timeNum ); % the unit is mmol/d
rate_rate = zeros(1  ,timeNum );% the unit is mmol/m2/d



for ii = 1: timeNum
flag =  reshape(Var(:, ii), layerNum,cellNum  );
wet = wetDry(:, ii);

wet_CV = wet & CV ; % the final results is 0 , as long as there is 0 in one of them. 
area_wet_CV = sum(cell_area(wet_CV));
 
mass = flag(end, :).* cell_area;
 mass_wet_CV = sum(mass( wet_CV ));
 mass_rate(1, ii) = mass_wet_CV;
 rate_rate(1,ii) = mass_wet_CV./ area_wet_CV;
    
end 

end