function  [ fitXY   ,b    , R2_p]  = Equation_regression( y, x1) 


           X = [ones(size(x1))  x1   ];
          [b,  ~, ~, ~,  stats] = regress(y,X)  ;
          R2_p(1, 1) =  stats(1, 1);
          R2_p(1, 2) =  stats(1, 3); 
          fitXY.x = linspace(min(x1), max(x1), 100);
          fitXY.y = b(1) + b(2)*fitXY.x;
          
end