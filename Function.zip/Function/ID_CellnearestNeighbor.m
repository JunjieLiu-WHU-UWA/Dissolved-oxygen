

function           cell_ID    =   ID_CellnearestNeighbor(geofile, pnt)

% this function is designed to find the cell number accoriding to the x, y
% coordinates.
% filename is the name of nc file address.
% pnt is x and y coordinates.  1 *2 
% example 
% pnt(1, 1) = 399614.22;
% pnt(1, 2) = 6460374.324;



geoncid = netcdf.open(geofile,'NC_NOWRITE');
for ii = 1: 30
    [varname{ii}, xtype(ii), vardimids{ii} ] = netcdf.inqVar(geoncid, ii-1);
    rawGeo.(varname{ii})  = netcdf.getVar(geoncid,ii-1 );
end

geo_x = rawGeo.cell_ctrd(1,:)';
geo_y = rawGeo.cell_ctrd(2,:)';

dtri = delaunayTriangulation( geo_x   , geo_y );
cell_ID = nearestNeighbor(dtri,pnt);




end