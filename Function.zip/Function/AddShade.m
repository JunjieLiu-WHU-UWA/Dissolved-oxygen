function   AddShade(y4, y5, period  )
%y4 is the bottom boundary
%y5 is upper boundary
x2=([datenum(period(3), 'dd/mm/yyyy'), (datenum(period(4), 'dd/mm/yyyy') +1) ]);
% y4=[0,0];

patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
    'EdgeColor','none');
alpha(0.5)
hold on 

x2=([datenum(period(7), 'dd/mm/yyyy'), (datenum(period(8), 'dd/mm/yyyy')+1) ]);
% y4=[0,0];
% y5=[10,10];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
        'EdgeColor','none');
alpha(0.5)
hold on 

x2=([datenum(period(11), 'dd/mm/yyyy'),(datenum(period(12), 'dd/mm/yyyy')+1)]);
% y4=[0,0];
% y5=[10,10];
patch('YData',[y4 fliplr(y5)],'XData',[x2 fliplr(x2)],...
    'FaceColor',[0.5 0.5 0.5], ...
        'EdgeColor','none');
alpha(0.5)
hold on 
end
