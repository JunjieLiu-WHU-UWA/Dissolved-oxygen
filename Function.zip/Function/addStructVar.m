function  finalVar =   addStructVar(orignalVar   ,addVar   )

for ii = 1 : length(addVar.Date )

    orignalVar = InsertOneData( orignalVar , addVar.Date(ii,1), addVar.Data(ii,1)  );
    
end 

finalVar = orignalVar;
end