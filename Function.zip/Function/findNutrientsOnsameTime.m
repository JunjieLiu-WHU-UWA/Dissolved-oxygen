function  model_target    =  findNutrientsOnsameTime( NutrientDate, Model)

% this function is designed to find the corresponding modelled data accrong to sampling time.

% the resolustion is 10 minutes

len = length(NutrientDate );
model_target.Date = zeros(len, 1);
model_target.Data = zeros(len, 1);
for ii   = 1 : len
%  ii = 7;
    ss = find( abs(Model.Date - NutrientDate(ii) ) < datenum(0, 0, 0, 0, 6, 0) );
    
    
%     (NutrientDate(ii) + datenum(0, 0, 0, 0, 5, 0) ) <=  Model.Date & Model.Date < (NutrientDate(ii) - datenum(0, 0, 0, 0, 5, 0) ));
    if ss
    model_target.Date(ii, 1) = NutrientDate(ii);
    model_target.Data(ii, 1) = Model.Data(ss(1));
    end
end

end