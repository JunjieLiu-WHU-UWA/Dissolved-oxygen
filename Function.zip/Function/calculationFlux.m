function   flux_var  = calculationFlux(date, flow, var)


% the unit of date is day
% the unit of flow is m3/s
% the unit of var is mmol/m3
 % the unit of flux_var is  mmol/s
lenS = length(date);
flux_var.Date = date;
flux_var.Data = zeros(lenS,1);
for ii = 2 : lenS
    varFlag = mean(var(ii-1: ii,1));
    volFlag = mean(  flow(ii-1: ii,1) ) ;
    mass = varFlag * volFlag ;  %
    flux_var.Data(ii) = mass;
      
end


end