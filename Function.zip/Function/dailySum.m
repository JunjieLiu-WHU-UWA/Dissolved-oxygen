function    varDaily =  dailySum(var);



[yy, mm, dd, HH, MM, ~] = datevec(var.Date);
year = unique(yy);
month = unique(mm);
day = unique(dd);
hour = unique(HH);
minute = unique(MM);
flag = 0;
for yi = 1:length(year)
    for mi =1: length(month)
        for di =1: length(day)
        
                		    ss = find(  yy == year(yi) & mm== month(mi) & dd == day(di)  );
                      if ~isempty(ss)
			           flag = flag +1; 
			           varDaily.Date(flag,1) = datenum(year(yi), month(mi),  day(di) );
                       varDaily.Data(flag,1) = trapz(var.Date(ss,1) , var.Data(ss,1) ) ;
                     end
       
           
		end
		end
end
end