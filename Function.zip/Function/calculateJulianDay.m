function  JulianDay =  calculateJulianDay(NutrientDate)
%   NutrientDate  =finalVarPeriod.Date;
len_day = length(NutrientDate);
JulianDay.Date = NutrientDate;
JulianDay.JD   = zeros(len_day, 1);
JulianDay.sin_JD   = zeros(len_day, 1);
JulianDay.cos_JD   = zeros(len_day, 1);
for ii = 1: len_day
[yy, mm, dd, ~, ~, ~] = datevec(NutrientDate(ii));
JulianDay.JD(ii,1) =  floor( NutrientDate(ii)) - datenum(yy, 1,1) +1;
JulianDay.sin_JD(ii, 1) = sin(JulianDay.JD(ii));
JulianDay.cos_JD(ii, 1) = cos(JulianDay.JD(ii));
   
end



end