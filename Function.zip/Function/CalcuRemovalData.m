function     REData   =   CalcuRemovalData(inletData, outletData  )
% this function is designed to calculate kv, the unit of kv is /d
% the unit of sampleResNeibour is d
if  length(inletData) == length(outletData)
REData = ( inletData - outletData)   ./inletData; 
else
    error('Inlet do not correspond to outlet');
end

end