function  [outEquation, eq ,  gof , output    ] = FitEquation(  xxx ,yyy, var )
 % gof is good of fit
[eq, gof, output ] = fit(xxx,yyy,var); %poly1 is Linear polynomial curve

outEquation.x = (min(xxx) : (max(xxx) - min(xxx)) /100:max(xxx))';

outEquation.y = eq(outEquation.x);

end
