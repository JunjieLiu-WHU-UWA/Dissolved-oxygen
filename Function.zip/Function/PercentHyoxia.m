function     [ percentDO   ] =   PercentHyoxia( DOonelayer, DOthres, Basic, status, Cell_whole_channel)

status = - status; % change the logical number of wet and dry
% wet represent 1, 0 represent dry.
% all the wet area
in = Cell_whole_channel{1,5}; % the logical number within control volume
wet_cv = status & in ; % logcial operation
area_cv_wet = sum(Basic.cell_area(wet_cv)); % the total wet area 
ss_DO = zeros( length(DOonelayer) , 1);
ss_DO_th = find(DOonelayer < DOthres);   
%  the logical number of DO less than threshold
ss_DO(ss_DO_th) = 1;
 wet_cv_DO = status & in & ss_DO;     % logical operation
 area_cv_wet_DO = sum(Basic.cell_area(wet_cv_DO)); % the total area of DO concentration less than threshold
 percentDO =  area_cv_wet_DO /  area_cv_wet * 100; % the percent of area.
end
 