function   varNight = StartEndtimePercent( Var, thres )
% this function is to calculate the start time and end time of target

% percent of thres
% for calculatin of duration,  we need to find the time with obvious
% differecen. Usually, the concentration of DO large than 2mg/L occurs at noon 12:00 during day
% time.Thus several definitions are made. One night is from 12:00 during
% daytime to next 12:00 during day time.% ]

  


% Var = Hypoxia;
% thres = 50;
  DateSeries = unique(floor(Var.Date));


varNight.Date =DateSeries;
varNight.startTime = [];
varNight.endTime =[];
varNight.durt = [];
flag = 0;
for di = 1: length(DateSeries )
    
       flag = flag +1; 
	
                      
              if      di  == length(DateSeries )
                  % find the minimumal point for last day
                   ss_day = find(Var.Date ==DateSeries (di) );
                   [minDataDay, locationDay] = min(Var.Date(ss_day));
                   if minDataDay > thres
                       varNight.startTime(flag,1) = DateSeries (di) + 12/24;
                                     varNight.endTime(flag,1) =DateSeries (di) + 12/24;
                                         varNight.durt(flag,1) = 0;
                       
                       
                       
                   else
                               current_next.Date = Var.Date(ss_day(locationDay)  :end);
                                 current_next.Data = Var.Data(ss_day(locationDay)  :end );
                                   ss_thres = find(   current_next.Data >thres    );
                                    varNight.startTime(flag,1) = current_next.Date(ss_thres(1));
                                     varNight.endTime(flag,1) = current_next.Date(ss_thres(end));
                                         varNight.durt(flag,1) =  (varNight.endTime(flag,1) - varNight.startTime(flag,1)   ) *24 ;  
                                       
                   end
                      continue 
                   end
              startTime = DateSeries(di) + 6/24 ; % 12:00 during day time
              endTime =  DateSeries(di + 1)  + 6/24 ; % 12:00 of next time during day time
        
              ss_current = find(  startTime  <= Var.Date  & Var.Date <= endTime  ); 
          [ minDataCurrent, minLoationCurrent ] = min( Var.Data(ss_current)  );
                         % second step
                         % find the minimum location of current day and next day
                              ss_next = find(  startTime +1  <= Var.Date  & Var.Date <= endTime +1  ); 
                              [ minDataNext, minLoationNext ] = min( Var.Data( ss_next)  );
                             % define a new data series delimited by the consective
                                % minimum value
                             current_next.Date = Var.Date(ss_current(minLoationCurrent ) :ss_next(minLoationNext) );
                             current_next.Data = Var.Data(ss_current(minLoationCurrent ) :ss_next(minLoationNext) );
                             ss_thres = find(   current_next.Data >thres    );
                            if ~isempty(ss_thres)
                             varNight.startTime(flag,1) = current_next.Date(ss_thres(1));
                                varNight.endTime(flag,1) = current_next.Date(ss_thres(end));
                                 varNight.durt(flag,1) =  (varNight.endTime(flag,1) - varNight.startTime(flag,1)   ) *24 ;  
                            else
                                       varNight.startTime(flag,1) =DateSeries(di) ;
                                        varNight.endTime(flag,1) = DateSeries(di) ;
                                        varNight.durt(flag,1) = 0 ;  
                             end
end
                  
end





