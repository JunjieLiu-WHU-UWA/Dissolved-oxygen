function    [ PHY_GPPSumSpace , PHY_GPPCVMean ]  = ThreeVolume2twoarea(PHY_GPP,Basic, Cell_whole_channel )

% this function is to convert voumetic variable  into areal variable.
% the unit of original variable is mmol/m3/d. unit of  output variable is mmol/m2/d ,
% PHY_GPPSumSpace   mmol/d    , PHY_GPPCVMean is mmol/m2/d


cellCV = Cell_whole_channel{1,1};  % the control volume across the wetland , the number of cell.
areaCV = Cell_whole_channel{1,2};  % the  control volume across the wetland , the area of each cell


ResTime = Basic.ResTime;
idx2 = Basic.idx2; 
wetDry = Basic.stat;   % the state of the cell, wet or dry.
cell_Zb =  Basic.cell_Zb;
H = Basic.H;
Stage =   H - repmat(cell_Zb, [1, size(H,2)]);  % water evelation is more proper . zero point is bottom

sigmaZ = [1.0 0.75 0.5 0.25 ]';
for z = 1 : length(sigmaZ)  % this loop is designed to calculate the proporation of each layer.
     if z == length(sigmaZ)
          diffSigmaZ(z,1) = sigmaZ(z,1);
    else        
          diffSigmaZ(z,1) = sigmaZ(z ,1) - sigmaZ(z  + 1,1) ;
     end
end
 

PHY_GPPCV = zeros(length(cellCV), size(PHY_GPP,2)); 
% the length(cellCV)  is space, the  size(PHY_GPP,2) reprsent time
for ii = 1 : length( cellCV )
              ss = find(idx2 == cellCV(ii));
      for jj = 1 : length(ResTime)
  %  sum the water volume vertically 
   % the unit is mmol/d 
           PHY_GPPCV(ii,jj) =  (  diffSigmaZ.*  Stage(ii,jj) * areaCV(ii)  )'  *    PHY_GPP(ss,jj)  ; 
           %determine the wet or dry of the cell
           wetDryCV(ii,jj) =    wetDry(cellCV(ii),jj);
      end
    
end
% find dry cell % 0 represent dry, -1 repreent wet
ss_CV = find(  wetDryCV == 0);
% assume the dry cell as zero  
PHY_GPPCV(ss_CV) = 0; 
% give the cell area at each time step
areaCVtime = repmat(areaCV, [1, size(wetDryCV,2)]);
% assume area of dry cell as zero 
areaCVtime(ss_CV) = 0;
% sum values across all the cell.
PHY_GPPSumSpace = zeros(1, size(PHY_GPP,2));
PHY_GPPSumSpace =  sum(PHY_GPPCV )    ;  %  the unit is g/d

% method used here to calculate mean value is 
% sum of value across the whole wetalnd /     total area across the whole
% wetland
PHY_GPPCVMean = PHY_GPPSumSpace   ./ sum(areaCVtime) ;
end




