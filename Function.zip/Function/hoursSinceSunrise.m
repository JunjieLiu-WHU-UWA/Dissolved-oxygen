function   var  = hoursSinceSunrise( mDate)


 var.Date = mDate;
 var.Data = ( mDate - (floor(mDate) +  6/24 )) *24;
% for moment, we suppose that the surnris  time is 6:00am

 

end