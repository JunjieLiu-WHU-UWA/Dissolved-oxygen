clearvars -except anvil 
clc
close all
addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');
% load('anvil.mat');

% the results of oxygen is based on 20190618 3D
currentFolder  = '20190712 3D';
% nitrogen resluts is '20190712 3D'
BC_inflow = 'BC_inflow20190321.csv';
BC_Mars = 'BC_Mars20190321.csv';
% '20190412 3D'
 sTime  = datenum('2015/04/01 00:00:00');
 eTime  = datenum('2015/05/31 23:55:00');
 timeTick = {'2015/04/01 00:00:00'...
                  '2015/04/10 00:00:00'...
                  '2015/04/20 00:00:00'...
                  '2015/05/01 00:00:00'...
                  '2015/05/10 00:00:00'...
                  '2015/05/20 00:00:00'...
                  '2015/05/31 00:00:00'}';
timeLable = {' Apr 01' ' Apr 10'  ' Apr 20'   ' May 01' ' May 10'   ' May 20'  ' May 31'   }';  
dicmodel   = 'E:\Simulation_UWA_WD\';

Allyear(:,1) = (2002: 2018)';
Allyear(:,2) = ones(17 ,1) ;
Allyear(:,3) = ones(17 ,1) ;
day_second = 24* 3600;
N_mmol_g =  14 /1000;
Oxy_mmol_g = 32/ 1000;
% this determint the current folder. 
% variable of current folder must be the same with current folder.
% fileCurrent = [dicmodel currentFolder '\Output\currentFolder.mat'];
% curr = load(fileCurrent, 'currentFolder'); 
% if currentFolder ~= curr.currentFolder
%     error(' wrong crrent folder');
% end
%     
    

fileResTime = [dicmodel currentFolder '\Output\ResTime.mat'];
load(fileResTime, 'ResTime');
fileidx2 = [dicmodel currentFolder '\Output\idx2.mat'];
load(fileidx2, 'idx2');
fileFluxmat = [ dicmodel currentFolder  '\Output\Flux.mat'];
load(fileFluxmat, 'Flux');
filerawGeomat = [dicmodel currentFolder '\Output\rawGeo.mat'];
load(filerawGeomat, 'rawGeo');
fileBasicmat = [dicmodel currentFolder '\Output\Basic.mat'];
load(fileBasicmat, 'Basic');
% '20190115 3D';
% '20190203 2D';
% 
ncfile =  [dicmodel currentFolder '\Output\anvil.nc' ];
ncid = netcdf.open(ncfile,'NC_NOWRITE');  
basicInfor = ncinfo(ncfile);

% positionInlet = [399615.76118518575  	6460376.307198627]; % This point is
% % located in the start point of upstream channel, 
% %  positionInlet = [399537.65 	6460134.59];  % this point is located in the end point of upstream channel and is seen as start point
% positionMid  = [399565.077639184   6460035.742578388];
% positionWeir =  [399481.1  6459913.827];
% geofile = [ dicmodel currentFolder '\Input\log\anvil_geo.nc' ];
% inletCell = ID_CellnearestNeighbor(geofile, positionInlet);
% 
% weirCell = ID_CellnearestNeighbor(geofile, positionWeir);
% midCell = ID_CellnearestNeighbor(geofile, positionMid);

inletCell = 4;  % use cell number , dont use the coordiante of point
 midCell = 669;
 weirCell = 1894;


idx2InletCell = find(  idx2 == inletCell );
idx2midCell = find(  idx2 == midCell );
idx2weirCell = find(  idx2 == weirCell );

filerawGeomat = [dicmodel currentFolder '\Output\rawGeo.mat'];
load(filerawGeomat, 'rawGeo');

fileCellmat = [dicmodel currentFolder '\Output\Cell_whole_channel.mat'];
load(fileCellmat, 'Cell_whole_channel');

% global cellCV areaCV 
cellCV = Cell_whole_channel{1,1};  % the control volume across the wetland , the number of cell.
areaCV = Cell_whole_channel{1,2};  % the  control volume across the wetland , the area of each cell

period = { '01/04/2015', '06/04/2015' , ...
                 '07/04/2015',   '14/04/2015', ...
                   '15/04/2015',   '30/04/2015', ...
                   '01/05/2015',  '5/05/2015', ...
                   '6/05/2015',    '15/05/2015', ...
                   '16/05/2015',    '21/05/2015', ...
                   '22/05/2015', '31/05/2015' };
  period_10min = { '01/04/2015 00:00:00', '06/04/2015 23:50:00' , ... 
                                '07/04/2015 00:00:00',   '14/04/2015 23:50:00', ...
                                 '15/04/2015 00:00:00',   '30/04/2015 23:50:00', ...
                                  '01/05/2015 00:00:00',  '5/05/2015 23:50:00', ...
                                  '6/05/2015 00:00:00',    '15/05/2015 23:50:00', ...
                                   '16/05/2015 00:00:00',    '21/05/2015 23:50:00', ...
                                    '22/05/2015 00:00:00', '31/05/2015 23:50:00' }';             
               
     % calculate the wet area of wetland with time
     
     len_time =   length(ResTime);
     wetArea.Date = ResTime; 
     wetArea.Data = zeros(len_time ,1 ); 
     flag = zeros(2013 ,1 );
    flag(cellCV) = 1;
     stat = Basic.stat  * (-1);% after conversion , 0 respresnt dry, 1 represent wet
     for ii =  1 : len_time 
        
         wet_dry = stat(:,ii);

         ss= wet_dry &   flag ;
         
         wetArea.Data(ii, 1) = sum(Basic.cell_area(ss));
         
     end
     
     
     
     inlet_odd = (1: 2 : 17568)';
%      figure
%      plot( wetArea.Date ,wetArea.Data, '*'  )
%      
%                                                                         
%      set(gca,'XTick',[ datenum(timeTick )],'XTickLabel',timeLable,'TickLength',[0.005 0.015]);
     