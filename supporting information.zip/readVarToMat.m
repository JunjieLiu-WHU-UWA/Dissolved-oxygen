clc
% this script is to read all the basic variable and store them as mat file
% for BasicRead to load.
% This can increaese the speed 
% The list of variable is 
% currentFolder, ResTime, idx2 , Flux, rawGeo, Basic, Cell_whole_channel


addpath('E:\Simulation_UWA_WD\2 For model variables\Function');
addpath('E:\Simulation_UWA_WD\2 For model variables\Supporting information');

dicmodel   = 'E:\Simulation_UWA_WD\';
currentFolder  =  '20190806 3D';
% 
% fileCurrent = [dicmodel currentFolder '\Output\currentFolder.mat'];
% save(fileCurrent, 'currentFolder');
ncfile =  [dicmodel currentFolder '\Output\anvil.nc' ];
ncid = netcdf.open(ncfile,'NC_NOWRITE');  
varid = netcdf.inqVarID(ncid,'ResTime');
ResTime = netcdf.getVar(ncid,varid) ./24 +  datenum(2001,1,1);

fileResTime = [dicmodel currentFolder '\Output\ResTime.mat'];
save(fileResTime, 'ResTime');

varid = netcdf.inqVarID(ncid,'idx2');
idx2 = netcdf.getVar(ncid,varid); 

fileidx2 = [dicmodel currentFolder '\Output\idx2.mat'];
save(fileidx2, 'idx2');


fluxfile = [   dicmodel currentFolder '\Output\anvil_FLUX.csv' ];
fileHeaders = 'headersFlux24.csv';

[~,headers] = xlsread(fileHeaders);

Flux = tfv_process_fluxfile(fluxfile,'flux.mat',headers);
fileFluxmat = [ dicmodel currentFolder  '\Output\Flux.mat'];
save(fileFluxmat, 'Flux');

%--------------------------------------------------


geofile =[ dicmodel currentFolder '\Input\log\anvil_geo.nc' ];
ncid_geo = netcdf.open( geofile,'NC_NOWRITE');
for ii = 1: 30
    [varname{ii}, xtype(ii), vardimids{ii} ] = netcdf.inqVar(ncid_geo, ii-1);
    rawGeo.(varname{ii})  = netcdf.getVar(ncid_geo,ii-1 );
end
filerawGeomat = [dicmodel currentFolder '\Output\rawGeo.mat'];
% save Flux.mat Flux
save(filerawGeomat, 'rawGeo');
%---------------------------


%--------------
var = {'idx3', ...
'stat' , ... % -1 represent wet, 0 represent dry % 0 represent dry, -1 repreent wet
'H'}';


Basic = tfv_readnetcdf(ncfile,'names',var);
Basic.idx2 = idx2;
Basic.ResTime = ResTime;
Basic.cell_Zb = rawGeo.cell_Zb;   % the elevation of each cell
Basic.cell_X = rawGeo.cell_ctrd(1,:)'; % the coordinate of central point in the cell.
Basic.cell_Y = rawGeo.cell_ctrd(2,:)'; % the coordinate of central point in the cell.
Basic.cell_area = rawGeo.cell_area';  % the area of each cell

%--------------
sigmaZ = [1.0 0.75 0.5 0.25 ]';
for z = 1 : length(sigmaZ)  % this loop is designed to calculate the proporation of each layer.
     if z == length(sigmaZ)
          diffSigmaZ(z,1) = sigmaZ(z,1);
    else        
          diffSigmaZ(z,1) = sigmaZ(z ,1) - sigmaZ(z  + 1,1) ;
     end
end
 
 Basic.diffSigmaZ = diffSigmaZ ;
fileBasicmat = [dicmodel currentFolder '\Output\Basic.mat'];
save(fileBasicmat, 'Basic');


% initial vesion of 2dm file
NS1 = [8 1 2 3 4 5 13]';
NS12 = [  1683 1682 1684 1685 1693 1702 1704]';

NS_node{1,1} = NS1 ;
NS_node{2,1} = NS12 ;
%---------------------------
Node_XY = rawGeo.node_coord'; % the x and y coordinate of nods
cell_XY  = rawGeo.cell_ctrd';       % the coordiante of central points within cell
cell_area = rawGeo.cell_area;   % the area of each cell

 cell_X = cell_XY(:,1);  % X- coordinate of central point in 
    cell_Y = cell_XY(:,2);
 leftPoint(1,1) = 399321.0;  
 leftPoint(1,2) = 6460107.6;
    
    rightPoint(1,1) = 399892.3; 
    rightPoint(1,2) = 6460066.5;
    
    NSup(:,1) = Node_XY(NS_node{1,1}  ,1);
    NSup(:,2) = Node_XY(NS_node{1,1}  ,2);
    
    NSdown(:,1) = Node_XY(NS_node{2,1}  ,1);
    NSdown(:,2) = Node_XY(NS_node{2,1}  ,2);
    
    [ployX, ployY ]  = createPolygon( leftPoint, rightPoint, NSup, NSdown); 
    % plotyX and ployY is the created Polygon
    

          % find ID of cell  inside the ploygon.
    [in,~ ] = inpolygon( cell_X , cell_Y,ployX , ployY  ); 
        % find ID of node inside the ploygon.
      [in_node,~ ] = inpolygon( Node_XY(:,1) , Node_XY(:,2) ,ployX , ployY  ); 
    

    Cell_whole_channel{1,1} = find(in == 1 );  % the ID of cell within each volume
    Cell_whole_channel{1,2} = cell_area(in);  %  the area of each cell inside the volume
    Cell_whole_channel{1,3} = sum(cell_area(in));  %  the total  area of  the control  volume
    Cell_whole_channel{1,4} = find(in_node == 1 );  % the ID of node within  volume
    Cell_whole_channel{1,5} = in; %logical number , 1 represent  cell with control voume , 
                                                              % 0 represent cell is outside the control volume 
figure
plot(ployX, ployY  )
hold on
plot( cell_X,cell_Y ,'*')
hold on 
plot(cell_X(in), cell_Y(in),'o')
hold on
title('Central point of cell')
axis equal

figure
plot(ployX, ployY  )
hold on
plot( Node_XY(:,1),Node_XY(:,2) ,'*')
hold on 
plot(Node_XY(in_node,1), Node_XY(in_node,2),'o')
hold on
title('Point of node')
axis equal


fileCellmat = [dicmodel currentFolder '\Output\Cell_whole_channel.mat'];
% save Flux.mat Flux
save(fileCellmat, 'Cell_whole_channel');

% the first colume is the ID of cell within each volume;
% the second colume is  the area of each cell inside the volume;
% the third colume is   the total  area of  the control  volume
  % the fourth colume is the ID of node within  volume

function [ployX, ployY ]  = createPolygon( leftPoint, rightPoint, NSup, NSdown)


NS1_len = size(NSup,1);
NS2_len = size(NSdown,1);


ployX(1,1) =  leftPoint(1,1);
ployX(2: 1+ NS1_len,1) =   NSup(:,1) ;
ployX(1+ NS1_len +1,1) =  rightPoint(1,1);
ployX(  (1+ NS1_len +1+1) : (1+ NS1_len +1 +NS2_len)  ,1) = fliplr(NSdown(:,1)')' ;
ployX( 1+ NS1_len +1 +NS2_len +1  ,1) =   leftPoint(1,1); 

ployY(1,1) =  leftPoint(1,2);
ployY(2: 1+ NS1_len,1) =   NSup(:,2) ;
ployY(1+ NS1_len +1,1) =  rightPoint(1,2);
ployY(  (1+ NS1_len +1+1) : (1+ NS1_len +1 +NS2_len)  ,1) = fliplr( NSdown(:,2)')' ;
ployY( 1+ NS1_len +1 +NS2_len +1  ,1) =   leftPoint(1,2); 

end
